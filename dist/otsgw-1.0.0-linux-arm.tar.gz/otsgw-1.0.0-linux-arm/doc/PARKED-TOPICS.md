# Parked topics

Decisions taken knowingly, with the hardening left for later. Each entry says what the current
behaviour is, why it was accepted, and what closing it would take — so that "we will look at it
later" does not quietly become "nobody remembered".

Protocol work that is designed but not built lives in [`DESIGNS-PENDING.md`](DESIGNS-PENDING.md)
(streaming proxy, `resources` and `prompts`). This file is about operations and exposure.

---

## 1. The local UIs listen on every interface

**Current behaviour.** All five listeners bind to every interface:

```
TCP *:7082   gateway            MCP endpoint
TCP *:7083   mock server        fake backend
TCP *:7086   auth server        token endpoint  (when auth_server.internal.port is set)
TCP *:7085   dashboard          governance UI
TCP *:7001   console            writes ots.json
```

The dashboard and the console used to bind to `127.0.0.1` only. They were opened on purpose, to make
them reachable from another machine while the product is being built.

**What that means today.** Anyone who can reach the port gets in, unless `access_key` is set:

| Port | What an unauthenticated visitor can do |
|---|---|
| 7001 · console | **rewrite `ots.json`**: create consumers and credentials, widen allowlists, raise plans, point an MCP at another backend. It applies hot, with no restart |
| 7085 · dashboard | read the catalogue, the consumers, the masked keys and the full trace of every transaction |
| 7086 · auth server | try `client_id`/`client_secret` pairs. Bot detection throttles at `rate_per_minute`, it does not deny |

The gateway logs a warning at startup for each UI that has no `access_key`, the console one marked
`🚨` because it writes.

> **Half closed on 2026-09-07.** The `ots.json` of this repository now sets both
> `console.access_key` and `dashboard.access_key`, so neither UI answers without its key: `401` with
> `WWW-Authenticate: ApiKey realm="ots-console"` / `"ots-dashboard"`, and the key travels in
> `X-Console-Key` / `X-Dashboard-Key` or as `?key=`. Two things were fixed to make that a real
> control: the key is read from the **live** configuration on every request — before it was captured
> at startup, so turning it on required a restart, which is exactly when you cannot afford one — and
> the dashboard now compares it in **constant time**, as the console already did.
>
> What is still open here is everything below: the listeners still bind to every interface, so the
> keys are the only barrier. Keep the ports closed at the firewall or the security group anyway.
>
> **A cost of turning the keys on, found and closed on 2026-09-09.** For a day the two UIs stopped
> working as UIs: `?key=` authenticated the request it rode on, no cookie was issued, and the links
> and forms the pages generate are plain paths — so in a browser the entry page loaded and the first
> click was `401`. On the console every form (`/apply`, `/plan`, `/subscription`, `/mcp`,
> `/method/add`) posted without the key, so no save went through. The refusal was right; what was
> missing was a way for a browser to keep hold of the credential.
>
> Both UIs now issue a **session cookie** the first time a valid key arrives by header or by
> `?key=`, and accept it afterwards as a third source. `HttpOnly`, `SameSite=Strict` — which is what
> keeps another site from posting a configuration change through a browser that happens to be signed
> in — no `Max-Age`, and `Secure` only when the request came over TLS. It carries the same secret the
> query string already did, so it grants nothing new. Rotating the key invalidates every cookie by
> itself, and a cookie that no longer matches is cleared on that same response, so the operator is
> asked once instead of being refused forever. `dashboardAuth` and `consoleAuth` are now one shared
> `uiAuth`, which is what keeps the two from drifting apart. The header and `?key=` behave exactly as
> before, so nothing scripted against them changed. It is written up in *Reaching the dashboard and
> the console* in [`README.md`](README.md) and checked by cases 10.1 to 10.4 and 10.12 of
> [`MANUAL-TESTS.md`](MANUAL-TESTS.md).

**Cheapest mitigation right now**, no code involved: set `console.access_key` and
`dashboard.access_key`, and keep the ports closed at the firewall or the security group. On a
developer laptop, the operating system firewall already refuses inbound connections to the binary —
on a Linux server or inside a container it does not, and the socket is reachable.

**What closing it properly would take**, in increasing order of effort:

1. **`bind` per component** — one field on `dashboard`, `console`, `mock_server` and
   `auth_server.internal`, empty meaning every interface and `127.0.0.1` meaning this machine only.
   It existed for `auth_server.internal` and was removed to keep the block to a single field; the
   code is a one-line `Addr` change per listener.
2. **An allow list of client addresses** — `allowed_clients: ["10.0.0.0/8", "192.168.1.55"]` checked
   in the middleware of each UI, answering `403` to anything else. CIDR parsing is in the standard
   library (`net.ParseCIDR`), and it survives a reverse proxy only if `X-Forwarded-For` is trusted
   explicitly, which is its own decision.
3. **A block list** — the inverse, useful to shut out one source without rewriting the allow list.
   Worth less than the allow list: it denies by default nothing.
4. **Real authentication on the UIs** — the `access_key` is a shared secret in a header or a query
   string, which is enough for an operator on a private network and not enough for a public one.
   Session cookies, or the gateway's own OAuth with a scope like `ots:console`, would be the step up.
5. **mTLS or a reverse proxy in front** — the usual production answer, and the one that does not need
   any of the above.

**How to verify whatever is chosen.** `lsof -nP -iTCP -sTCP:LISTEN | grep otsgateway` shows what is
actually bound: `*:7001` is every interface, `127.0.0.1:7001` is not. Reaching the port from another
machine on the network is the only test that proves it.

---

## 2. Secrets are stored in clear in `ots.json`

**Current behaviour.** API keys and `client_secret` values are written literally, and the console
generates them and shows them once before masking them in the UI. `env:NAME` is supported everywhere
and keeps the value out of the file.

**Why it was accepted.** Editing the file by hand and debugging a credential is much easier this way,
and it matches how the API keys already worked.

**What closing it would take.** Store a hash instead of the value: the console generates the
credential, shows it once and saves `sha256` with a salt, or `bcrypt`. Authentication compares
hashes, so nothing else changes — except that a credential can then only be regenerated, never
recovered, which is exactly what WSO2 does with its consumer keys. The one design decision is
whether both credential types get it or only `client_secret`.

> **Closed on 2026-09-07**, and the decision was **both credential types**: an API key and a
> `client_secret` are the same kind of shared secret, and hardening one while leaving the other in
> clear would only move the problem.
>
> A credential field now takes a third form, `sha256:<salt>:<digest>`, alongside the literal and
> `env:NAME` — the prefix mirrors `env:` so one field keeps one meaning. Authentication compares the
> hash in constant time, on the MCP endpoint and on the token endpoint alike, so nothing else in the
> pipeline changed. The salt is per credential.
>
> Three deliberate choices:
> - **Literals still work.** A cutover that invalidated every configuration written so far would have
>   been a worse problem than the one being solved.
> - **`console.hash_new_credentials`** (true in this repo) makes the console store hashes for what it
>   creates from then on. It already showed a new credential once; now that is the only time anybody
>   can read it.
> - **`./otsgateway -hash '<secret>'`** prints the stored form, because this file gets edited by
>   hand and hardening a credential should not require the UI.
>
> What is left in clear on purpose: the `api_key` and `client_secret` of `c0`, which every document
> and every manual test uses as an example. Hashing them would break the examples without protecting
> anything — they are development values for a gateway that listens on a laptop.
>
> One consequence worth knowing: the load-time check that refuses the same `api_key` on two consumers
> can only see literals, because two hashes of the same secret never collide.

Until then: `env:NAME` for anything that matters, and never commit the file with real values.

> **Closed on 2026-09-09.** Two things happened. First the defect: `env:` used to be resolved *into*
> the configuration in memory, and the console writes that back to disk, so any save turned every
> reference into the plaintext secret. The field is no longer overwritten — the loader validates, and
> the value is read at the point of use — so `ots.json` keeps saying `env:NAME` for its whole
> life. It is C5 in [`AUDIT.md`](AUDIT.md).
>
> Then the store: the values live in **`secrets.json`** next to `ots.json`, with permissions
> `600`, in `.gitignore`, read by the gateway itself and **written by the console**. Rotating a
> signing key is now a form and a save, applied on the next request with no restart, and it does not
> touch the configuration. `secrets.env` and the `source` the start script did are gone;
> `./otsgateway -import-secrets secrets.env` converts one. Written up as *Secrets* in
> [`README.md`](README.md) and checked by cases 2.13 to 2.16 and 10.16 to 10.17 of
> [`MANUAL-TESTS.md`](MANUAL-TESTS.md).
>
> What is **not** closed by this: a `secrets.env` that was already committed keeps its values in the
> git history. Migrating does not rotate them — see point 3.
>
> **And a decision taken the same day, knowingly**: `secrets.json` **is committed** in this
> repository. The gateway warns on every start, and the warning is right — everyone who clones gets
> the values, and removing the file later does not remove them from the history. It is accepted
> because this is a development environment on one laptop whose credentials are already in that
> history. Turning it round is two commands, `git rm --cached secrets.json` and putting
> `/secrets.json` back in `.gitignore`, plus rotating what was exposed. Anything that ever runs
> outside a laptop should start from there.

> **Narrowed on 2026-09-07.** The `ots.json` of this repository no longer carries a single real
> secret: the two `jwt_secret` values and the WSO2 pair are `env:` references, resolved from a local
> `secrets.env` that is in `.gitignore` (`secrets.env.example` documents its shape and travels with
> the packages). What is still literal here are the development API key and `client_secret` of `c0`,
> which every document uses as an example — those are what the hashing above would close.

---

## 3. Credentials that already reached git history

**Current behaviour.** `ots.json` carries the WSO2 `consumer_key` and `consumer_secret` of the
development environment, and they are in the history of the repository.

**Why it is parked.** It is a development environment, reachable only from the machine that runs it.

**What closing it would take.** Rotate them in WSO2 — deleting them from the file is not enough,
because the history keeps them — and move the new ones to `env:BOTIBANK_CONSUMER_KEY` /
`env:BOTIBANK_CONSUMER_SECRET`, which the gateway already resolves at startup and refuses to start
without. The same applies to `auth_server.internal.jwt_secret`: with it, anybody can mint a valid
token for any consumer.

> **Half done on 2026-09-07.**
>
> - **The two `jwt_secret` values are rotated**, to 64 random hex characters each, and live in
>   `secrets.env`. The ones in the history are dead: a token signed with them no longer verifies.
> - **The WSO2 pair moved to `env:`**, so `ots.json` stops carrying it and it cannot leak again —
>   but the value is the same one that is in the history. **This half is on you**: regenerate the
>   keys of that application in the APIM and paste the new pair into `secrets.env`. Until then, treat
>   that development environment as one whose credentials are public.
> - The API key and the `client_secret` of `c0` were left as they are on purpose: every document and
>   every manual test uses them as an example, and they are development values for a gateway that
>   listens on a laptop.
>
> **Updated on 2026-09-09.** The values now live in `secrets.json`, which is in `.gitignore` — so
> nothing new leaks from here on. But `secrets.env` **was** committed, so the four values are in the
> history of this repository and stay there. The JWT pair is dead already (rotated on 2026-09-07);
> the WSO2 pair is the half that still needs regenerating in the APIM. Generating real ones is one click in the console, which already produces 32
>   random hex characters and shows them once.

---

## 4. The `free` plan is effectively unlimited — closed

**What it used to be.** `free` allowed 10 req/s with a burst of 10, 100 calls an hour and 200 a day,
while `premium` was *stricter* (2 an hour). The numbers were there to make the limits visible in the
dashboard, not to protect anything — and the ladder was upside down, which is the part that would
have bitten first.

**What it is since 2026-09-07.** A ladder that is monotonic on the four axes, so moving a consumer up
a plan never takes anything away from it:

| Plan | req/s | burst | per hour | per day | What it is for |
|---|---|---|---|---|---|
| `free` | 2 | 5 | 60 | 500 | a trial or a development agent: the burst covers one agent turn that chains a few tools, 60 an hour is about one a minute sustained, and 500 a day caps a runaway loop |
| `premium` | 20 | 40 | 5000 | 50000 | a real workload: ten times the rate, ~83 a minute sustained |

The numbers are a starting point, not a law: plans apply hot, so changing them in the console takes
effect on the next request. What matters is that they now **bind** — verified: with `free`, the sixth
call in a burst gets `429` with `Retry-After`.

**And one mistake the loader now catches**: a plan whose `quota_hourly` is above its `quota_daily`
gets a warning at startup, because the hourly cap can never bind — the day runs out first. It is
always a configuration slip.
