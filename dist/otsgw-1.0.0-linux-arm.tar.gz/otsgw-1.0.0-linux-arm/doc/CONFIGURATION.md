# Configuration reference

Everything the gateway reads from `ots.json`, block by block: what each field does, its type, its
default, and whether changing it applies live or needs a restart.

> **The file is `ots.json`.** `config.json` is still read everywhere, so a deployment created before
> the rename needs no migration: `-config <path>` takes any name it is given, and with no flag the
> gateway reads the first of the two that is there and says which — `📄 Configuración: ots.json`.
> A folder with both is a folder mid-rename, and the new name wins.

Three ways to edit it:

- **The console** at `http://localhost:7001` — forms for plans, consumers, credentials and MCPs, plus a
  raw editor for everything else. It validates before writing, keeps a `.bak`, and applies the change
  live. This is the recommended path.
- **The VS Code connector** — the same fields as a form, plus the map: see
  [`VSCODE-PLUGIN.md`](VSCODE-PLUGIN.md). It writes the file, which the gateway is watching, so saving
  is already applying.
- **By hand.** With `otsgateway.watch_files` on (the default), the file is re-read within seconds. If
  you turned the watcher off, press *Reload from disk* in the console or restart.

An invalid file is never written and never applied: the gateway keeps running with the previous
configuration and reports what is wrong.

---

## Quick map

```json
{
  "otsgateway":    { ... },   // the MCP endpoint agents call
  "auth_server":   { ... },   // who issues and who validates the bearer tokens
  "dashboard":     { ... },   // read-only governance UI
  "console":       { ... },   // configuration panel
  "mock_server":   { ... },   // fake backend that answers from the spec examples
  "telemetry":     { ... },   // traces, counters and the journal
  "plans":         { ... },   // rate limits and quotas, by name
  "mcps":          [ ... ],   // the MCPs and their backends
  "subscriptions": [ ... ]    // consumers, credentials and what each may call
}
```

---

## `otsgateway`

The endpoint agents talk to.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | `true` | — | Reserved; the gateway always serves |
| `server_url` | string | `http://localhost` | — | Informational, for logs and docs |
| `server_port` | string | — | **restart** | Port of the MCP endpoint (`POST /mcp/messages`). Required |
| `log_file` | string | `logs/otsgateway.log` | — | Where `otsgateway.sh` redirects the process output |
| `allowed_origins` | string[] | `[]` | yes | Browser origins allowed to call. Empty means: a request carrying any `Origin` is refused with 403. `"*"` disables the check |
| `cors.enabled` | bool | `false` | yes | Whether the gateway answers the browser preflight and echoes the CORS headers |
| `cors.max_age_sec` | int | `600` | yes | How long a browser may cache the preflight |
| `watch_files` | bool | `true` | yes | Watches `ots.json` and every `ots_file` and reloads on change |
| `watch_interval_sec` | int | `5` | yes | How often the watcher checks the modification times |

```json
"otsgateway": {
  "enabled": true,
  "server_url": "http://localhost",
  "server_port": "7082",
  "log_file": "logs/otsgateway.log",
  "allowed_origins": [],
  "cors": { "enabled": false, "max_age_sec": 600 },
  "watch_files": true,
  "watch_interval_sec": 5
}
```

**About `allowed_origins` and `cors`.** They are two halves of the same story. `allowed_origins` is
the defence — who may call at all — and is enforced whether or not CORS is on. `cors.enabled` is the
permission the browser needs to let its own JavaScript read the response. A server-side agent (curl,
an SDK, another service) sends no `Origin` and is unaffected by either.

Both apply to **every endpoint an agent touches**, on the gateway port and on the mock port:
`POST /mcp/messages`, `POST /oauth/token` and the two `/.well-known/` discovery documents. A browser
agent that could not read the metadata or the token would never get as far as calling a tool, so
these are governed by the same two settings rather than left open. `WWW-Authenticate` and
`Retry-After` are published in `Access-Control-Expose-Headers`, because a header that is not exposed
there is invisible to the page — and that is the header a standard MCP client reads to find out where
to authenticate.

---

## `auth_server` — who issues and who validates the tokens

A **top-level block**, a sibling of `otsgateway` and not a field inside it, because the authorization
server is not a property of one listener: the gateway runs under it, and every other listener
inherits it.

```json
{
  "otsgateway":  { "server_port": "7082", … },
  "auth_server": { "internal": { … }, "external": { … } },
  "mock_server": { "server_port": "7083", "auth_server": { … } }
}
```

| Where it is declared | Who it governs |
|---|---|
| top level (`auth_server`) | the MCP endpoint, `POST /mcp/messages`, and anything that does not override it |
| `mock_server.auth_server` | only the mock port. **Declared** replaces the top-level block whole; **absent** inherits it |

> The block nested inside `otsgateway` is the old place. It still loads — promoted to the top level
> with a warning, never ignored, because an endpoint believed to be protected must not come up open —
> and declaring it in both places at once is refused.

It has two independent halves, and they can run together:

| Half | Who mints the token | What the gateway needs |
|---|---|---|
| `internal` | **The gateway itself.** It serves `client_credentials` and signs HS256 tokens | `jwt_secret`, and a `client_id`/`client_secret` per consumer |
| `external` | A real identity provider (Asgardeo, WSO2 IS, Entra ID, Auth0…) | `jwks_url`, to verify the RS256 signature |

With **neither** half enabled, only API keys get in. That breaks no rule — authorization is
*OPTIONAL* in MCP — but it has one practical consequence: **no off-the-shelf MCP client knows how to
send an API key.** Claude, ChatGPT, VS Code and Cursor all do the same thing: get a 401, read
`WWW-Authenticate` to discover the authorization server, and come back with a bearer token. Enabling
either half is what makes the gateway reachable from them without adapters.

> Which credential a given consumer may use is **not** decided here. It is declared in its own
> subscription, in [`auth_method`](#subscriptions). This block only says who may issue tokens at all.

### `auth_server.internal`

Turns the gateway into the authorization server too, so it needs no identity provider to work — the
same way the mock needs no backend.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | `false` | yes | Whether the token endpoint answers and HS256 tokens are accepted |
| `token_endpoint` | string | `/oauth/token` | **restart** | Path that serves `client_credentials`. Cannot collide with `/mcp/messages` or `/.well-known/…` |
| `port` | string | — | **restart** | Moves the authorization server to a listener of its own. Empty shares the port of the server it belongs to — see [*One port or two*](#one-port-or-two) |
| `jwt_secret` | string | — | yes | The HS256 key that signs and verifies. Required when enabled. Accepts `env:NAME`. Under 32 characters raises a warning |
| `token_duration_minutes` | int | `60` | yes | Lifetime of an issued token |
| `issuer` | string | `ots-gateway` | yes | `iss` claim. A token with another `iss` is refused |
| `audience` | string | = `issuer` | yes | `aud` claim. A token with another `aud` is refused |
| `bot_detection.enabled` | bool | `false` | yes | Throttles the token endpoint |
| `bot_detection.rate_per_minute` | number | `30` | yes | Sustained rate allowed, counted per `client_id` **and** per source IP |
| `bot_detection.burst` | int | `5` | yes | Requests allowed back to back before throttling starts |

```json
"auth_server": {
  "internal": {
    "enabled": true,
    "token_endpoint": "/oauth/token",
    "jwt_secret": "env:OTS_JWT_SECRET",
    "token_duration_minutes": 60,
    "bot_detection": { "enabled": true, "rate_per_minute": 10, "burst": 5 }
  }
}
```

How an agent gets in:

```bash
# 1. exchange the credentials of its subscription for a token
curl -s -X POST http://localhost:7082/oauth/token \
  -d 'grant_type=client_credentials&client_id=agente-ventas&client_secret=…'
# {"access_token":"eyJhbGciOiJIUzI1NiJ9…","token_type":"Bearer","expires_in":3600,
#  "scope":"bank:transfer:execute"}

# 2. call with it
curl -s -X POST http://localhost:7082/mcp/messages \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9…" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

`client_secret_basic` works too (`curl -u 'client_id:client_secret'`), which is the form OAuth 2.1
prefers.

**The scopes are not configured here.** The token carries what the *OTD* demands for the tools that
subscription allows — the union of the `security` blocks of those tools — so a token never claims
more than the allowlist already grants. A client may narrow that with `oauth2.scopes` in its
subscription, or per request with `&scope=…`; asking for anything outside the cap is
`invalid_scope`.

**About `jwt_secret`.** Whoever holds it can mint valid tokens for any consumer. Keep it in the
environment (`env:OTS_JWT_SECRET`), give the mock a different one, and rotate it by restarting —
every issued token becomes invalid at once, which is exactly what a rotation should do.

#### One port or two

Empty `port` is the simplest setup and the recommended default: the token endpoint lives on the
gateway itself and there is one address to expose, one certificate, one thing to configure. Sharing
breaks no rule — the discovery documents publish **absolute URLs**, so a client follows the link
wherever it points.

Setting `port` isolates it, and the reason is exposure rather than protocol:

| | `POST /mcp/messages` | `POST /oauth/token` |
|---|---|---|
| Who calls | agents already identified | anyone, **before** the server knows who they are |
| What travels | tool arguments | the `client_secret` |
| How it fails | `403` and life goes on | credential stuffing |

It is the only door that must answer without knowing who is asking, and the only one a secret travels
through. On its own port it can be kept on an internal network, put behind a different WAF, or simply
never published — the firewall decides, not the gateway.

```json
"auth_server": {
  "internal": {
    "enabled": true,
    "port": "7086",
    "token_endpoint": "/oauth/token",
    "jwt_secret": "env:OTS_JWT_SECRET"
  }
}
```

What moves and what stays:

| | Shared (`port` empty) | Own port |
|---|---|---|
| `POST /oauth/token` | gateway port | **the new port** — `404` on the gateway |
| `GET /.well-known/oauth-authorization-server` | gateway port | **the new port** — it describes the authorization server |
| `GET /.well-known/oauth-protected-resource` | gateway port | gateway port — it describes the *resource*, which has not moved |
| `authorization_servers` in that metadata | the gateway origin | `http(s)://<host>:<port>` |
| `tokenEndpoint` in `server/discover` | the path | the whole address |

Nothing else changes: the token is the same, the secret is the same, and the gateway keeps accepting
it. Only two fields need a restart — `port` and `token_endpoint` — because a listener is bound once.

Two guards at load time: a `port` that is already the dashboard's, the console's or the mock's is
refused, and a `port` equal to the gateway's own is accepted as "shared", with a warning, since the
endpoint is already served there.

**Bot detection** is on the token endpoint because that is the one door that must answer before any
subscription is known, and therefore the natural target of credential stuffing. Two buckets are
counted at once, per `client_id` and per source address, so neither one credential nor one host can
hammer it. Over the limit the answer is `429` with `{"error":"slow_down"}` and `Retry-After: 60`.
The plan's own rate limit and quota are a different thing: they apply to the MCP calls, not to
getting a token.

### `auth_server.external`

Keeps the gateway as a pure resource server: the token comes from your provider and the gateway only
verifies it.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | `false` | yes | Whether RS256 tokens are accepted |
| `jwks_url` | string | — | yes | Where the signing keys live. Required when enabled. Cached 5 minutes and refetched when a `kid` is unknown |
| `issuer` | string | — | yes | When set, the `iss` claim must match exactly |
| `audiences` | string[] | `[resource]` | yes | Accepted values of `aud`. **Set this**: without it a token minted for another resource is accepted here (the loader warns). Some providers — WSO2 among them — put the `client_id` there instead of a URI |
| `resource` | string | the request URL | yes | Canonical URI of this MCP server, published in the metadata (RFC 8707) |
| `authorization_servers` | string[] | `[issuer]` | yes | Published in the metadata so a client discovers where to ask for a token |
| `scopes_supported` | string[] | — | yes | The minimal set published in the metadata and offered in the 401 challenge |
| `scope_claim` | string | `scope` | yes | Claim carrying the scopes. Space-separated string or list |
| `subject_claim` | string | `client_id` | yes | Claim that identifies the caller, matched against `auth_method[].oauth2.client_id` of a subscription |
| `tls_skip_verify` | bool | `false` | yes | For a JWKS endpoint with a self-signed certificate |

```json
"auth_server": {
  "external": {
    "enabled": true,
    "jwks_url": "https://api.asgardeo.io/t/org4zfeo/oauth2/jwks",
    "issuer": "https://api.asgardeo.io/t/org4zfeo/oauth2/token",
    "audiences": ["https://gateway.example.com/mcp/messages"],
    "scopes_supported": ["bank:read", "bank:transfer:execute"]
  }
}
```

A consumer that only uses external tokens needs **no** `client_secret`: the gateway never sees it.
Its subscription declares just the `client_id`, which is what maps an incoming token to it.

### What both halves do, once enabled

- serve `GET /.well-known/oauth-protected-resource` (RFC 9728) — how a client discovers the
  authorization server, and mandatory in the 2026-07-28 revision;
- serve `GET /.well-known/oauth-authorization-server` (RFC 8414) when `internal` is on, so a client
  finds the token endpoint by itself;
- validate every token: **HS256 for internal, RS256 for external, and nothing else** — `none` and
  algorithm confusion are refused, and so is HS256 when `internal` is off;
- check `exp`, `nbf`, `iss` and **audience** on every call, then resolve the subject to a
  subscription: a perfectly valid token from a client nobody subscribed gets `403`;
- answer a missing or invalid credential with `401` and both challenges
  (`Bearer resource_metadata="…"` and `ApiKey realm="…"`), because it is the consumer who decides
  which one it uses;
- answer a token that is valid but too narrow with `403` and
  `WWW-Authenticate: Bearer error="insufficient_scope", scope="<what is missing>"`.

The scopes each tool demands live in the OTS spec, next to the tool they govern. See
[`OTD-REFERENCE.md`](OTD-REFERENCE.md#security--scopes).

### `mock_server.auth_server`

The same block, on the mock port, and the only listener that honours an override. Three cases:

| `mock_server.auth_server` | What the mock port does |
|---|---|
| absent | **inherits the top-level block.** Protected exactly like the gateway, with the same secret — so a gateway token opens the mock too. If that block has its own `port`, that single listener already serves the mock: no second one is started |
| declared, both halves `enabled: false` | **open.** No credential asked for. What a developer usually wants locally |
| declared, either half enabled | protected **with its own rules**: its own `jwt_secret`, its own lifetime, its own bot detection — and its own `port`, if you give it one. Two authorization servers cannot share a port, and the loader says so |

Protected, the mock behaves like the real thing: it demands the consumer's own credential, resolves
the subscription, hides from `tools/list` what that consumer may not call, refuses a tool outside the
allowlist with `403`, and enforces the scopes of the OTD.

```json
"mock_server": {
  "server_port": "7083",
  "auth_server": {
    "internal": { "enabled": false, "jwt_secret": "env:OTS_MOCK_JWT_SECRET",
                  "token_duration_minutes": 30 },
    "external": { "enabled": false, "jwks_url": "" }
  }
}
```

When you do protect it, give it its **own** `jwt_secret`: a token issued by the mock must not open
the real gateway, nor the other way round. And it never uses the *backend's* credentials — the
backend is precisely what the mock replaces.

---

## `dashboard`

The read-only governance UI: MCPs, their tools, the consumers and the full trace of every
transaction. It never writes configuration.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | — | **restart** | Whether the dashboard starts |
| `port` | string | — | **restart** | Port, e.g. `7085` |
| `refresh_interval_sec` | int | `5` | yes | Auto-refresh of the pages |
> **Secrets.** Any credential field of this file takes three forms: the literal value,
> `sha256:<salt>:<digest>` for a hash, or **`env:NAME`** for a named secret whose value lives in
> `secrets.json` next to `ots.json` — permissions `600`, gitignored, read by the gateway and
> written by the console. `env:NAME` looks in the environment first and then in the store, and a
> reference nobody defines refuses the boot naming it. See *Secrets* in [`README.md`](README.md).

| `access_key` | string | — | yes | When set, required as `X-Dashboard-Key`, as `?key=`, or in the session cookie the first two hand out — so one url with `?key=` is enough to browse the whole UI. Compared in constant time, and read from the live configuration on every request, so setting it or rotating it needs no restart; a rotation invalidates every open session. Without it, anyone who reaches the port reads the catalogue, the consumers and every trace — see *Reaching the dashboard and the console* in [`README.md`](README.md) and point 1 of [`PARKED-TOPICS.md`](PARKED-TOPICS.md) |
| `log_file` | string | — | — | Informational |

```json
"dashboard": { "enabled": true, "port": "7085", "refresh_interval_sec": 2,
               "access_key": "", "log_file": "logs/dashboard.log" }
```

---

## `console`

The configuration panel. It listens on **every interface**, and it is the **only component that writes
configuration** — give it a key.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | — | **restart** | Whether the console starts |
| `port` | string | — | **restart** | Port, e.g. `7001` |
| `access_key` | string | — | yes | When set, required as `X-Console-Key`, as `?key=`, or in the session cookie the first two hand out — without the cookie the forms of the console could not be submitted from a browser at all. `SameSite=Strict` on it is what keeps another site from posting a configuration change through a signed-in browser. Live like the dashboard one: an access key that needed a restart would be a control you cannot turn on when you need it. Without it, anyone who reaches the port can rewrite `ots.json` — see [`PARKED-TOPICS.md`](PARKED-TOPICS.md) |
| `hash_new_credentials` | bool | `false` | yes | When true, every API key and `client_secret` the console generates is stored as `sha256:<salt>:<digest>` instead of a literal. The value is still shown once, right after creating it — and that is then the only time it can be read |
| `log_file` | string | — | — | Informational |

---

## `mock_server`

A fake MCP backend that answers from the examples declared in the OTS specs. It serves **one context
per MCP whose `mock.enabled` is true**, taken from that MCP's `context_path`.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | `false` | **restart** | Whether the mock server starts |
| `server_url` | string | `http://localhost` | yes | Base URL the gateway uses to reach it |
| `server_port` | string | — | **restart** | Port, e.g. `7083` |
| `log_file` | string | — | — | Informational |
| `auth_server` | object | inherits the top-level block | yes | Credentials demanded on the mock port — see [`mock_server.auth_server`](#mock_serverauth_server). Declare it with both halves off to leave the mock open |

An MCP with `mock.enabled` while `mock_server.enabled` is false is a contradiction and the
configuration is refused: either enable the server or turn the mock off.

---

## `telemetry`

Traces, counters, quotas and the on-disk journal.

| Field | Type | Default | Live? | What it does |
|---|---|---|---|---|
| `enabled` | bool | `true` | **restart** | Whether the journal is written. With it off, the history is memory-only and resets on restart |
| `file` | string | `logs/transactions.jsonl` | **restart** | JSONL journal: one line per transaction, plus the task handles |
| `max_history` | int | `500` | yes | Transactions kept in the in-memory ring buffer, and how many are replayed at startup |
| `max_file_mb` | int | `64` | **restart** | When the journal grows past this it rotates to `<file>.1`; one generation is kept |

At startup the whole journal is replayed: cumulative counters come from every line, and the hourly
and daily quotas are rebuilt from the transactions that actually charged quota inside the current
windows — so a restart no longer hands back consumed quota. Payloads are truncated at 16 KiB each
and API keys and tokens are always masked.

---

## `plans`

A map of plan name to limits. A consumer references one by name in `key_plan`.

| Field | Type | Meaning |
|---|---|---|
| `rate_per_second` | float | Sustained requests per second. Must be > 0 |
| `burst` | int | How many requests may arrive at once. Must be > 0 |
| `quota_hourly` | int | Cap for the current hour. `0` or less means unlimited. Above `quota_daily` it can never bind, and the loader warns |
| `tokens_hourly` | int | Budget of **context served** in the current hour, in estimated tokens. `0` or less means unlimited |
| `tokens_daily` | int | The same for the current day |
| `max_tokens_per_call` | int | Refuses a single **relayed** answer bigger than this, with `413` and `-33004`. `0` means no cap |
| `quota_daily` | int | Cap for the current day. `0` or less means unlimited |

```json
"plans": {
  "free":    { "rate_per_second": 2,  "burst": 5,  "quota_hourly": 60,   "quota_daily": 500,
               "tokens_hourly": 50000,   "tokens_daily": 400000,   "max_tokens_per_call": 12000 },
  "premium": { "rate_per_second": 20, "burst": 40, "quota_hourly": 5000, "quota_daily": 50000,
               "tokens_hourly": 1000000, "tokens_daily": 10000000, "max_tokens_per_call": 60000 }
}
```

All four apply live: changing the figures rebuilds the affected limiters on the next call. **Quota
already consumed in the current hour or day is kept** — lowering a quota does not give back what was
already spent.

Exceeding the rate returns `-33003`; exhausting a quota returns `-33004`. Both with HTTP 429 and
`Retry-After`. A `key_plan` naming a plan that does not exist refuses the configuration.

---

## `mcps`

The MCP servers whose tools the gateway exposes.

| Field | Type | Live? | What it does |
|---|---|---|---|
| `name` | string | yes | Identifier used by the subscriptions. Required |
| `description` | string | yes | Shown in the dashboard |
| `context_path` | string | yes | Path this MCP is served at, on two listeners: its **own endpoint on the gateway**, `POST /{context_path}/mcp/messages`, which serves that MCP alone; and the **mock server**, where it is required when mock mode is on |
| `ots_file` | string | yes | Path to its OTS spec (the OTD). Must exist and parse, or the change is refused |
| `mock.enabled` | bool | yes | Send this MCP's calls to the mock server instead of the real backend |
| `mock.delay_ms` | int | yes | Latency the mock simulates |
| `output.enforce` | `off`/`warn`/`reject` | yes | What to do with a backend response that does not match the `outputSchema` |
| `output.max_bytes` | int | yes | Cap on the relayed response. `0` means the global 8 MiB limit |
| `backend_server` | array | yes | The backends. A tool picks one through the `server` block of the spec; without that, the first is used |

### `backend_server[]`

| Field | Type | Default | What it does |
|---|---|---|---|
| `url` | string | — | The MCP endpoint of the backend |
| `description` | string | — | Shown in the dashboard |
| `tls_skip_verify` | bool | `false` | Skips validation of the backend certificate. Only for local self-signed setups; it also covers the token request |
| `protocol_version` | string | `""` | MCP revision this backend speaks. Empty means the legacy era: no mirrored headers, no per-request `_meta`. Set `2026-07-28` and the gateway sends both |
| `tasks` | bool | `false` | Declares the `io.modelcontextprotocol/tasks` extension to this backend, so it may return a durable handle instead of blocking |
| `security.type` | string | — | `OAuth2` or empty. With `OAuth2` the gateway fetches and caches a client-credentials token |
| `security.token_url` | string | — | Token endpoint. Required with `OAuth2` |
| `security.revoke_url` | string | — | Kept for compatibility; the gateway no longer revokes on a 401, it refreshes and retries once |
| `replicas` | string[] | — | Other addresses of **this same** endpoint, for failover. They share its security, its `protocol_version`, its `tasks` flag and its TLS setting |
| `security.consumer_key` | string | — | Client id. Accepts `env:VARIABLE` |
| `security.consumer_secret` | string | — | Client secret. Accepts `env:VARIABLE` |

```json
"mcps": [{
  "name": "botibank",
  "description": "Boti Bank OTS",
  "context_path": "/botibankots",
  "ots_file": "boti-bank-ots.yaml",
  "mock":   { "enabled": false, "delay_ms": 100 },
  "output": { "enforce": "warn" },
  "backend_server": [{
    "url": "https://localhost:8243/botibankmcp/1.0/mcp",
    "description": "Backend Boti Bank OTS",
    "tls_skip_verify": true,
    "security": {
      "type": "OAuth2",
      "token_url": "https://localhost:9443/oauth2/token",
      "consumer_key": "env:BOTIBANK_KEY",
      "consumer_secret": "env:BOTIBANK_SECRET"
    }
  }]
}]
```

### Failover: `replicas`

The entries of `backend_server` are **different destinations**, not copies: which one serves a tool,
a resource or a prompt is decided by the `server` block of the spec. Failing over from one to another
would be a routing bug dressed as resilience, so failover has its own field, and it belongs to the
endpoint:

```json
"backend_server": [{
  "url": "https://primary:8243/botibankmcp/1.0/mcp",
  "replicas": ["https://secondary:8243/botibankmcp/1.0/mcp"],
  "security": { "type": "OAuth2", "token_url": "…" }
}]
```

When it fails over, and when it does not:

| Situation | What happens |
|---|---|
| A transport failure — the address refuses the connection, or times out | the next address is tried |
| `502`, `503`, `504` | the next address is tried: that is a proxy in front of the backend, not the backend |
| `4xx`, `500`, or any other answer | **no** failover: the backend answered, and asking a second one would get the same answer twice — or do the work twice |
| `resources/read`, `prompts/get` | failover always: they are reads |
| `tools/call` | only when the tool declares `idempotent: true` in the OTD. A transport error never says whether the request arrived, so retrying a transfer could move the money twice |

The loader refuses a replica that is not an absolute `http(s)` address, and one that is also the
`url` of another entry of the same array — that would be the routing bug above. The trace names the
address that failed and the one that answered, and the dashboard shows how many an endpoint has.

**Keep credentials out of the file.** `env:BOTIBANK_CONSUMER_KEY` reads the value from the environment at
startup, and the gateway refuses to start if the variable is empty. A secret written literally here
ends up in git history.

---

## `subscriptions`

Who may call what, and **how each consumer authenticates**. One entry per consumer, one `security`
rule per credential set.

| Field | Type | Live? | What it does |
|---|---|---|---|
| `consumer_name` | string | yes | Name shown everywhere. Required and unique |
| `description` | string | yes | Free text |
| `security[].auth_method[]` | array | yes | The credentials this consumer may come in with. One entry per credential, at least one. Required |
| `security[].auth_method[].api_key` | string | yes | A key the agent sends in `X-API-Key`, or as `Authorization: Bearer` — a bearer that is not a JWT is tried as a key. Takes the three forms of a credential field: the literal, `sha256:<salt>:<digest>`, or `env:NAME` with the value in `secrets.json`. Unique across the file |
| `security[].auth_method[].scopes` | string[] | yes | The scopes **this credential carries**. On an `api_key` entry they are the scopes the key presents to the scope gate of the OTD: with none declared, any element whose contract demands a scope is refused with `403 insufficient_scope`. On an `oauth2` entry the scopes travel in the token and this list caps what the internal server may issue |
| `security[].auth_method[].oauth2.client_id` | string | yes | Identifies the client. With `internal` it is what asks for a token; with `external` it is matched against the `subject_claim` of an incoming token. Unique across the file |
| `security[].auth_method[].oauth2.client_secret` | string | yes | Only needed by `auth_server.internal`, which checks it before minting a token. An external-only consumer leaves it out — the gateway never sees it |
| `security[].auth_method[].oauth2.scopes` | string[] | yes | Caps what the internal server may issue to this client. Empty means everything the allowed tools demand in the OTD |
| `security[].key_plan` | string | yes | Name of the plan that applies to this rule |
| `security[].mcps[]` | array | yes | One object per MCP, mapping its name to what is allowed of it: `tools`, `resources` and `prompts`. Each entry is a name or `{"name": ["scope"]}` — see *Scopes on the entry* |

```json
"subscriptions": [{
  "consumer_name": "c0",
  "description": "Consumidor 0",
  "security": [{
    "auth_method": [
      { "api_key": "default-key-1235", "scopes": ["bank:accounts:read"] },
      { "oauth2": { "client_id": "agente-ventas", "client_secret": "default-secret-1235" } }
    ],
    "key_plan": "free",
    "mcps": [{
      "botibank": {
        "tools":     ["listar_clientes", "consultar_cuentas"],
        "resources": ["politica_privacidad"],
        "prompts":   ["resumen_mensual"]
      }
    }]
  }]
}]
```

**Every credential of a rule is the same consumer.** They share the plan, the rate limit, the quota
and the allowlist: it makes no difference to the plan whether the call arrived with the API key or
with a token. The dashboard shows which one each transaction used.

A credential that is not declared cannot be used. Dropping the `api_key` entry from a rule turns that
consumer OAuth-only on the next request, with no restart.

**Older spellings still load**, and the gateway normalises them into `auth_method` (the console
rewrites the file in the canonical form the first time it saves):

| Written as | Read as |
|---|---|
| `"aut_method": [ … ]` | the same list — the spelling is tolerated |
| `"api_key": "…"` | `auth_method: [{ "api_key": "…" }]` |
| `"oauth": { "subject": "…" }` | `auth_method: [{ "oauth2": { "client_id": "…" } }]`, with a warning |

**Secrets are stored in clear**, like the API keys. Use `env:NAME` for anything that matters:
`"client_secret": "env:AGENTE_VENTAS_SECRET"`.

**Three independent lists, one per MCP primitive.** MCP servers expose tools, resources and prompts,
and the subscription authorises each kind on its own: allowing `listar_clientes` grants neither the
documents nor the prompt templates of the same MCP. Each list denies by default — an absent list
means *none allowed*, not *all* — so a file written before resources and prompts existed keeps
behaving exactly as it did.

| List | Governs | Methods it gates |
|---|---|---|
| `tools` | the tools the model executes | `tools/list`, `tools/call` |
| `resources` | the documents the application attaches | `resources/list`, `resources/templates/list`, `resources/read` |
| `prompts` | the templates the user picks | `prompts/list`, `prompts/get` |

`["*"]` allows every element of that kind in that MCP, including the ones its spec gains later.
Anything not allowed is refused with `-33002` and HTTP 403, and never appears in the corresponding
list method either: the allowlist denies by default, which is the point.

**The allowlist is one of the two gates.** The other one is the `security` block of the OTD: an
element whose contract demands a scope also needs the credential to carry it — the scopes of the
bearer token, or the ones declared in `auth_method[].scopes` for an API key. Both gates filter the
catalogue as well, so a consumer never lists what it could not use. When a subscription allows an
element whose scopes its `api_key` cannot satisfy, the loader says so by name at startup: the
permission would otherwise be a guaranteed 403.

### Scopes on the entry: what the credential shows for one primitive

An entry is a name, or a name with the scopes the credential carries **when using that one
primitive**:

```json
"tools": [
  { "transferir_dinero": ["bank:transfer:execute"] },
  { "consultar_cuentas": ["cuentas:read"] },
  "listar_servicios",
  { "estado_servicio": ["*"] }
]
```

`auth_method[].scopes` declares them once for every call the credential makes; this narrows them to
the primitive that needs them, which matters most for an `api_key` — a key has nowhere else to carry
a scope.

| Entry | What the credential shows there |
|---|---|
| `"listar_servicios"` | the scopes of the credential, exactly as before this existed |
| `{ "transferir_dinero": ["bank:transfer:execute"] }` | those scopes, and only for that primitive |
| `{ "consultar_cuentas": [] }` | nothing: it satisfies only a contract that demands no scope |
| `{ "estado_servicio": ["*"] }` | the scope check of the contract is skipped for that primitive |
| `"*"` | authorises every primitive of that kind; it qualifies nothing |

Three rules keep this from becoming a hole:

- **Silence never widens anything.** A bare name means what it has always meant, so no allowlist
  written before this existed changed meaning when it shipped. The exemption is `["*"]`, written
  down, and a `grep` finds every one of them.
- **Against a token the configuration only narrows.** The scopes of a bearer token are what the
  authorization server granted; the entry can drop some of them for a primitive, never add one.
  For an `api_key` the entry *is* the declaration, because a key carries nothing of its own.
- **The internal authorization server issues no more than this.** A token is capped by what the
  subscription says the consumer may present, so a scope the allowlist would refuse is a scope that
  never gets minted.

An entry with two keys (`{"a": [...], "b": [...]}`) is refused when the configuration loads: it
would mean two things at once. The dashboard shows a qualified entry as
`botibank.transferir_dinero · scopes bank:transfer:execute`, and the side bar of the extension shows
the same under *may call*.

The console edits the three lists as three groups of checkboxes, `*` included, and writes the three
whenever it saves a subscription — carrying over the scopes of every entry that survives, because the
form has no field for them.

A consumer may hold several rules, each with its own plan and its own allowlist: useful to give one
agent a restricted credential for production and a wider one for testing. The console generates keys
and secrets of 32 random hex characters and shows the full value once — after that it masks them,
because it cannot recover what it does not display.

---

## Secrets: the three forms of a credential field

Every credential field — the two `jwt_secret`s, `consumer_key`, `consumer_secret`, `api_key`,
`client_secret` — accepts three forms, and they can be mixed freely in the same file:

| Form | Example | When to use it |
|---|---|---|
| literal | `"default-key-1235"` | development, and anything you want to be able to read back |
| `env:NAME` | `"env:BOTIBANK_CONSUMER_KEY"` | the value lives in the environment, out of the file |
| `sha256:<salt>:<digest>` | `"sha256:332e13fe…:f520d78b…"` | the value lives **nowhere**: only its hash is stored |

The hashed form is checked at authentication time, in constant time, so nothing else in the pipeline
changes. What changes is that the credential can be regenerated but never recovered — which is
exactly what WSO2 does with its consumer keys.

**To harden a credential you already have**, ask the binary for its stored form and paste it in:

```bash
./otsgw -hash 'default-key-1235'
# sha256:332e13fe216cbbb120b5e4517ec26481:f520d78b7e6ee8e7b36596cd13ced401430efc98f07f1ff17dceb53e80707a92
```

The salt is per credential, so hashing the same secret twice gives two different values and two
consumers who happen to share a secret do not share a digest. The consequence to know about: the
startup check that refuses **the same `api_key` on two consumers** can only see literals — two
hashes never collide. The console never generates a duplicate, so this matters only when editing by
hand.

**To have the console store hashes from the outset**, set `console.hash_new_credentials: true` (it is
`true` in the `ots.json` of this repository). Every key or secret the console generates from then
on is written hashed, and the banner that already showed the value once now says so: *It is stored
hashed: this is the only time it can be read.* Credentials already in the file are untouched and keep
working; turning the switch off again only affects what is created afterwards.

## A backend that is a database

An entry of `backend_server` takes a `type`. Absent or `"mcp"` is another MCP server over HTTP —
everything written before this existed keeps its meaning. `"database"` is a SQL query.

```json
{
  "url": "mariadb://localhost:3306/test?consultar_producto",
  "type": "database",
  "query_file": "sql/getProductoById.sql",
  "description": "Un producto por su id",
  "cache": { "enabled": false },
  "security": { "type": "password", "username": "root", "password": "env:DB_PASSWORD" }
}
```

| Field | Type | Required | Live | What it does |
|---|---|---|---|---|
| `type` | string | — | restart | `mcp` (default) or `database` |
| `url` | string | yes | restart | `mariadb://host:port/dbname?label`. Use `127.0.0.1` and not `localhost` (which resolves to `::1` first, where a published container is not listening); the path is the **schema**; and the query string is a **label** that makes this entry distinct, so a `server:` block of the spec can point at it. The two urls have to match exactly — that is the binding |
| `query_file` | string | yes | **live** | the `.sql`, relative to `ots.json`. Watched: editing a query applies within the watch interval |
| `security.type` | string | yes | restart | `password` |
| `security.username` | string | yes | restart | the database user. Give it **read-only** grants |
| `security.password` | string | yes | live | takes `env:NAME`, so the value lives in `secrets.json` |
| `cache.enabled` | bool | — | restart | only `false` is implemented; `true` is refused rather than ignored |
| `tls_skip_verify` | bool | — | restart | adds `tls=skip-verify` to the connection |
| `replicas` | list | — | restart | read replicas, tried on a transport failure exactly as for an MCP backend |

The primitive it serves must declare **both** `inputSchema` and `outputSchema`: the schema is the
contract, the query is only how it is answered today, and a consumer must not be able to tell.
Every `$name` in the query has to be a declared argument (or a `uriTemplate` variable, for a
resource), and the value is **bound**, never interpolated. See *A tool served by a SQL query* in
[`README.md`](README.md) for what the loader refuses and why.

## Secrets: `env:` and `secrets.json`

Every credential field accepts **`env:NAME`** instead of a literal value: the two `jwt_secret`
fields, `consumer_key`, `consumer_secret`, `api_key` and `client_secret`. The field says the name for
its whole life — nothing ever rewrites it into the value — and **a reference nobody defines stops the
load** naming it, which is better than starting with an empty credential and failing on the first
call.

The `ots.json` of this repository uses it for the four secrets that matter:

```json
"auth_server":  { "internal": { "jwt_secret": "env:OTS_JWT_SECRET" } },
"mock_server":  { "auth_server": { "internal": { "jwt_secret": "env:OTS_MOCK_JWT_SECRET" } } },
"backend_server": [{ "security": { "consumer_key":    "env:BOTIBANK_CONSUMER_KEY",
                                   "consumer_secret": "env:BOTIBANK_CONSUMER_SECRET" } }]
```

### Where the values live

`secrets.json`, next to `ots.json`. The gateway reads it, the **console writes it**, and the
watcher reloads it — so rotating a secret is a form and a save, applied on the next request with no
restart.

```json
{
  "secrets": {
    "OTS_JWT_SECRET": "32-random-characters-or-more",
    "OTS_MOCK_JWT_SECRET": "a-different-one-on-purpose",
    "BOTIBANK_CONSUMER_KEY": "your-consumer-key",
    "BOTIBANK_CONSUMER_SECRET": "your-consumer-secret"
  }
}
```

The bare map without the `"secrets"` wrapper is also accepted when reading; the wrapped form is what
the gateway writes. The file is created with permissions `600`, and `ejemplo/secrets.json` is the
tracked template.

| Rule | Why |
|---|---|
| The **environment wins** over the file for the same name, with a warning at startup | an exported variable means somebody put it there on purpose — a container, a CI runner |
| A value that is itself `env:…` is **refused** | a name pointing at a name is a cycle, or a secret that silently resolves to nothing |
| An entry nobody references is a **warning** | a store full of dead secrets is one nobody dares to clean |
| Permissions other users can read, or the file being tracked by git, are **flagged at startup** | those are the two silent ways a secret leaves the machine |

> **Whether `secrets.json` goes into git is a decision, and the startup states which one you took.**
> Committed, everyone who clones gets the values and the history keeps them for good; ignored, each
> machine keeps its own and `ejemplo/secrets.json` documents the names. This repository commits it —
> a development environment on one laptop — and takes the `🚨 secrets.json está versionado en git`
> on every start as the reminder that it is a choice, not an oversight.

### From the console

The **Secrets** section lists the names and never the values: whether something defines each one,
where from, how long it is, and which fields reference it. A referenced name cannot be deleted — the
next reload would refuse to start and you could not fix it from there. Adding an MCP with backend
credentials puts the values in the store and the reference in `ots.json`, under a predictable
name (`MCP_<NAME>_CONSUMER_SECRET`).

A credential the console **generates** does not go to the store: it is kept **hashed**
(`console.hash_new_credentials`), which is stronger — regenerable, never recoverable. The store is
for secrets somebody else issued and that have to be kept as they are.

### Coming from `secrets.env`

The earlier arrangement kept the values in a shell file that `./otsgateway.sh -start` sourced.
Nothing reads that file any more — not the gateway, not the script. The values go into
`secrets.json` as a name and a value, in the wrapped shape this document describes, and the old
file is renamed out of the way:

```bash
mv secrets.env secrets.env.migrated
```

To run the binary by hand nothing special is needed:

```bash
./otsgw -config ots.json
```

## The token budget: the other axis of a plan

Counting calls says nothing about what a call costs. One `tools/call` is one call whether it returns
three fields or three thousand, and what it returns lands in a model's context — which is the
expensive part, and the reason this gateway exists. So a plan governs two axes:

| Axis | Fields | What it protects |
|---|---|---|
| Calls | `rate_per_second`, `burst`, `quota_hourly`, `quota_daily` | the backend, and the gateway itself |
| Context | `tokens_hourly`, `tokens_daily`, `max_tokens_per_call` | the agent's context window, and the bill behind it |

**The figures are an estimate, and they are labelled as one everywhere**: four bytes to a token,
which is the usual rule of thumb. Counting exactly needs the tokenizer of a specific model, and this
gateway does not know which model is on the other side — that is the host's business. Four bytes errs
high on dense JSON, which is the safe direction for a budget.

How it behaves:

- **The window budget is checked before the work**, next to the call quota: an exhausted budget
  answers `429` with `Retry-After` and `-33004` — *the hourly token budget of the plan is
  exhausted* — without touching the backend.
- **It is charged with what was actually served**, which is only known once the answer exists. So the
  budget can be overshot by one response: the alternative is refusing content the backend already
  produced, which is worse for everybody. That is why the dashboard can read `288 / 200`.
- **The three catalogue methods are measured but not charged**, the same split the call quota makes:
  a catalogue is fetched once and it is the price of admission; the content is what scales.
- **`max_tokens_per_call` only applies to relayed answers.** What the contract itself serves is text
  whoever configures this gateway wrote, and `output.max_bytes` is its own cap.
- Every transaction records what it served, so the journal rebuilds the windows after a restart and
  the dashboard shows the context cost of a call next to its latency.

The loader warns about a budget that can never bind: an hourly above the daily, or a per-call cap
above the hourly budget.

## The port of each listener, written either way

The four listeners disagreed on the spelling: `otsgateway` and `mock_server` said `server_port`,
`dashboard` and `console` said `port`. **Both are read everywhere now**, so neither spelling is
wrong and no file has to be rewritten. What the console writes stays as it was — `server_port` for
the first two, `port` for the other two — and declaring **both with different values** is refused at
load time, because otherwise one of them would look ignored:

```
❌ otsgateway declares server_port "9999" and port "5182": they are the same field
   written two ways, so declare one
```

## What needs a restart

The console tells you when a change falls here, and so does this list:

- any port: `otsgateway.server_port`, `dashboard.port`, `console.port`, `mock_server.server_port`
- turning `dashboard`, `console` or `mock_server` on or off
- `telemetry.file`, `telemetry.max_file_mb`, `telemetry.enabled`
- `auth_server.internal.token_endpoint` and `port`, on either server: a listener is bound once, at
  startup. Everything else about `auth_server` — enabling or disabling either half, the secret, the
  lifetime, bot detection, the JWKS — is live

Everything else applies on the next request: plans, quotas, subscriptions, credentials, MCPs,
backends, mock mode, TLS flags, output policy, CORS, the watcher, and the tool catalog itself — the
OTS specs are re-read on every reload.

---

## `ejemplo/`

A folder with a deployment that works and carries **no credential**: `ots.json`, `secrets.json`, a
small `ejemplo-ots.yaml` and a `LEEME.md`. It is what the distributable packages carry, so a fresh
machine has something to start from.

```bash
cp ejemplo/*.json ejemplo/*.yaml .
./otsgw
```

It will refuse, naming the first secret without a value:

```
❌ auth_server.internal.jwt_secret is "env:OTS_JWT_SECRET" and nothing defines OTS_JWT_SECRET
```

**That is the point.** Every credential in it is an `env:` reference and every value in
`secrets.json` is empty, because an example with working credentials in it is an example somebody
publishes as it is. The five names — `OTS_JWT_SECRET`, `OTS_MOCK_JWT_SECRET`, `OTS_DASHBOARD_KEY`,
`OTS_CONSOLE_KEY`, `C0_API_KEY` — are documented in its `LEEME.md` with what each one signs or opens.

Its one backend is in **mock mode**, answering from the contract's own examples, so the deployment
answers a `tools/call` before there is anything behind it.

---

## Minimal working file

Enough to serve one MCP with one consumer:

```json
{
  "otsgateway": { "server_port": "7082" },
  "dashboard":  { "enabled": true, "port": "7085" },
  "console":    { "enabled": true, "port": "7001" },
  "plans": {
    "free": { "rate_per_second": 10, "burst": 20, "quota_hourly": 1000, "quota_daily": 10000 }
  },
  "mcps": [{
    "name": "botibank",
    "context_path": "/botibankots",
    "ots_file": "boti-bank-ots.yaml",
    "backend_server": [{
      "url": "https://localhost:8243/botibankmcp/1.0/mcp",
      "tls_skip_verify": true,
      "security": {
        "type": "OAuth2",
        "token_url": "https://localhost:9443/oauth2/token",
        "consumer_key": "env:BOTIBANK_KEY",
        "consumer_secret": "env:BOTIBANK_SECRET"
      }
    }]
  }],
  "subscriptions": [{
    "consumer_name": "agent-1",
    "security": [{
      "auth_method": [{ "api_key": "ots_change_me" }],
      "key_plan": "free",
      "mcps": [{ "botibank": { "tools": ["*"] } }]
    }]
  }]
}
```

Everything omitted takes the defaults in the tables above.

One dependency to keep in mind: **every `server.url` declared inside a tool of the spec must exist in
`backend_server`**, or the gateway refuses to start naming the tool. The spec decides which backend
serves what; this file has to contain all of them:

```json
"backend_server": [
  { "url": "https://localhost:8243/botibankmcp/1.0/mcp", "security": { … } },
  { "url": "https://localhost:8243/botibankext/1.0/mcp", "security": { … } }
]
```

---

## Common recipes

**Run without any backend, answering from the spec examples**

```json
"mock_server": { "enabled": true, "server_port": "7083" },
"mcps": [{ "mock": { "enabled": true, "delay_ms": 120 } }]
```

**Audit what the backends really return, without breaking anything**

```json
"mcps": [{ "output": { "enforce": "warn" } }]
```

Then read the log: every tool whose backend returns something its `outputSchema` does not declare is
named. Move to `"reject"` once the specs are honest.

**Let a browser-based agent connect**

```json
"otsgateway": {
  "allowed_origins": ["https://myapp.example.com"],
  "cors": { "enabled": true }
}
```

**Lock down the UIs, which listen on every interface**

```json
"dashboard": { "access_key": "…" },
"console":   { "access_key": "…" }
```

**Edit files by hand and have them picked up**

```json
"otsgateway": { "watch_files": true, "watch_interval_sec": 5 }
```

**Give an agent OAuth without deploying an identity provider**

```json
"auth_server": { "internal": {
  "enabled": true, "jwt_secret": "env:OTS_JWT_SECRET", "token_duration_minutes": 60,
  "bot_detection": { "enabled": true, "rate_per_minute": 10, "burst": 5 } } },
"subscriptions": [{ "consumer_name": "agente-ventas", "security": [{
  "auth_method": [{ "oauth2": { "client_id": "agente-ventas",
                                "client_secret": "env:AGENTE_VENTAS_SECRET" } }],
  "key_plan": "free", "mcps": [{ "botibank": { "tools": ["listar_clientes"] } }] }] }]
```

**Let a standard MCP client (Claude, ChatGPT, VS Code) connect through your own identity provider**

```json
"auth_server": { "external": {
  "enabled": true,
  "jwks_url": "https://idp.example.com/oauth2/jwks",
  "issuer": "https://idp.example.com",
  "audiences": ["https://gateway.example.com/mcp/messages"],
  "authorization_servers": ["https://idp.example.com"] } },
"subscriptions": [{ "security": [{
  "auth_method": [{ "oauth2": { "client_id": "<client_id of the agent>" } }] }] }]
```

**Keep the token endpoint off the public port**

```json
"auth_server": { "internal": {
  "enabled": true, "port": "7086", "jwt_secret": "env:OTS_JWT_SECRET" } }
```

**Protect the mock like production, but with its own tokens**

```json
"mock_server": { "auth_server": { "internal": {
  "enabled": true, "jwt_secret": "env:OTS_MOCK_JWT_SECRET", "token_duration_minutes": 30 } } }
```

**Leave the mock open while the gateway is protected**

```json
"auth_server": { "internal": { "enabled": true, "jwt_secret": "env:OTS_JWT_SECRET" } },
"mock_server": { "auth_server": { "internal": { "enabled": false },
                                  "external": { "enabled": false } } }
```

**Talk to a backend on the new MCP revision, with long-running operations**

```json
"backend_server": [{ "protocol_version": "2026-07-28", "tasks": true }]
```
