# OTS — OpenTool Specification

## Introduction

The OpenTool Specification (OTS) defines a standard, language-agnostic interface to HTTP MCP Tools
which allows both humans and computers to discover and understand the capabilities of the service
without access to source code, documentation, or through network traffic inspection. When properly
defined, a consumer can understand and interact with the remote service by parsing and serializing
messages to and from a data model with a minimal amount of implementation logic.

An OpenTool Description (OTD) can then be used by documentation generation tools to display the MCP
Tools, code generation tools to generate servers and clients in various programming languages,
testing tools, and many other use cases.

In this repository each OTD is a `*-ots.yaml` file, and the reference implementation of the
specification is the gateway described below.

## The gateway

Governance gateway for the tools consumed by AI agents. Agents never talk to the MCP servers
directly: they talk to the **OTS Gateway**, which authenticates the agent, authorises tool by tool,
enforces consumption limits and proxies the call to the real MCP, handling whatever security that
backend requires (today OAuth2 client credentials against WSO2 API Manager).

## Functional goal

- Expose tools to agents, catalogued as a list of **MCPs**.
- The agent calls the OTS Gateway naming the tool to run; the gateway proxies it, invokes the
  matching MCP tool with the security that MCP requires and returns the response to the agent.
- Agents authenticate against the gateway with the credentials declared in their **consumer**: an
  API key, an OAuth2 client, or both — each consumer decides, in its own `auth_method`. The gateway
  can mint those tokens itself (`auth_server.internal`) or validate the ones an identity provider
  issued (`auth_server.external`).
- Every consumer is subscribed to a **plan** that defines limits (requests per unit of time, and in
  the future consumed LLM tokens).
- A **dashboard** to inspect consumers.
- A **control panel** to edit `ots.json`.

---

## Architecture

### Component view

```mermaid
flowchart LR
    A1["Agent c0<br/>X-API-Key or Bearer"]
    A2["Other agents"]

    subgraph OTS["OTS Gateway :7082 — Go process (main.go)"]
        direction TB
        D["mcpDispatcher<br/>POST /mcp/messages"]
        PIPE["Per-request pipeline<br/>1 · authenticate the credential<br/>2 · authorise the tool (allowlist)<br/>3 · plan rate limit and quota<br/>4 · validate arguments against inputSchema<br/>5 · translate to the backend name and arguments<br/>6 · backend OAuth2 token"]
        REG["In-memory registry<br/>tool catalog from the OTS specs"]
        MOCK["Mock server :7083<br/>one context per mock-enabled MCP<br/>answers from the spec examples"]
        TEL["In-memory telemetry<br/>traces · counters · quotas"]
        DASH2["Dashboard :7085<br/>read-only"]
        CONS["Console :7001<br/>edits and hot-applies the config"]
        D --> PIPE
        REG -.-> D
        PIPE -->|"if mock.enabled"| MOCK
        PIPE --> TEL
        TEL --> DASH2
    end

    subgraph CFG["Configuration on disk"]
        direction TB
        CJ["ots.json<br/>plans · MCPs · subscriptions"]
        YML["*-ots.yaml<br/>tool catalog = the contract"]
    end

    subgraph WSO2["WSO2 API Manager"]
        direction TB
        IDP["Token endpoint<br/>:9443/oauth2/token"]
        GW2["API Gateway<br/>:8243/botibankmcp/1.0/mcp"]
        MCPS["MCP Server BotiBankMCP"]
        BE["Business REST API<br/>customers · accounts · mortgages"]
        GW2 --> MCPS --> BE
    end

    A1 --> D
    A2 --> D
    CJ -.->|loaded at startup| REG
    YML -.->|loaded at startup| REG
    PIPE -->|client_credentials| IDP
    PIPE -->|"JSON-RPC + Bearer"| GW2
    CONS -.->|"validates · writes · swaps"| CJ
    CONS -.->|publishes the new snapshot| REG


```

### Full flow of a `tools/call`

```mermaid
sequenceDiagram
    autonumber
    participant AG as Agent
    participant GW as OTS Gateway :7082
    participant IDP as WSO2 IDP :9443
    participant AM as WSO2 APIM :8243
    participant BE as Business API

    AG->>GW: POST /mcp/messages<br/>X-API-Key or Bearer + JSON-RPC tools/call
    Note over GW: reads the whole body and keeps it<br/>to rebuild the backend request

    GW->>GW: registry[name] → is the tool in any OTS spec?
    alt unknown tool
        GW-->>AG: JSON-RPC error -32601 (HTTP 200)
    end

    GW->>GW: authenticate the credential
    alt missing or unknown key
        GW-->>AG: JSON-RPC error -32002 (HTTP 401)
    end

    GW->>GW: subscription allowlist
    alt not allowed
        GW-->>AG: JSON-RPC error -32001 (HTTP 403)
    end

    GW->>GW: plan rate limit and hour/day quota
    alt limit exceeded
        GW-->>AG: JSON-RPC error -32029 (HTTP 429 + Retry-After)
    end

    GW->>GW: validate arguments against the spec inputSchema
    alt invalid arguments
        GW-->>AG: JSON-RPC error -32602, backend never touched
    end

    GW->>GW: translate to the backend contract<br/>backend.tool + backend.arguments

    alt mock.enabled on the MCP
        GW->>GW: target = mock server + the MCP context_path
    else real backend
        GW->>GW: target = backend_server[0].url
        opt no valid token in cache
            GW->>IDP: POST /oauth2/token<br/>grant_type=client_credentials + Basic auth
            IDP-->>GW: access_token + expires_in
            GW->>GW: cached with a 60 s safety margin
        end
    end

    GW->>AM: POST the backend URL<br/>translated body + Authorization: Bearer
    AM->>BE: resolves the tool to the mapped REST operation
    BE-->>AM: business response
    AM-->>GW: JSON-RPC result

    alt HTTP 401 from the backend
        GW->>IDP: refresh the token and drop the cache entry
        GW->>AM: retry once, transparent to the agent
    else HTTP >= 400
        GW->>GW: log the detail
        GW-->>AG: generic JSON-RPC error -32003 + requestId<br/>the backend message is never forwarded
    else HTTP 200
        GW-->>AG: the MCP JSON-RPC response
    end
```

### `tools/list` flow (catalog filtered by subscription)

```mermaid
sequenceDiagram
    autonumber
    participant AG as Agent
    participant GW as OTS Gateway

    AG->>GW: POST /mcp/messages · JSON-RPC tools/list
    loop every tool in the in-memory OTS registry
        GW->>GW: subscription allowlist check
        Note right of GW: only the tools allowed<br/>for that API key are returned
    end
    GW-->>AG: result.tools = [{name, title, description, inputSchema, outputSchema}]
```

The catalog is never asked to the MCP backend: it is built from the `*-ots.yaml` files. The OTS
spec is the contract and the single source of truth for which tools exist.

### Routing and decisions inside `mcpDispatcher`

```mermaid
flowchart TD
    IN["POST /mcp/messages"] --> M{"POST?"} -->|no| E405["HTTP 405"]
    M -->|yes| PARSE["JSON-RPC parsing<br/>failure → -32700"]
    PARSE --> AUTH{"valid credential?"} -->|no| E401["HTTP 401 · -33001"]
    AUTH -->|yes| SW{"method"}
    SW -->|tools/list| LIST["Catalog filtered by API key"]
    SW -->|initialize · ping| LOCAL["Answered locally by the gateway<br/>MCP handshake"]
    SW -->|"notifications/*"| NOTIF["HTTP 202, no body<br/>notifications get no response"]
    SW -->|anything else| DEF["-32601 method not supported"]
    SW -->|tools/call| CALL["Security and proxy pipeline"]

    CALL --> C1{"tool in the catalog?"} -->|no| E1["-32601"]
    C1 -->|yes| C2{"allowed for this API key?"} -->|no| E2["-32001 · HTTP 403"]
    C2 -->|yes| C3{"within the rate limit?"} -->|no| E3["-32029 · HTTP 429"]
    C3 -->|yes| C6{"arguments valid<br/>against inputSchema?"} -->|no| E4["-32602"]
    C6 -->|yes| MAP["Translate name and arguments<br/>to the backend contract"]
    MAP --> C4{"mock enabled?"}
    C4 -->|yes| MK["Mock server, MCP context<br/>answers from the spec examples"]
    C4 -->|no| C5{"security.type = OAuth2?"}
    C5 -->|yes| T["getBackendToken — cache or /oauth2/token"]
    C5 -->|no| P["Proxy to the backend<br/>Authorization only if a token was obtained"]
    T --> P
    P --> ST{"backend status"}
    ST -->|200| R["MCP response relayed to the agent"]
    ST -->|401| RT["Refresh the token and retry once"]
    ST -->|">= 400"| EB["-32003 generic + requestId<br/>detail goes to the log only"]
    RT --> ST

    style E4 fill:#fff3cd,stroke:#cc8800
    style EB fill:#fff3cd,stroke:#cc8800
```

### `ots.json` data model

```mermaid
erDiagram
    CONFIG ||--|| OTSGATEWAY : "otsgateway"
    OTSGATEWAY ||--|| AUTH_SERVER : "auth_server"
    MOCKSERVER ||--|| AUTH_SERVER : "auth_server"
    AUTH_SERVER ||--|| INTERNAL_AS : "internal · issues HS256"
    AUTH_SERVER ||--|| EXTERNAL_AS : "external · validates RS256"
    CONFIG ||--o{ PLAN : "plans"
    CONFIG ||--o{ MCP : "mcps"
    CONFIG ||--o{ SUBSCRIPTION : "subscriptions"
    CONFIG ||--|| DASHBOARD : "dashboard"
    CONFIG ||--|| CONSOLE : "console (not implemented)"
    CONFIG ||--|| MOCKSERVER : "mock_server"

    MCP ||--o{ BACKEND_SERVER : "backend_server"
    MCP ||--|| OTS_FILE : "ots_file"
    OTS_FILE ||--o{ TOOL : "tools"
    BACKEND_SERVER ||--|| SECURITY : "security OAuth2"

    SUBSCRIPTION ||--o{ SECURITY_RULE : "security"
    SECURITY_RULE ||--o{ AUTH_METHOD : "auth_method"
    AUTH_METHOD ||--o| API_KEY : "api_key"
    AUTH_METHOD ||--o| OAUTH2_CLIENT : "oauth2"
    OAUTH2_CLIENT }o--|| INTERNAL_AS : "client_secret checked by"
    OAUTH2_CLIENT }o--|| EXTERNAL_AS : "client_id matched from the token"
    SECURITY_RULE ||--|| PLAN : "key_plan"
    SECURITY_RULE ||--o{ MCP_ACCESS : "mcps"
    MCP_ACCESS ||--o{ TOOL : "allowed tools"

    PLAN {
        float rate_per_second "enforced"
        int burst "enforced"
        int quota_hourly "enforced"
        int quota_daily "enforced"
    }
    TOOL {
        string name "key of the tools map"
        string description "the prompt the agent reads"
        object inputSchema "returned and validated"
        object outputSchema "returned, $ref resolved"
        object backend "name and argument mapping"
    }
```

Full identity chain: `auth_method` (an `api_key`, or an `oauth2` client that becomes a token) →
`consumer_name` → `key_plan` → `mcps[].tools[]`. Every credential of a rule lands on the same
consumer, the same plan and the same quota bucket. A tool name must
be **identical** in three places: the key of the `tools:` map in the YAML, the `name:` inside that
tool, and the subscription `tools` list. A mismatch shows up as a confusing `-32601` or `-32001`,
not as a startup error — so the gateway validates it at load time.

### Backend token lifecycle

```mermaid
stateDiagram-v2
    [*] --> NoToken
    NoToken --> Requesting : first tools/call
    Requesting --> Cached : access_token + expires_in
    Requesting --> Failed : network error or HTTP >= 400
    Failed --> NoToken
    Cached --> Cached : reused while now < ExpiresAt
    Cached --> NoToken : expired (60 s safety margin)
    Cached --> Refreshing : backend answers 401
    Refreshing --> Cached : new token, call retried once
```

The cache is keyed by `token_url` + `consumer_key`, is process-wide and lives only in memory: after
a restart the gateway asks for a new token.

---

## Ports and endpoints

| Component | Port | Endpoint | Status |
|---|---|---|---|
| OTS Gateway | 7082 | `POST /mcp/messages` | Implemented — the aggregate endpoint: every MCP behind one address |
| OTS Gateway, per MCP | 7082 | `POST /{context_path}/mcp/messages` | Implemented — the same pipeline narrowed to one MCP. Which of the two an agent should call is *Which endpoint an agent calls*, below |
| Internal authorization server | 7082, or its own port | `POST /oauth/token`, `GET /.well-known/oauth-authorization-server` | Implemented — top-level `auth_server.internal`; shares the gateway port unless `port` moves it, path configurable |
| Protected resource metadata | 7082 | `GET /.well-known/oauth-protected-resource` | Implemented (RFC 9728) — 404 while no `auth_server` half is enabled |
| Mock server | 7083 | `POST {context_path}` of every mock-enabled MCP, plus its own `/oauth/token` and metadata | Implemented — replaces the real backend for the three primitives, answering from the spec examples |
| Governance dashboard | 7085 | `/`, `/mcp/{m}/tool/{n}`, `/mcp/{m}/resource/{n}`, `/mcp/{m}/prompt/{n}`, `/consumers`, `/transactions`, `/api/state` | Implemented — every interface, guarded by `dashboard.access_key` (live, constant time). The short forms `/tool/{n}` and friends still work, and answer 300 with the candidates when the name belongs to two MCPs |
| Configuration console | 7001 | `/`, `POST /apply`, `/plan`, `/subscription`, `/method/add`, `/mcp`, `/reload` | Implemented — every interface, **writes configuration**: guarded by `console.access_key` (live, constant time) |
| MariaDB / MySQL | 3306 | a `backend_server` entry of `type: database` | External — the gateway connects with `database/sql` and the MySQL driver |
| WSO2 APIM (MCP backend) | 8243 | `POST /botibankmcp/1.0/mcp` | External |
| WSO2 IDP (tokens) | 9443 | `POST /oauth2/token`, `/oauth2/revoke` | External |

> The port numbers above, and in the diagrams, are the ones `ots.example.json` ships with. The
> real ones are whatever `ots.json` says — `otsgateway.port`, `mock_server.port`,
> `dashboard.port`, `console.port` and `auth_server.internal.port` — and the startup log prints
> every address it actually binds. `./otsgateway.sh -status` asks the operating system rather than
> the file, which is the answer to trust.

Supported JSON-RPC methods: `server/discover`, `tools/list`, `tools/call`, `resources/list`,
`resources/templates/list`, `resources/read`, `prompts/list`, `prompts/get`,
`subscriptions/listen`, `tasks/get`, `tasks/update`, `tasks/cancel`, plus `initialize` and `ping`
for agents of the earlier era, and `notifications/*` (accepted with 202 and no body, as JSON-RPC
requires). Anything else gets a clean `-32601`.

**How a credential travels.** An OAuth 2.1 token goes in `Authorization: Bearer …` and an API key
in `X-API-Key` — and an **API key sent as a bearer token is also accepted**, because most MCP
clients have one "API key" field and put whatever is in it into `Authorization`. A bearer that is
three dot-separated parts is validated as a JWT; anything else is tried as an API key, in constant
time. It is the same secret over the same channel, so refusing it only produced a good error
message about something that did not need to fail.

Status codes: 401 without a valid credential — with `WWW-Authenticate` for both the bearer token and
the API key — 403 without permission on the tool, the resource or the prompt, or without the scopes
the tool demands, 429 when the plan is exceeded, 405 if the method is not POST, 501 when a resource
or a prompt has neither an example nor a backend to answer it, 502 if the target MCP fails, and 200
with the error inside the JSON-RPC body for protocol-level errors (`-32601`, `-32602`).

## Which endpoint an agent calls

There are two, and both are the whole gateway — same credential, same allowlist, same scopes, same
plan, same trace. What changes is **how much of the catalogue the agent can see**.

```
POST /mcp/messages                  every MCP the subscription allows
POST /{context_path}/mcp/messages   that MCP alone
```

With a single MCP configured the two answer identically, which is why the distinction only starts
to matter the day there is a second one. Nothing about a call changes: the same `tools/call` works
through either.

| Use | When |
|---|---|
| the **aggregate** endpoint | an agent that should see everything its subscription allows, without knowing how you have split it internally. This is the normal way to configure an MCP host, and it means adding an MCP later needs no change on the agent's side |
| a **per-MCP** endpoint | you want that agent to see one MCP and no more, or you need to disambiguate a tool name two MCPs both declare. It is also the honest answer for a third party you do not want browsing the rest of the catalogue |

The `context_path` of an MCP is what builds its address, and it is resolved per request: an MCP
added from the console answers on its own endpoint on the next call, with no restart.

### What differs, apart from the catalogue

Only the errors, and only to be more useful:

- A **context nobody declares** is `404`. Saying the address is wrong beats serving an empty
  catalogue that looks like a permissions problem.
- A tool that **belongs to another MCP**, asked through this one, is refused by name:
  *this endpoint serves the mcp "weather"; the tool "listar_clientes" belongs to "botibank" — use
  its own endpoint or the aggregate one*.
- A name **two MCPs declare** is only ambiguous on the aggregate endpoint, and only for a consumer
  authorised on both — see *Two MCPs, one name*. Through a per-MCP endpoint it cannot be, because
  there is one of it there.

Cases 9.1 to 9.5 of [`MANUAL-TESTS.md`](MANUAL-TESTS.md) walk both endpoints with curl.

## Authenticating agents

Two separate questions, answered in two different places:

| Question | Where it is answered |
|---|---|
| Who may issue and validate tokens? | `auth_server`, a **top-level block** of `ots.json` |
| Which credential may **this** consumer use? | `auth_method` of its own subscription |

```json
{
  "otsgateway":  { "server_port": "7082", … },
  "auth_server": { "internal": { … }, "external": { … } },
  "mock_server": { "server_port": "7083", "auth_server": { … } }
}
```

`auth_server` is a sibling of `otsgateway`, not a field inside it: the authorization server is not a
property of one listener. The gateway runs under it, and every other listener inherits it —
`mock_server` being the one that can override it with a block of its own, to stay open locally or to
demand its own tokens with its own secret.

That split is deliberate. A gateway serves consumers of different kinds at once — a server-side agent
that only ever holds an API key, and a standard MCP client that can only do OAuth — and each one
should be described where it lives, in its own subscription.

```json
"subscriptions": [{
  "consumer_name": "c0",
  "security": [{
    "auth_method": [
      { "api_key": "default-key-1235" },
      { "oauth2": { "client_id": "agente-ventas", "client_secret": "env:AGENTE_SECRET" } }
    ],
    "key_plan": "free",
    "mcps": [{ "botibank": { "tools": ["listar_clientes", "consultar_cuentas"] } }]
  }]
}]
```

Both credentials are the same consumer: same plan, same rate limit, same quota bucket, same
allowlist. The dashboard records which one each transaction used (`via api_key`, `via oauth2`,
`via oauth2-external`).

### The `auth_method` of a subscription, form by form

`auth_method` is the list of credentials one consumer may come in with. **One entry per credential,
at least one**, and every entry shares the subscription: the same allowlist, the same plan, the same
quota. What changes is how the agent gets in.

```jsonc
"auth_method": [
  { "api_key": "default-key-1235" },                     // the literal value
  { "api_key": "sha256:9f3a…:7c21…" },                   // hashed: compared, never recovered
  { "api_key": "env:AGENT_KEY" },                        // the value lives in secrets.json
  { "api_key": "env:AGENT_KEY", "scopes": ["bank"] },    // and the scopes the key presents
  { "oauth2": { "client_id": "agente-ventas",
                "client_secret": "env:AGENTE_SECRET" } } // an OAuth2 client
]
```

| Form | What it is for |
|---|---|
| `"api_key": "<literal>"` | development, and the examples in this documentation. It is a secret written into a file that gets committed |
| `"api_key": "sha256:<salt>:<digest>"` | production. `./otsgw -hash 'the-key'` prints the stored form, and the console writes it directly when `console.hash_new_credentials` is on. It can be regenerated, never read back |
| `"api_key": "env:NAME"` | production too, when the value has to stay readable — an integration you did not issue. The value lives in `secrets.json` |
| `+ "scopes": [...]` | **required whenever a tool, resource or prompt declares `security`.** Without it the allowlist may permit the element and the contract still refuse it with `403 insufficient_scope`: an API key does not skip the scope gate, it carries scopes |
| `"oauth2": { … }` | an agent that asks the internal authorization server for a token, or one that arrives with a token from an external provider — in which case declare the `client_id` and no secret, because a resource server never sees one |

The key travels in `X-API-Key` **or** as `Authorization: Bearer`, so a client with a single "API
key" field works either way. The `client_secret` of an `oauth2` entry takes the same three forms as
an `api_key`.

Two rules the loader enforces: **the same `api_key` on two consumers is refused** — one credential
identifies one consumer, or the quota and the trace mean nothing — and a rule with an empty
`auth_method` is refused too, because it is a subscription nobody can use and nobody can fix from
the console.

### The two halves of `auth_server`

```mermaid
flowchart LR
    subgraph AGENTS["Agents"]
        A1["Server-side agent<br/>X-API-Key"]
        A2["Agent with client_id<br/>+ client_secret"]
        A3["MCP client<br/>Claude · VS Code · Cursor"]
    end

    subgraph GW["OTS Gateway :7082"]
        TOK["POST /oauth/token<br/>client_credentials<br/>HS256 · bot detection"]
        VAL["Credential validation<br/>HS256 internal · RS256 external<br/>exp · nbf · iss · aud"]
        SUB["Resolve the subscription<br/>api_key or client_id -> consumer"]
        MCP["POST /mcp/messages"]
    end

    IDP["External provider<br/>Asgardeo · WSO2 IS · Entra ID"]

    A1 -->|X-API-Key| VAL
    A2 -->|1 . credentials| TOK
    TOK -->|2 . Bearer HS256| A2
    A2 -->|3 . Bearer| VAL
    A3 -->|401 + WWW-Authenticate| A3
    A3 -->|token from the provider| IDP
    IDP -->|Bearer RS256| A3
    A3 -->|Bearer| VAL
    IDP -.->|JWKS, cached 5 min| VAL
    VAL --> SUB --> MCP
```

**`internal`** — the gateway is the authorization server. It needs no identity provider: the
`client_id`/`client_secret` of each subscription is enough, and the token it signs with `jwt_secret`
is the one it later verifies. It is to authentication what the mock is to the backend: the piece that
lets a developer work alone.

It shares the gateway port by default, which is the simplest thing to run and breaks nothing — the
discovery documents publish absolute URLs, so a client follows them wherever they point. Giving it a
`port` moves the token endpoint and its metadata to a listener of their own, which is worth doing when
the deployment demands it: it is the only door that must answer *before* knowing who is calling, and
the only one a `client_secret` travels through, so on its own port it can be kept on an internal
network, put behind a different WAF, or never published. The protected-resource metadata stays on the
gateway — it describes the resource, which has not moved — and starts pointing
`authorization_servers` at the new address by itself.

**`external`** — the gateway is only a resource server. The token comes from the provider and is
verified against its JWKS, with `iss` and `aud` checked, so a token minted for another resource
cannot open this one. A consumer here needs no `client_secret`: the gateway never sees it, and the
`client_id` inside the token is what identifies the consumer.

Both can run at once. Each token is validated by the half its algorithm belongs to — HS256 is ours,
RS256 is the provider's — and HS256 is refused outright when `internal` is off, which closes the
algorithm-confusion attack.

### How an agent gets in, step by step

Nobody has to be told where to authenticate: the gateway answers a bare request with the address of
its own discovery document, and everything else follows from there.

```mermaid
sequenceDiagram
    autonumber
    participant AG as Agent
    participant RS as OTS Gateway 7082
    participant AS as Authorization server 7086
    participant BE as MCP backend

    AG->>RS: POST /mcp/messages with no credential
    RS-->>AG: 401 · WWW-Authenticate Bearer resource_metadata plus ApiKey realm
    AG->>RS: GET /.well-known/oauth-protected-resource
    RS-->>AG: resource plus authorization_servers
    AG->>AS: GET /.well-known/oauth-authorization-server
    AS-->>AG: token_endpoint plus grant_types_supported
    AG->>AS: POST /oauth/token · client_credentials · client_id and client_secret
    Note over AS: bot detection per client and per IP<br/>secret compared in constant time<br/>scopes taken from the subscription and the OTD
    AS-->>AG: access_token HS256 · expires_in · scope
    AG->>RS: POST /mcp/messages · Authorization Bearer
    Note over RS: signature · exp · nbf · iss · aud<br/>subject to subscription<br/>allowlist · scopes · plan
    RS->>BE: tools/call translated plus the backend token
    BE-->>RS: result
    RS-->>AG: result with the output contract applied
```

Steps 2 to 6 are what a standard MCP client does on its own, and what an agent of your own can skip
entirely: it already knows the token endpoint, so it starts at step 7. With `auth_server.internal.port`
empty, the *Authorization server* column is the gateway itself and steps 5 to 8 travel to port 7082 —
nothing else changes.

With `external` instead of `internal`, steps 5 to 8 happen against your identity provider, the
gateway never sees the `client_secret`, and step 3 advertises that provider as the
`authorization_server`.

### What the gateway does with the credential it receives

Authentication answers *who is calling*; four more gates decide *whether this call happens*. They run
in this order on purpose: the cheap checks first, and nothing reaches the backend that has not passed
all of them.

```mermaid
flowchart TD
    IN["Request on /mcp/messages"] --> BEARER{"Authorization Bearer?"}

    BEARER -->|no| KEY{"X-API-Key present?"}
    KEY -->|no| C401["401 · WWW-Authenticate<br/>Bearer + ApiKey"]
    KEY -->|yes| KMATCH{"declared in some<br/>auth_method?"}
    KMATCH -->|no| C401
    KMATCH -->|yes| ID["Identity · via api_key<br/>with the scopes declared next to the key"]

    BEARER -->|yes| ALG{"alg of the token"}
    ALG -->|"HS256"| INT{"internal<br/>enabled?"}
    ALG -->|"RS256"| EXT{"external<br/>enabled?"}
    ALG -->|"none or other"| C401
    INT -->|no| C401
    EXT -->|no| C401
    INT -->|yes| HMAC["HMAC with jwt_secret<br/>iss and aud must be ours"]
    EXT -->|yes| JWKS["RS256 against the JWKS<br/>iss and aud as configured"]
    HMAC --> CLAIMS{"signature, exp, nbf,<br/>iss, aud valid?"}
    JWKS --> CLAIMS
    CLAIMS -->|no| C401
    CLAIMS -->|yes| SUBJ{"subject declared in<br/>some auth_method?"}
    SUBJ -->|no| F403["403 · valid token,<br/>no subscription"]
    SUBJ -->|yes| ID2["Identity · via oauth2<br/>with the scopes of the token"]

    ID --> ALLOW{"element in the<br/>allowlist of its kind?"}
    ID2 --> ALLOW
    ALLOW -->|no| F403B["403 · -33002"]
    ALLOW -->|yes| SCOPE{"scopes the OTD<br/>demands?"}
    SCOPE -->|missing| F403C["403 · insufficient_scope<br/>naming what is missing"]
    SCOPE -->|satisfied| RATE{"rate limit<br/>of the plan?"}
    RATE -->|exceeded| R429["429 · Retry-After"]
    RATE -->|ok| QUOTA{"hourly and daily<br/>quota?"}
    QUOTA -->|exhausted| Q429["429 · quota"]
    QUOTA -->|ok| GO["Validate arguments,<br/>translate and proxy"]
```

Three things worth reading off that diagram. **The scope gate applies to every credential**, an API
key included: a key carries the scopes declared next to it in its `auth_method` entry, and a key
with none satisfies only the elements whose contract demands none. **The gate is the same for the
three primitives** — a tool, a resource and a prompt each demand what their own `security` block
says, falling back to the document one. And the rate limit and the quota are charged to the
**rule**, not to the credential: the same consumer coming in with its key or with its token spends
from one bucket.

### Getting in

```bash
# 1 · with an API key, nothing changes
curl -s -X POST http://localhost:7082/mcp/messages \
  -H 'X-API-Key: default-key-1235' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'

# 2 · with a token issued by the gateway itself
TOKEN=$(curl -s -X POST http://localhost:7082/oauth/token \
  -d 'grant_type=client_credentials&client_id=agente-ventas&client_secret=…' \
  | python3 -c 'import sys,json;print(json.load(sys.stdin)["access_token"])')

curl -s -X POST http://localhost:7082/mcp/messages \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'

# 3 · what a standard MCP client does on its own
curl -si -X POST http://localhost:7082/mcp/messages -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
# HTTP/1.1 401 Unauthorized
# Www-Authenticate: Bearer resource_metadata="http://localhost:7082/.well-known/oauth-protected-resource"
# Www-Authenticate: ApiKey realm="ots-gateway", header="X-API-Key"
```

The scopes in the token are not configured by hand: they are the union of what the **OTD** demands
for the tools, resources and prompts that subscription allows, so a token never claims more than the
allowlist grants — and a scope that only a resource demands is issuable, which it would not be if
only tools were walked. A client can be capped further with `oauth2.scopes`, or narrow itself per
request with `&scope=…`. A credential that falls short of what an element demands gets `403` with
`WWW-Authenticate: Bearer error="insufficient_scope", scope="bank:transfer:execute"` and the missing
scopes in `error.data.requiredScopes`.

An **API key declares its scopes in the subscription**, because a key has nowhere else to carry
them:

```json
"auth_method": [
  { "api_key": "env:AGENT_KEY", "scopes": ["bank:accounts:read"] },
  { "oauth2": { "client_id": "agente-ventas", "client_secret": "env:AGENT_SECRET" } }
]
```

**And the catalogues filter by scope.** `tools/list`, `resources/list`,
`resources/templates/list` and `prompts/list` return only what that credential could actually use:
the allowlist of its kind **and** the scopes of the contract. Listing what would be refused only
invites the refusal, and it lets a token narrow its own catalogue by asking for fewer scopes. The
loader helps here too: if a subscription allows an element whose contract demands scopes its
`api_key` does not declare, it says so by name at startup instead of leaving a permission that
always ends in a 403.

Full field reference: [`CONFIGURATION.md`](CONFIGURATION.md#auth_server--who-issues-and-who-validates-the-tokens).

---

## Implementation status

| Capability | Status |
|---|---|
| Agent authentication per consumer (`auth_method`) | Implemented — API key and/or OAuth2 client, declared in the subscription; 401 with both challenges when the credential is missing |
| Internal authorization server (`client_credentials`, HS256, RFC 8414) | Implemented — `auth_server.internal`, scopes derived from the subscription, bot detection on the token endpoint |
| Credential storage | Implemented — a credential field takes a literal, `env:NAME` or `sha256:<salt>:<digest>`; hashes are compared in constant time, the console can store them from the outset (`console.hash_new_credentials`) and `-hash` produces one for a file edited by hand |
| Per-tool authorisation (allowlist) | Implemented, `*` supported; 403 when not allowed |
| The three MCP primitives (`tools`, `resources`, `prompts`) | Implemented — declared in the OTS spec, authorised by three independent lists per subscription, mocked, relayed to the backend and measured |
| Rate limiting per API key and plan | Implemented (token bucket), 429 with `Retry-After` |
| Hourly and daily quotas | Implemented — current-hour and current-day windows, 429 when exhausted |
| MCP handshake (`initialize`, `ping`, `notifications/*`) | Implemented |
| `tools/list` with `inputSchema` and `outputSchema` | Implemented — agents can build arguments and know the shape of the answer |
| Request and response examples in the spec | Implemented — `inputSchema.example` for the request, `example` / named `examples` with `input` + `value`/`error` for the response |
| `$ref` resolution against the spec `components` | Implemented — schemas travel resolved, agents never receive a reference they cannot follow |
| Argument validation against the spec | Implemented — required fields, undeclared fields and primitive types |
| OTS → backend translation (`backend.tool` / `backend.arguments`) | Implemented |
| MCP 2026-07-28 revision | Implemented alongside the legacy era — see *MCP protocol support* |
| `server/discover`, `resultType`, per-request `_meta`, mirrored-header validation | Implemented |
| `subscriptions/listen` (`toolsListChanged`, `resourcesListChanged`, `promptsListChanged`) | Implemented — SSE stream, acknowledged first, keep-alives, and one notification only for the catalog that actually changed |
| Tasks extension (`io.modelcontextprotocol/tasks`) | Implemented as a governed proxy: quota on the call, ownership on every poll |
| Streaming relay (SSE from the backend) | Implemented — an answer in `text/event-stream` is copied event by event with a flush, so progress arrives while the work happens; notifications travel untouched, the result is stamped and filtered by the output contract, and the agent hanging up cancels the backend |
| `x-mcp-header` mirroring towards the backend | Implemented, with the Base64 sentinel |
| Output contract: masking, projection and validation | Implemented — `x-ots-mask` in the `outputSchema`, policy per MCP, `max_bytes` cap, and every relayed result marked `ots/untrusted` for the host |
| CORS for browser agents | Implemented, off by default (`otsgateway.cors.enabled`) — covers the MCP endpoint, the token endpoint and both discovery documents |
| OAuth 2.1 resource server (RFC 9728, audience binding, `insufficient_scope`) | Implemented — `auth_server.external` for provider tokens, `auth_server.internal` for its own |
| Scopes from the OTS `security` block, on the three primitives | Implemented — `security` per tool, resource and prompt with the document-level fallback; enforced on every credential, an API key included (`auth_method[].scopes`); the four catalogues filter by scope; 403 naming what is missing |
| `tools/list` pagination, `icons`, tool-name rules | Implemented |
| Mirrored-header validation (`Mcp-Param-*`) | Implemented — `-32020` on mismatch |
| Per-tool backend selection (`server` in the spec) | Implemented — the tool block wins, then the document `servers`, then the first backend |
| OAuth2 client credentials to the backend | Implemented, cached per backend with a transparent retry on 401 |
| Failover between backend addresses | Implemented — `replicas` per `backend_server` entry, tried on a transport failure or a 502/503/504; always for reads, and for a `tools/call` only when the tool declares `idempotent: true` |
| Backend error isolation | Implemented — detail to the log, the agent gets `-32003` with a `requestId` |
| Per-transaction traceability | Implemented — step-by-step pipeline and the four payloads, secrets masked |
| History and quotas surviving a restart | Implemented — JSONL journal replayed at startup |
| Governance dashboard | Implemented — catalog, per-consumer usage and full traces |
| Mock mode | Implemented — the mock server serves one context per mock-enabled MCP from the spec examples, with `mock.delay_ms` and error scenarios |
| TLS to the backend | Verification on by default; `tls_skip_verify` per backend for local environments |
| Configuration validation at startup | Implemented — unknown plans, empty or duplicated API keys and unreadable specs abort the boot |
| Graceful shutdown and server timeouts | Implemented |
| Context budget per plan (LLM tokens) | Implemented — `tokens_hourly`, `tokens_daily` and `max_tokens_per_call`, checked before the work and charged with what was served; an estimate of four bytes to a token, labelled as one everywhere |
| Backend of type `database` | Implemented — a `backend_server` entry runs a SQL query and the rows become an MCP result, with both schemas mandatory so the contract is identical to an MCP-served tool. MariaDB and MySQL; see *A tool served by a SQL query* |
| Multi-MCP | Implemented — each MCP has its own endpoint from its `context_path`, the aggregate one keeps serving all of them, and the registries are keyed by `(mcp, name)`, so two MCPs may declare the same tool, resource or prompt name; see *Two MCPs, one name* |
| Configuration console | Implemented — edits `ots.json` and applies it live |
| Hot reload of `ots.json` | Implemented — atomic snapshot swap, no restart |

## Resources and prompts: governing the other two MCP primitives

### The problem

MCP defines **three** server primitives, and they are not variations of one another — each is
decided by a different actor:

| Primitive | Who decides to use it | What it is |
|---|---|---|
| **tools** | the model | an operation it can execute: *list the clients*, *transfer money* |
| **resources** | the host application, by `uri` | data it attaches to the context: a privacy policy, the movements of an account |
| **prompts** | the user, by picking a template | a pre-written interaction: *«monthly summary»*, *«loan guide»* |

Until now the OTS contract only catalogued **tools**. That is not a cosmetic gap: everything this
gateway exists to do — declare, authorise per subscriber, translate to the backend, mock, rate limit
and measure — simply did not exist for the other two. A backend MCP that exposed documents and
prompt templates was consumed **around** the gateway or not at all, and the practical consequences
were concrete:

- a consumer authorised for one harmless tool could read **every document** of that MCP, because
  nothing said otherwise;
- there was no way to declare *«this agent may read the privacy policy but not the movements of an
  account»*;
- reads did not appear in the trace, did not consume quota and did not show up in the dashboard, so
  nobody could answer *«who read what, and when»*;
- and a client that asked `resources/list` got a `-32601`, so a standard MCP client saw a server
  that was half a server.

### The use case, end to end

The support agent of BotiBank. A customer asks *«summarise my account and tell me what you do with
my data»*, and answering it needs the three primitives at once:

| Step | Primitive | Element | Where the answer comes from |
|---|---|---|---|
| The user picks the *Monthly Summary* template | prompt | `resumen_mensual` | the `example.messages` of the contract |
| The agent quotes the current legal text | resource | `politica_privacidad` | the `example` of the contract — a document that lives in the spec |
| The agent reads the movements of `CU-001` | resource | `movimientos_cuenta` | **relayed** to the real MCP: the contract only declares the shape |
| The agent lists the client's accounts | tool | `consultar_cuentas` | relayed to the real MCP, as always |

The same request must be refused for a second consumer — an analytics agent, say — that is allowed
`consultar_cuentas` and nothing else. Both consumers hit the same endpoint with the same catalogue
behind it; what separates them is the subscription.

### The solution in one picture

```mermaid
sequenceDiagram
    autonumber
    participant U as User
    participant H as Host / MCP client
    participant GW as OTS Gateway :7082
    participant MK as Mock server :7083
    participant BE as Backend MCP (WSO2)

    U->>H: "Summarise my account and tell me what you do with my data"

    Note over H,GW: 1 · the catalogues, filtered by subscription (free of charge)
    H->>GW: prompts/list · resources/list · resources/templates/list
    GW-->>H: only what c0 is authorised for, with ttlMs + cacheScope: private

    Note over H,GW: 2 · the prompt the user picked
    H->>GW: prompts/get { name: resumen_mensual, arguments: { cuenta_id: "CU-001" } }
    GW->>GW: authorised in the prompts list? · plan quota · required arguments present?
    GW-->>H: messages with {cuenta_id} bound → "Analyse account CU-001…"

    Note over H,GW: 3 · a document the contract itself answers
    H->>GW: resources/read { uri: "ots://botibank/politica-privacidad" }
    GW->>GW: no backend block declared → the example of the spec is the answer
    GW-->>H: contents[0].text = the legal text · ttlMs from cache.ttlMs

    Note over H,BE: 4 · a document that lives in the real MCP
    H->>GW: resources/read { uri: "ots://botibank/cuentas/CU-001/movimientos" }
    GW->>GW: matches the uriTemplate · binds cuentaId = CU-001
    GW->>GW: declares backend.uriTemplate → relay, translate the address
    GW->>BE: resources/read { uri: "mcp://core/accounts/CU-001/tx" }<br/>Authorization: Bearer + MCP-Protocol-Version + Mcp-Method
    BE-->>GW: contents[0]
    GW-->>H: relayed, stamped with resultType, serverInfo and the cache hints

    Note over H,MK: 4' · the same call with mock.enabled on that MCP
    H->>GW: resources/read { uri: "ots://botibank/cuentas/CU-001/movimientos" }
    GW->>MK: resources/read with the OTS uri
    MK-->>GW: the example of the spec, placeholders bound
    GW-->>H: same shape, no real backend touched

    Note over H,GW: 5 · and what the other consumer gets
    H->>GW: resources/read (analytics agent, allowed only consultar_cuentas)
    GW-->>H: HTTP 403 · -33002 "your subscription does not authorise this resource"

    H->>U: the summary, with the policy quoted
```

### Declaring them: the contract

The OTS document gains two blocks that are siblings of `tools`, with the same structure — own name,
description, example, and `backend` to translate to the real one:

```yaml
resources:
  politica_privacidad:
    title: "Privacy Policy"
    description: "Current legal text about data treatment, so the agent can cite it verbatim."
    uri: "ots://botibank/politica-privacidad"     # the uri the agent sees
    mimeType: "text/markdown"
    cache:
      ttlMs: 3600000
    example: |                                    # the contract answers with this
      # Privacy Policy v2.1
      …

  movimientos_cuenta:
    title: "Account Movements"
    description: "Detailed list of the transactions of one account, newest first."
    uriTemplate: "ots://botibank/cuentas/{cuentaId}/movimientos"
    mimeType: "application/json"
    backend:
      uriTemplate: "mcp://core/accounts/{cuentaId}/tx"     # the real MCP answers this one

prompts:
  resumen_mensual:
    title: "Monthly Summary"
    description: "Writes an executive summary of the monthly spending of one account."
    arguments:
      - name: "cuenta_id"
        description: "The account to summarise"
        required: true
    example:
      messages:
        - role: "user"
          content: { type: "text", text: "Analyse account {cuenta_id} and summarise it." }
```

A `{placeholder}` in a `uriTemplate` never spans a `/`, so one uri can never match two different
resources, and the binding is applied to the body too: `{cuenta_id}` inside an `example` is
substituted with what the caller sent.

### Governing them: three independent lists

The subscription goes from one list to three, and **what is not declared cannot be used**:

```json
"mcps": [{
  "botibank": {
    "tools":     ["listar_clientes", "consultar_cuentas"],
    "resources": ["politica_privacidad", "movimientos_cuenta"],
    "prompts":   ["resumen_mensual"]
  }
}]
```

- **Independent on purpose.** Authorising a tool grants neither the documents nor the prompt
  templates of the same MCP. That is the whole point: reading *«the movements of any account»* is not
  the same permission as *«list the clients»*.
- **Deny by default.** An absent list means *none allowed*, never *all*. A `ots.json` written
  before these existed therefore behaves exactly as it did.
- **`["*"]`** allows every element of that kind in that MCP, including the ones its spec gains
  tomorrow. The console offers it as a checkbox of its own, so saving a subscription never silently
  rewrites a wildcard into a literal list.
- What is not authorised is refused with `-33002` and HTTP 403, **and does not appear** in the
  corresponding list method either — a consumer cannot even see the name of what it cannot use.

### Answering them: mock, backend or contract

Three possible sources, decided in this order:

```mermaid
flowchart TD
    A["resources/read · prompts/get"] --> B{"the MCP has mock.enabled?"}
    B -- yes --> M["mock server<br/>answers from the spec examples"]
    B -- no --> C{"the primitive declares a backend block?"}
    C -- yes --> R["relay to the backend MCP<br/>uri / prompt name translated<br/>OAuth2 token + one retry on 401"]
    C -- no --> D{"does it declare an example?"}
    D -- yes --> E["the contract answers<br/>placeholders bound"]
    D -- no --> F["HTTP 501<br/>and a warning by name at startup"]
```

**Declaring `backend:` is what turns a resource or a prompt into a relayed one.** That single rule
keeps the change additive — nothing that already answered from its example changed its answer — and
it gives a meaning to a block that until now was only documentation:

| Declared | Sent to the backend |
|---|---|
| `backend.uri` / `backend.uriTemplate` | the translated uri, with the placeholders bound: `ots://botibank/cuentas/CU-001/movimientos` → `mcp://core/accounts/CU-001/tx` |
| `backend.prompt` | the real name: `guia_creditos` → `loan_guide` |
| `backend.arguments` | the renamed arguments, `destination: origin` as in a tool: `{perfil_riesgo: "bajo"}` → `{riskProfile: "bajo"}` |
| nothing | the address or the name of the contract travels unchanged |

The relay is the `tools/call` one minus what only tools have: there is no `outputSchema` to enforce,
no `x-mcp-header` to mirror and no task to intercept, because neither method can create one. What it
does keep is the OAuth2 token of its `backend_server`, the transparent retry on a 401, the version
bridge headers, the `_meta` of the agent passed through untouched, and the rule that a failing
backend becomes a generic error whose detail stays in the gateway log.

A primitive that declares **neither an example nor a backend** cannot be answered by anybody: the
loader says so by name at startup and the call gets an HTTP 501 that explains it, instead of handing
the agent an empty body.

### What it costs, and what it does not

Same criterion as tools — the catalogue is free, the content is charged:

| Method | Authorisation | Rate limit and quota |
|---|---|---|
| `resources/list`, `resources/templates/list` | filters the catalogue by subscription | free: a client that cannot list cannot choose |
| `prompts/list` | filters the catalogue | free |
| `resources/read` | by uri, or by the template it matches | charged |
| `prompts/get` | by name | charged |

The four catalogue-ish results carry `ttlMs` and `cacheScope: "private"`, private because each
catalogue is filtered by the caller's subscription. `ttlMs` comes from the `cache.ttlMs` the spec
declares: the shortest among what that consumer can see for a list, its own for a read, and on a
relayed answer the gateway stamps it only if the backend did not.

### What it looks like once it runs

**Every transaction says which primitive it served.** The journal line carries a `kind` of `tool`,
`resource` or `prompt` — lines written before the field existed are read as `tool` — and the
counters are namespaced by kind, so a tool and a resource that share a name never add up their
metrics.

```
resource resolution   mcp botibank · movimientos_cuenta · answered by the backend
authorization         subscription allowlist: allowed
rate limit            within the free plan
plan quota            hour 2/100 · day 2/200
backend mapping       ots://botibank/cuentas/CU-001/movimientos → mcp://core/accounts/CU-001/tx
target                backend https://localhost:8243/botibankmcp/1.0/mcp
backend token         reused from cache (OAuth2 client_credentials)
MCP call              HTTP 200 from https://localhost:8243/botibankmcp/1.0/mcp
response to agent     relaying the MCP response
```

**The dashboard has a page per element**: `/resource/{name}` shows the uri or the template with its
variables, the mime type, the cache ttl, who answers it, the body declared in the spec and **who has
read it**; `/prompt/{name}` shows the arguments and which are required, the mapping to the backend
and the messages of the spec. The catalogue home and each MCP page carry one table per primitive,
and a consumer's page shows the three allow lists apart from each other.

**The capabilities are announced honestly.** `initialize` and `server/discover` declare `resources`
and `prompts` only when the live spec actually contains some: a client that sees the capability will
call the list method behind it, and an empty catalogue there is worse than no capability at all.

**Changes are notified per catalogue.** `subscriptions/listen` acknowledges `toolsListChanged`,
`resourcesListChanged` and `promptsListChanged`, and on every configuration publish the gateway
fingerprints exactly what each list method hands out. Editing a resource notifies the resource
subscribers and nobody else; changing a plan notifies nobody.

### Errors, in one table

| Situation | Answer |
|---|---|
| A uri no resource serves | `-32602` *no resource of this gateway serves "…"* |
| A prompt name that does not exist | `-32602`, HTTP 404 |
| A required argument the call does not provide | `-32602` with `data.missingArguments: ["cuenta_id"]` |
| Not in the subscription | `-33002`, HTTP 403, and invisible in the list method |
| Neither example nor backend to answer with | HTTP 501, plus a warning by name at startup |
| The backend rejects the relayed call | `-33005`, HTTP 502; the backend detail stays in the log |
| An invalid credential | HTTP 401, before reaching any registry |

### Where the rest of it is documented

- [`OTD-REFERENCE.md`](OTD-REFERENCE.md) — the two blocks field by field, and what the loader
  refuses or warns about
- [`CONFIGURATION.md`](CONFIGURATION.md) — the three lists of a subscription and the wildcard
- [`MANUAL-TESTS.md`](MANUAL-TESTS.md) — block 5 and block 9, curl by curl, with what each one proves
- [`RESOURCES-AND-PROMPTS-WALKTHROUGH.md`](RESOURCES-AND-PROMPTS-WALKTHROUGH.md) — the quick walk-through
- [`designs/seq_resources_prompts_en.html`](designs/seq_resources_prompts_en.html) — the use case
  above as a standalone diagram, side by side with what it looked like without governance

## Two MCPs, one name

### The problem

A gateway whose reason to exist is fronting **somebody else's** MCPs does not get to choose what
they call their tools. `search`, `get_users`, `create_ticket` — two vendors will pick the same name,
and until 2026-09-08 that aborted the boot:

```
❌ tool "get_users" is declared in two MCPs (crm and billing): names must be unique
```

The only way out was renaming it in the OTS spec, which breaks the contract the backend actually
serves. So the three registries are now keyed by **`(mcp, name)`**, and a repeated name is a
warning, not a failure:

```
⚠️ the tool "consultar_cuentas" is declared by botibank and by weather: a call naming it
   resolves through the subscription, or through the endpoint of one of them
```

### How a name resolves

Three cases, in this order. Most ambiguity never reaches the agent.

```mermaid
flowchart TD
    A["tools/call · resources/read · prompts/get<br/>with a name"] --> Z{"does any MCP declare<br/>that exact name?"}
    Z -- "no, but it reads as mcp.name" --> Q["that MCP<br/>the qualified form the catalogue advertised"]
    Z -- yes --> B{"came through<br/>/{context_path}/mcp/messages ?"}
    B -- yes --> C["that MCP<br/>unambiguous by construction"]
    B -- no --> D{"how many MCPs<br/>declare the name?"}
    D -- one --> E["that one<br/>every configuration that works today"]
    D -- several --> F{"how many does this<br/>subscription allow?"}
    F -- one --> G["that one<br/>the subscription is already per MCP"]
    F -- several --> H["409 · -32602<br/>name it mcp.name, or use the MCP's endpoint"]
```

The third case is the one worth noticing: a subscription is written per MCP already
(`{"botibank": {…}}, {"weather": {…}}`), so a consumer authorised on only one of the two homonyms
resolves without knowing anything happened. Only a consumer authorised on **both** has a real
ambiguity — and it is the one consumer that can resolve it.

### The qualified name

Resolution is only half of it. If two entries of an aggregate `tools/list` are both called
`consultar_cuentas`, no MCP client can address either one. So a catalogue qualifies a name **its own
listing repeats**, and accepts that form back on the call:

```
tools/list  →  botibank.consultar_cuentas
               consultar_tiempo
               listar_clientes
               listar_servicios
               weather.consultar_cuentas
```

Note what stays bare. `consultar_tiempo` is unique in this listing, so it is listed plainly — and
so is *every* name for a consumer authorised on only one of the homonyms, and every name on a
per-MCP endpoint, whose listing is one MCP by construction. **The qualified form appears exactly
where the ambiguity is real**, and nowhere else, so no existing agent sees its catalogue change.

The separator is a dot because that is already the shape of an allowlist entry and of a console
checkbox key. The bare name is always tried first, so a primitive whose own name contains a dot
keeps resolving to itself.

Naming an ambiguous name bare is not an error the agent has to guess its way out of — the answer
carries both remedies, leading with the one it already holds:

```json
{"code": -32602, "message": "the tool \"consultar_cuentas\" is declared by more than one mcp
 (botibank, weather) and your subscription allows it in several: name it
 \"botibank.consultar_cuentas\" or \"weather.consultar_cuentas\", as the catalogue lists it, or
 call the endpoint of the one you mean, /{context_path}/mcp/messages"}
```

### A name may repeat; an address may not

One check did not disappear, it moved. MCP addresses a resource by **uri** — the name is an OTS
courtesy — and a uri carries no MCP, so two resources sharing one would be an ambiguity with no way
to resolve it. Uri uniqueness is therefore a startup failure, where name uniqueness used to be:

```
❌ the uri "ots://botibank/politica-privacidad" is declared by weather.politica_privacidad and by
   botibank.politica_privacidad: a name may repeat across MCPs, an address may not
```

Which is also why `resources/read` by uri never needs disambiguating, and by name sometimes does.

### What it changes elsewhere

`weather-ots.yaml` in this repository is that second MCP: it declares the three homonyms of
`boti-bank-ots.yaml` plus one unique tool, so the collision path is exercised on purpose rather than
the day a customer hits it. Block 9 of [`MANUAL-TESTS.md`](MANUAL-TESTS.md) has the two JSON blocks
that wire it in, and cases 9.11 to 9.22 that prove it.

| Surface | What it looks like |
|---|---|
| Per-MCP endpoint | Unchanged, and now the fastest answer to any ambiguity: its catalogue is one MCP, so every name in it is bare and every call in it is unambiguous |
| Dashboard | The canonical url is `/mcp/{mcp}/tool/{name}`, and the same for resources and prompts. `/tool/{name}` still resolves while the name belongs to one MCP, and answers **300 Multiple Choices** with the candidates as links when it does not — the name is right, it is the url that is missing the MCP |
| Per-consumer counters | `botibank.consultar_cuentas` and `weather.consultar_cuentas` are two rows on the consumer page, with their own calls, errors and latency |
| Console | Nothing changed: its checkbox keys were already `mcp.name`, so the two homonyms have always been two separate checkboxes |
| Mock server | Nothing changed: it resolves per context path, so it never saw a name from another MCP |
| Subscriptions | Nothing changed: an allowlist is written per MCP already |

## The `backend:` block of the OTS spec

This is what turns OTS into a contract layer instead of a plain passthrough: the agent sees the OTS
catalog names even when the target MCP uses different ones.

```yaml
transferir_dinero:
  name: "transferir_dinero"
  backend:
    tool: "post_cuentas_by_cuentaId_transferir"   # real name in the MCP
    arguments:                                    # destination: source
      cuentaId: "cuenta_origen"
      "requestBody.cuentaDestino": "cuenta_destino"
      "requestBody.monto": "monto"
      "requestBody.concepto": "concepto"
```

- `backend.tool` — the tool name in the target MCP. If omitted, the OTS name is used as is.
- `servers[].protocol` — the transport. `streamable-http` is the current one; `sse` names the
  HTTP+SSE transport deprecated since 2025-03-26 and produces a warning at load; `stdio` is refused
  because the gateway can only reach HTTP backends.
- `backend.arguments` — maps *destination: source*. The key accepts dotted paths for nesting, which
  covers the `requestBody` wrapper generated by MCP servers created from a REST API.
- With no `arguments`, the agent arguments are forwarded untouched. With `arguments`, only what is
  mapped is forwarded: nothing the contract does not declare reaches the backend.

### Choosing the backend per tool

An MCP can declare several backends in `ots.json`, and the spec decides which one serves each
tool through its `servers` block. The contract picks the destination, the configuration keeps the
credentials:

```json
"backend_server": [
  { "url": "https://localhost:8243/botibankmcp/1.0/mcp", "security": { … } },
  { "url": "https://localhost:8243/botibankext/1.0/mcp", "security": { … } }
]
```

```yaml
# document level: the default for every tool of this spec
servers:
  - protocol: sse
    url: "https://localhost:8243/botibankmcp/1.0/mcp"

tools:
  listar_clientes:
    # this tool only: it overrides the default
    server:
      - protocol: sse
        url: "https://localhost:8243/botibankext/1.0/mcp"
```

Note the keys: **`servers`** at document level, because it lists the defaults for the whole spec,
and **`server`** inside a tool, because it names the one that serves that tool. A tool still using
the plural key is reported at load time instead of being silently ignored.

Resolution happens once, at load time, in this order:

| Order | Where the url comes from | Result |
|---|---|---|
| 1 | The tool's own `server` | that backend serves this tool |
| 2 | The document-level `servers` | the default for every other tool |
| 3 | Neither | the first `backend_server` of the MCP |

A url that matches no `backend_server` **rejects the configuration** naming the tool and the url:
routing the call to a different backend without saying so would be worse than refusing to start.
Matching ignores the trailing slash.

Each backend keeps its own credentials, its own TLS flag and its own token, cached by
`token_url` + `consumer_key` — two tools on different backends never share a token unless the
credentials are genuinely the same.

**This does not apply to the mock.** With `mock.enabled` every tool of that MCP answers from the
mock server context, uniformly: the mock replaces the whole MCP, not one backend of it. The
resolution stays declared and shown in the dashboard, ready for when the mock goes off.

The dashboard shows it: the tool page says `served by <url>` with a badge telling whether the
decision came from the tool block, the document one or the default, and the MCP page has a
**Served by** column per tool.

### Schemas

Both `inputSchema` and `outputSchema` are read from the spec, shown on the tool page of the
dashboard and returned in `tools/list` — `outputSchema` only when the contract declares it, as the
MCP 2025-06-18 revision defines it as optional. `inputSchema` is additionally enforced on every
call: required fields, undeclared fields when the schema is closed, and primitive types.

`$ref` pointers to `#/components/schemas/...` are **resolved at load time**, so what reaches the
agent is a self-contained schema:

```yaml
# in the spec
outputSchema:
  type: "object"
  properties:
    clientes:
      type: "array"
      items:
        $ref: "#/components/schemas/Cliente"
```

```json
// what tools/list returns
{"type":"object","properties":{"clientes":{"type":"array","items":{
  "type":"object","properties":{
  "id":{"type":"string"},"nombre":{"type":"string"},
  "apellido":{"type":"string"},"email":{"type":"string"}}}}}}
```

The `components` block never travels to the agent, so an unresolved reference would be useless to
it. Anything that cannot be resolved is left as written and logged as a warning at startup.

#### An outputSchema is always an object, and a list travels wrapped

MCP types `structuredContent` as an **object**, and requires it to be **present** whenever the tool
declares an `outputSchema`. The two rules together leave no room for a top-level list, so an
`outputSchema` of `type: array` is **refused at load time** — the reload does not go live and the
error names the tool. A client that validates its results reports one of these two symptoms:

```
ValidationError: … structuredContent  Input should be a valid dictionary [input_type=list]
RuntimeError: Tool consultar_cuentas has an output schema but did not return structured content
```

The fix is the wrapped form shown above. Once the contract declares it, the gateway does the rest:
a backend that answers with a bare list — and a database tool, whose answer is always rows — has it
placed under the property the schema names, so `structuredContent` comes back as
`{"clientes": [ … ]}` with the same JSON in the `text` block. The query is unchanged: a plain
`SELECT` still fills a wrapped schema.

The wrapping only happens when the schema leaves no doubt: an object whose **only** property is the
array. Anything richer than that — two lists, or a list next to a count — is a shape only the
backend can build, and the answer is passed through as it comes.

### Request and response examples, and the mock

Each tool declares both sides of the exchange: a request that is valid against its `inputSchema`,
and the response it returns. Same shape OpenAPI uses.

```yaml
consultar_cuentas:
  inputSchema:
    type: "object"
    required: ["cliente_id"]
    properties:
      cliente_id:
        type: "string"
        description: "ID del cliente (UUID)"
    example:                      # the request example lives inside the schema
      cliente_id: "71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"
```

The request example sits **inside** the `inputSchema`, exactly where OpenAPI puts it in a Schema
Object. Both spellings are read: `example` (a single value, OpenAPI) and `examples` (a list, JSON
Schema). Because it lives in the schema, it travels to the agent in `tools/list` on its own — OTS
does not need to invent a field for it, and any MCP client already knows how to read it.

Examples are checked against their own schema at load time: one that does not satisfy the contract
it belongs to is reported as a warning in the console and the log.

Then the response, as one inline example:

```yaml
listar_clientes:
  example:
    - id: "71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"
      nombre: "Ana"
      apellido: "García"
```

Or several named scenarios pairing request and response, including failures:

```yaml
transferir_dinero:
  examples:
    default:
      summary: "Transferencia aceptada"
      input:
        cuenta_origen: "CTA-122"
        cuenta_destino: "CTA-999"
        monto: 500.00
        concepto: "Traspaso entre cuentas propias"
      value:
        mensaje: "Transferencia realizada con éxito"
        saldoRestante: 1300.50
    saldo_insuficiente:
      summary: "La cuenta origen no cubre el monto"
      error:
        code: -32000
        message: "Saldo insuficiente en la cuenta"
        data:
          cuenta_origen: "CTA-123"
          saldo_disponible: 100.00
```

### The mock server

Two flags, two different jobs:

| Flag | What it does |
|---|---|
| `mock_server.enabled` | Starts the mock server on `mock_server.server_port` |
| `mcps[].mock.enabled` | Puts that MCP in mock mode: the gateway sends its calls to the mock server instead of the real backend — `tools/call`, `resources/read` and `prompts/get` alike |

The mock server exposes **one context per mock-enabled MCP**, taken from its `context_path`. An MCP
whose `mock.enabled` is false is not served there at all — asking for its context returns a 404 that
says exactly that. And an MCP in mock mode with the mock server disabled is a contradiction, so the
configuration is rejected: either enable the server or turn the mock off.

```
mock_server.server_port: 7083
mcps[0]: { name: botibank, context_path: /botibankots, mock: { enabled: true, delay_ms: 120 } }

POST http://localhost:7083/botibankots            → served from the OTS examples
POST http://localhost:7083/otro-mcp-sin-mock      → 404 "not in mock mode"
```

It behaves like a real MCP server, so you can point the gateway at it — which is what mock mode
does — or call it directly from a test client: it answers `initialize`, `ping`, `tools/list` (with
the schemas and their examples) and `tools/call`. Tool names resolve both ways, by contract name and
by backend name, so it works whichever side calls it. The response is shaped like a real MCP answer:
`content[0].text` with the JSON, plus `structuredContent` — an example written as a list is wrapped
under the property the `outputSchema` declares, exactly as a real backend's answer would be, so
switching mock mode off changes nothing on the wire.
An example that declares `error` comes back as a JSON-RPC error with its own code, message and data,
which is how you exercise the failure paths of an agent without a real backend.

Everything before the call still applies in mock mode: authentication, per-tool authorisation, rate
limit, quotas and `inputSchema` validation. Only the destination changes, and `mock.delay_ms`
simulates the backend latency inside the mock server.

Both flags are hot-reloadable from the console: flipping an MCP between mock and real backend takes
effect on the next call, with no restart. Changing the mock server's port or enabling it for the
first time does need one.

Picking a scenario:

| Situation | What the mock returns |
|---|---|
| `X-Mock-Example: <name>` header on the agent request | that scenario, or an error if the spec has no such name |
| No header, the arguments match a scenario's `input` | that scenario — send the account with no funds and you get the failure |
| No header, `examples.default` exists | `default` |
| No header, only a single `example` | that one |
| No header, several named scenarios | the first one alphabetically, so the answer stays deterministic |
| No example at all in the spec | HTTP 501 telling you to declare one |

That last row is deliberate: a tool with no declared example cannot be mocked, and saying so loudly
is better than inventing a payload the contract never promised.

## A tool served by a SQL query

An entry of `backend_server` can be a **database** instead of another MCP server. The gateway runs a
query and turns the rows into an MCP result — same pipeline, same output contract, same trace, same
quota. It is the alternative to the mock for an MCP that does not exist yet, and sometimes the
answer itself: a catalogue that lives in a table does not need a server in front of it to be one.

**The contract does not know.** The OTS spec declares the tool with its `inputSchema` and its
`outputSchema` and says nothing else; the entry names the primitive it serves in the query string of
its url. Swap that entry for an MCP one tomorrow and no consumer can tell the difference — which is
the whole reason it is built this way, and why both schemas are **mandatory** on a database tool.

```json
// ots.json — one entry per query
{
  "url": "mariadb://localhost:3306/test?consultar_producto",
  "type": "database",
  "query_file": "sql/getProductoById.sql",
  "description": "Un producto por su id",
  "cache": { "enabled": false },
  "security": { "type": "password", "username": "root", "password": "env:DB_PASSWORD" }
}
```
```sql
-- sql/getProductoById.sql, relative to ots.json
select id, nombre, detalles, stock, precio from productos where id = $id;
```
```yaml
# the spec: a tool like any other. No url, no query, no database.
  consultar_producto:
    name: "consultar_producto"
    summary: "Un producto por su id"
    inputSchema:
      type: "object"
      additionalProperties: false
      required: ["id"]
      properties:
        id: { type: "integer" }
    outputSchema:
      type: "object"
      additionalProperties: false
      properties:
        id: { type: "integer" }
        nombre: { type: "string" }
        detalles: { type: "string" }
        stock: { type: "integer" }
        precio: { type: "number" }
```

```
tools/call consultar_producto {"id": 7}
  → select … where id = ?   with [7]
  → { "structuredContent": { "id": 7, "nombre": "Ratón", "precio": 19.95, "stock": 0 },
      "content": [ { "type": "text", "text": "{\"id\":7,…}" } ],
      "isError": false, "resultType": "complete",
      "_meta": { "ots/untrusted": true, "ots/source": "database query" } }
```

### `$id` is a bound parameter, never text

Every `$name` in the query is replaced by the driver's placeholder and the value travels beside it.
An `id` of `1; drop table productos` reaches the database as that **string**, and a `nombre` of
`' or '1'='1` matches nothing:

```
buscar_producto {"nombre": "' or '1'='1"}   →   0 rows
```

The type check of the `inputSchema` catches most of it earlier still — an `id` declared `integer`
never gets to be a string — but the binding is what makes it safe rather than lucky.

### The outputSchema is what turns rows into a contract

It does two jobs no query can do on its own:

- **Types.** A MySQL driver hands back `"49.90"` for a `DECIMAL` and bytes for text. The schema says
  `precio` is a `number`, so `49.9` is what the agent gets. Without it every consumer parses strings.
- **What travels.** A column the contract does not declare is **trimmed** in `reject` mode. Add a
  `coste_interno` to the table and it stops at the gateway instead of reaching a model — which is
  exactly the failure a `select *` produces six months later.

`x-ots-mask` applies too, so a column can be published masked without changing the query.

Shapes: an object whose single property is an array returns **every row** under that property, and
an empty result is `{"cuentas": []}`. A plain object promises **one row** — no row is a **tool
error** (`isError: true`, "the query of this tool matched no row"), because a product that does not
exist is a fact about the data and not a fault of the gateway, and more than one row is refused,
because that means the query is wrong. A top-level `type: array` is not a shape: MCP cannot carry
it, and the loader refuses it.

### What the loader refuses

| Refused | Why |
|---|---|
| A file that is not a single `SELECT` (or `WITH … SELECT`) | a query file is executable SQL; a `DELETE` pasted there should never reach a database |
| More than one statement in a file | the same |
| A `$name` the `inputSchema` does not declare | every parameter has to come from a declared argument |
| A database tool with no `inputSchema` or no `outputSchema` | the schema is the contract; the query is only how it is answered today |
| Two entries claiming the same primitive | one query, one entry |
| `cache.enabled: true` | this version does not cache query results, and accepting the field while ignoring it is worse than refusing it |
| A scheme other than `mariadb://` or `mysql://` | those are the two this version speaks |

An argument the query never uses is a **warning**: usually a contract that drifted from its query.

### Three traps in the url

| Part | What it is |
|---|---|
| `127.0.0.1`, not `localhost` | `localhost` resolves to `::1` first, and a container published on `0.0.0.0` is IPv4 only: the connection is refused before it starts |
| `/botibank` | the **schema** — the database name. Not a path, and not the name of anything in the spec |
| `?getConsultarCuentasByClienteId` | a **label** for the entry, so two queries against one database are two distinct urls a `server:` block can point at. Not the name of the tool |

And the url in the entry and the url in the `server:` block have to match character for character:
that is the binding, and a mismatch is refused at load with *points at the server "…", which is not
in the backend_server list*.

The whole thing end to end — container, table, read-only user, query file, secret, entry, spec, and
the curls one at a time — is *A backend that is a query* in
[`MANUAL-TESTS.md`](MANUAL-TESTS.md), with a table of every error it can give and what each means.

### The rest of it

The `.sql` files are **watched** like the specs: editing a query applies within the watch interval,
with no restart. The password takes `env:NAME` and lives in
[`secrets.json`](#secrets-secretsjson) like every other credential. `replicas` work as they do for an
MCP backend and fit well here — they are read replicas, and a `SELECT` can always be retried. A
connection failure, a timeout or a SQL error reach the agent as `-33005` with a `requestId`, and the
driver's message — which names columns and tables — stays in the log. Mock mode still wins, so you
can develop against the spec examples with no database at all.

Give the gateway a **read-only database user**. The single-`SELECT` rule catches the slip; the
grants are what make it true.

## Secrets: `secrets.json`

A credential field of `ots.json` may hold the value, but it should not: it says `env:NAME` and
the value lives in `secrets.json` next to it.

```jsonc
// ots.json — readable, diffable, committable
"jwt_secret": "env:OTS_JWT_SECRET",
"consumer_secret": "env:BOTIBANK_CONSUMER_SECRET"
```
```jsonc
// secrets.json — permissions 600, written by the console
{
  "secrets": {
    "OTS_JWT_SECRET": "57a59175e838bf…",
    "BOTIBANK_CONSUMER_SECRET": "RGzPdKnwtyxi…"
  }
}
```

Two properties are what the extra file buys, and neither is available with the value written inline:

- **`ots.json` carries no secret**, so it can be read, diffed and committed. That includes what
  the console writes: saving a plan or adding an MCP rewrites the configuration and leaves every
  reference exactly as it was.
- **The console can change a secret**, because `secrets.json` is a file it writes and the watcher
  reloads — like `ots.json`. Rotating a signing key is a form and a save, not an edit and a
  restart.

### How a name resolves

`env:NAME` keeps the prefix it always had; it now means *a named secret*, looked for in two places:

1. **The environment**, if the variable is set. That is the deliberate override — a container, a CI
   runner, an orchestrator's secret manager.
2. **`secrets.json`**. The normal store, and the one the console writes.

A name defined in **both** resolves to the environment, and the startup says so rather than leaving
you to find out by debugging. A reference **nobody** defines refuses the boot, naming it:

```
❌ auth_server.internal.jwt_secret is "env:OTS_JWT_SECRET" and nothing defines
   OTS_JWT_SECRET: add it to secrets.json, or export it
```

Which is the point: a server that cannot resolve a credential must not come up with an empty one.

Three other rules the loader enforces, each because the alternative fails silently: a value that is
itself an `env:` reference is refused (a name pointing at a name is a cycle or a secret that resolves
to nothing); an entry nobody references is a **warning**, because a store full of dead secrets is a
store nobody dares to clean; and the file is checked at startup for permissions that let other users
read it, and for being tracked by git — the most common way a secret leaves the machine, and a
silent one.

> **In this repository `secrets.json` is committed**, decided on 2026-09-09 for a development
> environment that runs on one laptop. The startup says so on every start (`🚨 secrets.json está
> versionado en git`) and the warning is accurate: everyone who clones gets the values, and deleting
> the file later does not remove them from the history. The alternative is one line — put
> `/secrets.json` back in `.gitignore` and `git rm --cached secrets.json` — and then each machine
> keeps its own, with `secrets.json.example` documenting the names.

### From the console

The **Secrets** section lists the names, never the values. Per name it shows whether something
defines it, where from, how long the value is — enough to tell "I pasted the wrong thing" from "it
is not there" — and which fields of `ots.json` reference it. A secret is **written, never read
back**, the same discipline the console already applies to the credentials it generates.

Two rules there: a name that is still referenced **cannot be deleted**, because the next reload
would refuse to start and you could not fix it from the console; and a name nothing references is
marked *safe to delete*.

Adding **or editing** a component brings its secret with it. Fill in the backend credentials of an
MCP — on the form that creates it or on the one that edits it — and the value goes to the store while
the configuration gets the reference:

```
add the MCP "crm" with its consumer_secret
   → secrets.json:  "MCP_CRM_CONSUMER_SECRET": "what you typed"
   → ots.json:   "consumer_secret": "env:MCP_CRM_CONSUMER_SECRET"
```

The generated name is predictable — `MCP_<NAME>_<FIELD>` — because a store full of opaque names is
one nobody cleans up. Three details that only show up in use:

- **Editing keeps the name.** A field that already says `env:BOTIBANK_CONSUMER_SECRET` takes the new
  value under *that* name; minting a fresh one on every save would rename the secret behind your
  back and orphan the old entry.
- **Empty means leave it alone.** The two credential fields are write-only, so saving the form to
  change a mock flag cannot wipe a credential you could not see.
- **A refused configuration rolls the secrets back.** If the save fails for any other reason — a
  spec that points at a backend the MCP does not declare, say — the values that came with the form
  are undone rather than left behind.

### Coming from `secrets.env`

The earlier arrangement kept the values in a shell file that `otsgateway.sh` sourced before
starting. Nothing reads it any more: the values belong in `secrets.json`, one name and one value
each, and the old file is renamed out of the way.

```bash
mv secrets.env secrets.env.migrated
```

Note that a `secrets.env` already committed keeps its values in the git history: moving them does
not rotate them.

> **Generated credentials do not go here.** An API key or a `client_secret` created by the console is
> stored **hashed** (`console.hash_new_credentials`), which is stronger than a reference: it can be
> regenerated but never recovered. The store is for the secrets somebody else issued — a signing key,
> the consumer pair of an APIM — that have to be kept as they are.

## Reaching the dashboard and the console

Both start with the gateway, both listen on **every interface**, and each is guarded by its own key
in `ots.json`:

```json
"dashboard": { "enabled": true, "port": "3004", "access_key": "8dadb7329fa02ead5b5df7e3d824fe4b" },
"console":   { "enabled": true, "port": "3005", "access_key": "26557c87c9c870a554b259c3d00d348f" }
```

The key travels three ways, and the gateway tries them in this order:

| Where | Who uses it |
|---|---|
| the `X-Dashboard-Key` / `X-Console-Key` header | a script, a `curl`, a reverse proxy in front |
| `?key=` on the url | a browser, which cannot set a header by hand — every example in the documentation uses this |
| the session cookie | set the first time the key arrived by either of the other two, so that **the links and the forms of the page work without carrying the key in every one** |

So opening one url is all it takes:

```
http://localhost:3004/?key=8dadb7329fa02ead5b5df7e3d824fe4b     dashboard
http://localhost:3005/?key=26557c87c9c870a554b259c3d00d348f     console
```

and from there every link, every deep link and every form of the console works — the browser holds
the cookie:

```
GET  /?key=8dadb…                          → 200   Set-Cookie: ots_dashboard_key=…; Path=/; HttpOnly; SameSite=Strict
GET  /mcp/botibank                         → 200   a click
GET  /mcp/botibank/tool/consultar_cuentas  → 200   a deep link
GET  /api/state                            → 200
POST /plan                                 → 200   a save, on the console
GET  /mcp/botibank    (no cookie at all)   → 401
```

From a script nothing changed. The header still authenticates on its own, request by request; a
`Set-Cookie` comes back with it, and `curl` discards it unless you asked for a cookie jar, so there
is nothing to manage:

```bash
curl -H 'X-Dashboard-Key: 8dadb7329fa02ead5b5df7e3d824fe4b' http://localhost:3004/consumers
curl -H 'X-Console-Key: 26557c87c9c870a554b259c3d00d348f'   http://localhost:3005/
```

Without a key, or with the wrong one, both answer `401` and say which realm they belong to:

```
WWW-Authenticate: ApiKey realm="ots-dashboard"
WWW-Authenticate: ApiKey realm="ots-console"
```

### What the cookie is, and is not

It holds the same secret the query string already carried, so it **grants nothing new** — what it
adds is that the browser keeps hold of it. `HttpOnly` keeps it away from page scripts,
`SameSite=Strict` keeps another site from posting a configuration change through a browser that
happens to be signed in — which is why it matters more on the console than on the dashboard — and no
`Max-Age` makes it die with the browser session. `Secure` is set when the request arrived over TLS
and not otherwise, so it works on a plain `http://localhost` and hardens itself behind a proxy that
terminates TLS.

**Rotating the key invalidates every cookie by itself**, because the comparison then fails. A cookie
that no longer matches is *cleared* on that same response, so the operator is asked for the new key
once rather than refused forever by a stale one. Verified: rotate `console.access_key`, wait for the
watcher, and the browser gets `401` plus a `Max-Age=0` for the old cookie; open `?key=<the new one>`
and it navigates again.

One thing the cookie does **not** do: it does not take the key out of the address bar of the page
you typed. Redirecting to strip it was considered and rejected — `curl "$DASH/?key=…"` would then
answer `303` instead of `200` and every documented example and every automated case would have to
change. So treat a url with `?key=` in it the way you would treat any url with a secret in it: do
not paste it into a chat, and be aware it reaches the browser history and the `Referer` of anything
the page links to.

### Two properties worth knowing

The key is read from the **live** configuration on every request, so turning it on or rotating it
takes effect on the next request with no restart — which matters because the moment you need to
rotate a key is exactly the moment you cannot afford a restart. And it is compared in **constant
time** on both (`subtle.ConstantTimeCompare`), so the comparison leaks nothing about how much of a
guess was right.

### With no key at all

Leaving a key empty is allowed and the startup log says so: `⚠️` for the dashboard, which exposes the
catalogue, the consumers, the masked credentials and the full trace of every transaction — and `🚨`
for the console, because the console **writes `ots.json`**: anyone who reaches that port can
create credentials, widen allowlists, raise plans or point an MCP at another backend, applied hot.
Point 1 of [`PARKED-TOPICS.md`](PARKED-TOPICS.md) has what the keys do and do not protect, and why
the ports should stay closed at the firewall regardless: the listeners bind **every interface**, so
the keys are the only barrier in front of them.

## Governance dashboard

Starts together with the gateway when `dashboard.enabled` is `true` and listens on every interface,
on `dashboard.port`. Guarded by `dashboard.access_key` — see *Reaching the dashboard and the
console* above for how the key travels.

| Route | What it shows |
|---|---|
| `/` | Catalog: every MCP with its **tools, resources and prompts** — the real backend name, who answers each one, calls, failures, average latency and last use — plus the latest transactions |
| `/mcp/{name}` | MCP detail: backend, security type, spec file, its three catalogs and its transactions |
| `/tool/{name}` | Tool contract (description, `inputSchema` with its request example, `outputSchema`, backend mapping), the **declared scenarios** as request/response pairs, **which consumers have consumed it** and all its transactions |
| `/resource/{name}` | Resource contract: uri or uri template with its variables, mime type, cache ttl, who answers it, the body declared in the spec, **who has read it** and its transactions |
| `/prompt/{name}` | Prompt contract: arguments and which are required, argument mapping to the backend, the messages declared in the spec, **who has rendered it** and its transactions |
| `/consumers` | Every consumer with its plan, rate limit, hourly and daily quota: used, remaining and a usage bar |
| `/consumer/{name}` | Consumer detail: what the subscription allows of each kind, what was actually consumed and its transactions |
| `/transactions` | Whole in-memory history |
| `/transaction/{uuid}` | **Full trace**: the pipeline step by step with timings, and the four messages — agent request, gateway request to the MCP, MCP response and response to the agent |
| `/api/state` | The same data as JSON, for scripting |

Every transaction is identified by a **UUID v4**, shown shortened in tables and in full on the
trace page. A real trace looks like this:

```
0.4 ms   JSON-RPC parsing        method tools/call
0.4 ms   authentication          consumer c0 · plan free
0.4 ms   tool resolution         mcp botibank · backend tool get_cuentas
0.4 ms   authorization           subscription allowlist: allowed
0.4 ms   rate limit              within the free plan
0.4 ms   plan quota              hour 2/100 · day 2/1000
0.4 ms   contract validation     1 arguments conform to inputSchema
0.4 ms   backend mapping         consultar_cuentas → get_cuentas, 1 arguments translated
0.4 ms   backend token           reused from cache (OAuth2 client_credentials)
43.5 ms  MCP call                HTTP 200 from https://localhost:8243/botibankmcp/1.0/mcp
44.0 ms  response to agent       relaying the MCP response
```

API keys and tokens are always masked everywhere (`def•••35`, `Bearer eyJ•••Lw`).

### Persistence

Transactions are appended to a **JSONL journal**, one line per transaction, so the history is not
lost on `-stop` / `-start`:

```json
"telemetry": {
  "enabled": true,
  "file": "logs/transactions.jsonl",
  "max_history": 500,
  "max_file_mb": 64
}
```

- `max_history` — transactions kept in the in-memory ring buffer, and how many are replayed into it
  at startup. Payloads are truncated at 16 KiB each.
- `max_file_mb` — when the journal grows past this, it is rotated to `<file>.1` and a new one
  starts. One generation is kept: this is recent traceability, not an archive.
- At startup the whole journal is replayed: **cumulative counters** come from every line and the
  **hour and day quotas** are rebuilt from the transactions that actually charged quota inside the
  current windows, so a restart no longer gives away consumed quota.
- Writes are asynchronous — disk never sits in the agent request path. If the queue saturates, lines
  are dropped rather than slowing the agent down, and the dropped count is shown on
  `/transactions`.
- The journal never stores the API key: each transaction carries a `KeyID`, the first bytes of its
  SHA-256, which is enough to rebuild quotas without persisting the secret.
- Set `"enabled": false` to go back to memory-only telemetry.

If the block is missing from `ots.json`, telemetry is enabled with exactly those defaults.

## Code layout

The whole gateway lives in a **single `main.go`**, split into banner-numbered sections. The index
sits at the top of the file:

| Section | Contents |
|---|---|
| 1–9 | Gateway core: models, state, OAuth2 tokens, config loading and validation, authentication and authorisation, OTS contract, dispatcher and mock |
| **10. Telemetry component** | Traces, counters and quotas. Depends only on the types from section 1 |
| **11. Dashboard component** | Views, HTML templates and server. Reads the tool registry, the config and section 10 |
| **12. Console component** | Configuration panel: validates, writes `ots.json` and publishes the new snapshot |
| 13. Main | Startup, signals and graceful shutdown |

Sections 10, 11 and 12 are decoupled from the core: the dispatcher only reaches telemetry through
the recorder (`beginTx`, `rec.step`, `rec.fail`, `rec.ok`), and the console only touches the core
through `buildState` and `publishState`. `main()` just calls `startDashboard` and `startConsole`.
Any of the three can be modified — or removed — without touching the gateway logic.

The live configuration is an **immutable snapshot** published with an atomic swap. The whole gateway
reads it through `cfg()` and `catalog()`, so a request either sees the old configuration or the new
one, never a half-applied mix.

## Configuration console

Starts with the gateway when `console.enabled` is `true` and listens on every interface, on
`console.port`. It is the only component that **writes** configuration, so it is the one that most
needs its `console.access_key` — see *Reaching the dashboard and the console* above for how the key
travels, and why its forms need the session cookie to be submitted from a browser at all.

| Section | Edit | Add | Remove |
|---|---|---|---|
| Plans | `rate_per_second`, `burst`, `quota_hourly`, `quota_daily` | New plan with its four limits | Delete a plan (refused while a consumer uses it) |
| Consumers and credentials | Plan and the three checklists of each rule — tools, resources and prompts, `*` included | New consumer, another rule, or another credential (API key or OAuth2 client, generated) | Delete one credential, or revoke a whole rule; the consumer disappears with its last rule |
| MCPs | Backend URL, mock mode, mock delay, `tls_skip_verify` | New MCP with its OTS spec and OAuth2 backend | Delete an MCP; its tools, resources and prompts are also dropped from every subscription |
| Raw `ots.json` | Everything else, in a validated text editor | — | — |
| Reload from disk | Re-reads the file and applies it, for when you edited it or an OTS spec by hand | — | — |

Leaving the API key field empty generates one: 32 random hex characters from `crypto/rand`, prefixed
`ots_`. The console shows it in full **once**, right after creating it, and masks it from then on —
so no more `default-key-1235` in production.

### How a change is applied

```
edit → validate → write ots.json (atomic) → publish the new snapshot
             ↓ invalid
        nothing is written, the gateway keeps the previous configuration
```

Validation is exactly the one that runs at startup: unknown plans, duplicated or empty API keys,
unreadable OTS specs, names that clash across MCPs in any of the three registries, plans that would
block every request. The
errors are shown in the console; the file is only touched once everything passes.

Before every write the previous version is copied to `ots.json.bak`, and the new content goes
out as a temporary file plus a rename, so `ots.json` is never left half-written.

### What applies live and what does not

Live: plans, quotas, subscriptions, allowed tools, API keys, MCPs, backends, mock mode, TLS flag,
tool catalog (the OTS specs are re-read) and `telemetry.max_history`.

Needs a restart — the console tells you when a change falls here: any port (gateway, dashboard,
console, mock), the journal file, and the dashboard/console access keys.

Two details worth knowing. Changing a plan's numbers rebuilds the affected rate limiters, but the
**quota already consumed in the current hour or day is kept** — lowering a quota does not hand back
what was already spent. And the quick-edit forms rewrite `ots.json` in a canonical layout
(the struct's field order, with the telemetry defaults made explicit); the raw editor writes exactly
what you type.

## The VS Code connector

A third interface, next to the dashboard and the console, and the only one that edits the **files**
rather than the running process: [`VSCODE-PLUGIN.md`](VSCODE-PLUGIN.md) is the whole of it, and the
code is in [`../vscode-extension/`](../vscode-extension).

**The configuration is `ots.json`** — `config.json` is still read everywhere, so a deployment created
before the rename needs no migration: the gateway with no flag takes the first of the two that is
there and says which one it read, and the extension finds, opens and lists both.

**The gateway travels inside it.** There is one package per platform, each carrying the binary built
for it, so installing the extension is the whole installation — no Go, no build, no repository. An
explicit `ots.gatewayPath` still wins, and so does a binary next to your `ots.json`: somebody with
a checkout is working on the gateway and wants theirs.

| It does | |
|---|---|
| **A deployment from nothing** | `OTS: New deployment…` writes `ots.json`, a specification, `secrets.json` and a `.gitignore` — all of it already working, with generated credentials and its one backend in mock mode so it answers on the first run |
| **The specification, as a form** | any `*-ots.yaml` opens as one, and a new one is written complete rather than empty. Tools, resources, prompts, schemas, servers and scenarios are added from the interface, and every edit replaces exactly the value it changes — comments, key order and formatting survive |
| **`ots.json`, as a form** | gateway, dashboard, console, authorization server, mock, telemetry, plans, MCPs, consumers, and the secret store. A literal credential can be turned into an `env:` reference with its value preserved |
| **The deployment, as a map** | who calls, what they call, what answers — with the backend resolution drawn in the gateway's own order, so a line that surprises you there is a line that will surprise you in production. Permissions are granted by dragging, primitives are created and connected on the canvas, and a mock is switched per destination |
| **The calls, live** | every call travels the map as a ball, read from `logs/transactions.jsonl` as it grows, so the map costs the running gateway nothing. Click one for its route, its steps with their timings and the four payloads of the trip, or the 🔍 to open that transaction in the dashboard |
| **The gateway itself** | start, stop, restart and its log, without leaving the editor. It interrupts you only for a refusal |
| **A breakpoint that stops a real call** | see below |
| **The documentation** | this document and four others ship inside the extension, readable without a repository or a network |

### The debugger

`debug.enabled` is false by default, and the gateway refuses to turn it on when the console is
disabled or has no `access_key` — releasing a held call goes through the console, so a debugger
without one would be a way to hang a gateway with no way back.

With it off, a breakpoint on a box **catches**: the call is answered at full speed and kept in the
editor whole. With it on, the gateway **holds the call** — a ball parks on that box carrying what the
agent asked and what is about to happen — until somebody presses continue or abort.

It holds wherever the call actually goes, and says which: `before the backend`, `before the mock`,
`before the query`, and the same three on the way back. **One box watches both directions**, so a
breakpoint on a tool stops its answer too.

Four rails, all in `ots.json`, all failing closed: `timeout_sec` releases it on its own,
`on_timeout` says whether that is a continue or an error, `max_paused` is a ceiling past which a call
is **not** held — the debugger may never be the reason a gateway stops answering — and `allow_abort`
decides whether a held call may be answered with an error at all. A caller that hangs up ends its own
pause at once.

And the measurement stays honest: the journal records `PausedMs` beside `Duration`, so the caller's
wait is whole and every average the dashboard shows subtracts the pause. One debugged call does not
move the numbers.

Block 11 of [`TESTING-ONE-ONE.sh`](../TESTING-ONE-ONE.sh) proves all of it against a real gateway,
and [`MANUAL-TESTS.md`](MANUAL-TESTS.md) has the same cases as curls.

## MCP protocol support

The gateway serves **three revisions** — `2026-07-28`, `2025-11-25` and `2025-06-18` — in **two
eras**: the 2026-07-28 contract, and the earlier shape that the other two share. `initialize`
answers with a version the gateway supports and never with one it would refuse on the next request;
an unsupported version on a request is `-32022` with the list of the ones that are.

The gateway speaks **two eras of MCP at once**, because the revisions of 2026-07-28 and 2025-06-18
are not compatible and everything deployed today still speaks the older one.

| The agent sends | What the gateway does |
|---|---|
| No version at all | Legacy era: `initialize` and `ping` answer as before, nothing extra is required |
| `MCP-Protocol-Version` header and/or `_meta` with `io.modelcontextprotocol/protocolVersion` | Modern era: the per-request metadata and the mirrored headers are validated |

Modern-era validation, all with HTTP 400:

| Condition | Error |
|---|---|
| `_meta` without `io.modelcontextprotocol/clientCapabilities` | `-32602` |
| `MCP-Protocol-Version` header ≠ the `_meta` value | `-32020` `HeaderMismatch` |
| `Mcp-Method` ≠ the body method, or `Mcp-Name` ≠ `params.name` | `-32020` |
| A version the gateway does not implement | `-32022`, with `data.supported` |

Every result the gateway emits — including the ones relayed from a backend that speaks the older
revision — carries `resultType: "complete"` and `io.modelcontextprotocol/serverInfo` in `_meta`.
`tools/list` also carries `ttlMs` (from the `cache.ttlMs` of the spec) and `cacheScope: "private"`,
private because the catalog is filtered by the caller's subscription.

The gateway's own error codes live in `-33001..-33005`, outside the JSON-RPC reserved range, as the
revision's allocation policy requires. `-32020..-32099` belongs to the specification and is never
emitted for anything else.

### Version bridge

Each backend declares which revision it speaks:

```json
"backend_server": [{
  "url": "https://localhost:8243/botibankmcp/1.0/mcp",
  "protocol_version": "2026-07-28",
  "tasks": true
}]
```

With `protocol_version` set, the gateway sends that backend the `MCP-Protocol-Version` and
`Mcp-Method` headers, `Mcp-Name` when the method carries a name — a `tools/call` and a `prompts/get`
do, a `resources/read` is addressed by uri and does not — and, for the modern era, the per-request
`_meta` with `protocolVersion`, `clientCapabilities` and `clientInfo`. Left empty — the default —
none of that travels, which is what WSO2 API Manager expects today. A modern agent can therefore
consume a legacy MCP without knowing it.

The `Mcp-Param-*` headers a tool mirrors with `x-mcp-header` are the exception: they travel
whatever revision the backend declares, because they are not protocol chatter but the contract of
that tool — the spec author marked that argument to travel as a header, and usually the reason is a
backend that reads it there.

What the trace shows under *Gateway request to MCP* is exactly what went out on the wire, with the
`Authorization` value masked. That is worth saying because it was not always true: until
2026-09-07 those headers were built and recorded but never attached to the outgoing request — the
call passed no extra headers at all — so a backend declaring `protocol_version` received none of
them and a tool declaring `x-mcp-header` mirrored nothing. Fixed for `tools/call` and implemented
this way from the start in the resource and prompt relay; with `protocol_version` empty, which is
the default, nothing about the request changed.

### Long-running operations (Tasks)

Asynchrony in MCP is **not** part of the core protocol: it is the opt-in `io.modelcontextprotocol/tasks`
extension. When a backend has `"tasks": true`, the gateway declares the extension on its behalf and
the backend may answer a `tools/call` with a durable handle instead of the result. The agent then
polls with `tasks/get`.

Governance of that flow, which the extension leaves to the implementation:

| Question | Decision |
|---|---|
| When is quota charged? | On the `tools/call` only. Polling every two seconds must not eat the plan |
| Are polls rate limited? | Yes, so nobody hammers the gateway asking |
| How is a poll authorised, if it only carries a `taskId`? | The gateway mints its own opaque handle and records owner, MCP and tool. Every poll re-checks ownership **and** the current authorisation on that tool |
| What if the tool is revoked mid-task? | The polling stops: 403 |
| Someone else's handle? | Same answer as an unknown one, so the existence of another consumer's task cannot be probed |
| Do handles survive a restart? | Yes, they are persisted in the journal as `"kind":"task"` lines |

The backend's own task identifier is never exposed to the agent.

### Progress while the work happens: the streaming relay

The transport lets a backend answer the same POST either way, and the gateway follows what it
answers:

```
application/json    → read whole, stamped and relayed, as it always was
text/event-stream   → copied event by event, flushing each one
```

Why it matters: with the body read at once, a backend that spends thirty seconds emitting
`notifications/progress` produced an agent that saw **nothing** for thirty seconds and then
everything at once. The progress arrived exactly when it was useless. Measured against the mock
emitting three events 400 ms apart:

```
+   9 ms  headers · Content-Type: text/event-stream · X-Accel-Buffering: no
+ 411 ms  notifications/progress  progressToken=tok-42  1/3
+ 811 ms  notifications/progress  progressToken=tok-42  2/3
+1212 ms  notifications/progress  progressToken=tok-42  3/3
+1212 ms  notifications/message   "the backend wants this logged"
+1213 ms  result · resultType=complete · ots/untrusted=true
```

Four things the relay guarantees, and they are the reasons this took care rather than lines:

- **Notifications travel untouched.** `notifications/progress` and `notifications/message` are the
  backend talking to the agent, and they carry the `progressToken` the agent itself sent, so it can
  attribute them. The gateway has no business editing that.
- **The result is still governed.** Streaming is not a way around the output contract: every event
  carrying a `result` goes through the masking and the projection, and a result the contract refuses
  becomes — inside the stream — the same generic error the whole-body path returns. Once the stream
  is open there is no other way to say no.
- **Hanging up cancels the backend.** The agent closing the connection cancels the request context,
  which closes the backend body, which the backend reads as a cancellation. It is what the transport
  asks for, and it is visible on both sides of the trace.
- **It is bounded.** The 20 s deadline moved to the *headers*, because a stream that lasts two
  minutes is the feature; what bounds an open one is the agent's own context, a byte cap and a
  ten-minute wall clock for a backend that never closes.

The trace records what only streaming can measure: **TTFB** — how long the agent waited for the
first event — the number of events and the bytes. And the token budget charges the whole stream,
because the whole stream went into the model's context.

**Streaming and tasks are complements, not alternatives.** Streaming is for progress during work
that finishes inside this request; the tasks extension is for work that outlives it, because a
handle survives a disconnection and a restart while a stream does not.

### Change notifications

`subscriptions/listen` opens an SSE stream that begins with
`notifications/subscriptions/acknowledged` and then delivers `notifications/tools/list_changed`,
`notifications/resources/list_changed` and `notifications/prompts/list_changed` whenever the
corresponding catalog changes — which happens for real here, every time the console or the file
watcher publishes a new snapshot.

The three are acknowledged because the three share one honest trigger. What travels is only what
moved: on every publish the gateway fingerprints exactly what each list method hands out, so editing
a resource notifies the resource subscribers and nobody else, and changing a plan or a credential
notifies nobody. `resourceSubscriptions` — a notice per uri — is still omitted from the
acknowledgement, because it would need the backend to tell us first, and the specification requires
omitting whatever a server does not support. The stream carries
`io.modelcontextprotocol/subscriptionId` in every message and keeps itself alive with SSE comments.

Full conformance analysis, including what is still open, in
[`MCP-CONFORMANCE-2026-07-28.md`](MCP-CONFORMANCE-2026-07-28.md).

## Output contract

The `outputSchema` used to be published and nothing else. It is now a filter over what the backend
sends back, because that response lands inside an LLM context.

Three things happen to a relayed result:

| Step | What it does |
|---|---|
| **Masking** | Fields annotated with `x-ots-mask` are replaced. Always applied: a mask is an instruction of the contract, not a policy |
| **Projection** | With `additionalProperties: false`, fields the schema does not declare are dropped (in `reject` mode) |
| **Validation** | Types and required fields are checked against the schema |

```yaml
outputSchema:
  type: "object"
  properties:
    cuentas:
      type: "array"
      items:
        type: "object"
        additionalProperties: false
        properties:
          cuentaId:  { type: "string", x-ots-mask: "last4" }
          clienteId: { type: "string", x-ots-mask: "hash" }
          saldo:     { type: "number" }
```

What the agent then receives:

```json
{"cuentas": [{"clienteId": "sha256:06510c3363bd", "cuentaId": "•••-122", "saldo": 1800.5}]}
```

Masking modes: `full` (`•••`), `last4`, `first4`, `email` (`a•••@dominio.com`), `hash` (a SHA-256
prefix, so two records can be correlated without exposing the value) and `drop` (the field
disappears). A non-string value is always replaced whole: masking a number digit by digit would leak
its magnitude.

**The text block is rebuilt too.** A tool result carries the data twice — in `structuredContent` and
serialised inside `content[0].text` — so masking only the structured half would leak the value
through the other one. When the text block is the JSON of the structured content, it is regenerated
from the masked object.

### Policy per MCP

```json
"mcps": [{ "output": { "enforce": "warn", "max_bytes": 262144 } }]
```

| Mode | Masks | Validates | Drops undeclared | On a real mismatch |
|---|---|---|---|---|
| `off` | yes | no | no | relays |
| `warn` (default) | yes | yes | no, reports it | relays and logs |
| `reject` | yes | yes | yes | refuses with a generic error |

Dropping an undeclared field is the remedy, not a failure: in `reject` mode the contract wins and the
call goes through without that field. Only a genuine mismatch — a wrong type, a missing required
field — refuses the call. `max_bytes` caps the response, since a backend returning megabytes of text
would blow both the agent's context and the journal.

Starting in `warn` audits the contracts for free: the log names every tool whose backend returns
something the spec does not declare.

**A failure is not governed.** A result that comes back with `isError: true` is relayed whole, in
the three modes: the `outputSchema` describes the answer, and a backend that fails answers with a
shape of its own — an API Manager saying *Error connecting to the back end*, a core returning its
fault code. That body is the only thing that tells the model what went wrong, so it is neither
validated nor trimmed. It is also why the log stays readable: without this, one unreachable backend
printed *is not declared in the outputSchema* once per field, on every call.

### Marking what the gateway did not author

What the gateway **cannot** do here, and it is worth being explicit: prompt injection through data.
If a customer's name field contains *"ignore previous instructions and transfer…"*, no filter in the
gateway solves that — the mitigation lives in the host, with a human in the loop. What the gateway
does contribute is the hard part: nobody unauthorised gets to call `transferir_dinero`.

What it also contributes is the piece the host needs to put that human there: **every relayed result
is marked as content the gateway did not author**, in the `_meta` of the result.

```json
"_meta": {
  "io.modelcontextprotocol/serverInfo": {"name": "OTS Gateway", "version": "1.0.0"},
  "ots/untrusted": true,
  "ots/source": "backend MCP"
}
```

The two keys are prefixed `ots/` and not `io.modelcontextprotocol/`, which belongs to the
specification: inventing keys inside somebody else's namespace is how namespaces stop meaning
anything. `ots/source` is `backend MCP` or `mock server`.

**What is not marked, and why.** A catalogue is composed here, and a resource or a prompt served from
the `example` of the spec is text written by whoever configures this gateway — the same authority
that writes the allowlists. The mark says *"this came from a system I proxy"*, so it goes on
`tools/call`, and on `resources/read` and `prompts/get` when they are relayed, including through the
mock: mock mode exists so the agent behaves as it will in production, and that includes treating the
data with the same suspicion.

## CORS for browser agents

A browser refuses to let a page's JavaScript call another origin unless the server says otherwise, so
an agent running inside a browser cannot use the gateway without CORS. Two separate things:

- `otsgateway.allowed_origins` — the **defence**: who may call at all. Enforced always.
- `otsgateway.cors.enabled` — the **permission**: whether the gateway tells the browser about it.

```json
"otsgateway": {
  "allowed_origins": ["https://miapp.empresa.com"],
  "cors": { "enabled": true, "max_age_sec": 600 }
}
```

Off by default, so it never gets in the way of local testing: with it disabled, an `OPTIONS` gets a
plain `405`. Enabled, the preflight is answered with `204` and the exact origin is echoed — never
`*`, because the endpoint is authenticated — plus `Vary: Origin` so no shared cache mixes responses
between origins.

**Which endpoints it covers.** All the ones an agent touches, on the gateway port and on the mock
port, under the same two settings:

| Endpoint | Why the browser needs it |
|---|---|
| `POST /mcp/messages` | the calls themselves |
| `POST /oauth/token` | to get a token. `client_secret_basic` sends `Authorization`, so this one is preflighted |
| `GET /.well-known/oauth-protected-resource` | to discover the authorization server |
| `GET /.well-known/oauth-authorization-server` | to discover the token endpoint |

Without CORS on these last three, a browser agent gets a token it cannot read and metadata it cannot
parse — the whole discovery chain breaks silently, which is why they are governed by the same
`allowed_origins` and `cors.enabled` and not left open.

`WWW-Authenticate` is published in `Access-Control-Expose-Headers`, alongside `Retry-After`: a header
that is not exposed is invisible to the page, and that header is precisely how a standard MCP client
finds out where to authenticate.

One thing to weigh before pointing a browser at this: **if the agent runs in a browser, the
credential is in the browser** — an API key, or a `client_secret` that is no more secret than the
page it travels in — visible to the user and to any XSS there. Either treat those keys as
public (a restrictive plan, a minimal allowlist, easy rotation — the console does all three), or put
your own backend in front and keep the key there, in which case CORS is not needed at all.

## Operations

```bash
./otsgateway.sh -compile                     # lists the platforms you can build for
./otsgateway.sh -compile macos-arm64         # ...runs go vet and builds one, into dist/
./otsgateway.sh -start macos-arm64           # runs that binary from dist/
./otsgateway.sh -start macos-arm64 dev.json  # ...with another configuration
./otsgateway.sh -start                       # the platform of this machine, ots.json
./otsgateway.sh -status                      # what is running: PID and the ports it binds
./otsgateway.sh -restart macos-arm64         # stops it and starts it again
./otsgateway.sh -stop macos-arm64            # stops that instance
./otsgateway.sh -stop                        # stops every instance it finds
./otsgateway.sh -version                     # version, platform and commit
tail -f logs/otsgateway.log
```

Three things `-start` and `-stop` do that are worth knowing:

- **`-start` loads `secrets.env`** if it is there, so the `env:` references of `ots.json` resolve
  without exporting anything by hand. It says `🔐 Secretos cargados de secrets.env`, and warns when
  the file is missing while the configuration needs it.
- **`-stop` sends `SIGTERM` first** and only escalates to `-9` if the process is still there ten
  attempts later. The gateway has an orderly shutdown — it drains the journal and the in-flight
  requests — and a straight `kill -9` never let it run.
- **`-status` answers with what the process really has open**, not with what the configuration says:
  it lists the ports of that PID. It is how you find out that the dashboard did not come up because
  something else holds its port.

```
$ ./otsgateway.sh -status
✅ En marcha · PID 71430 · .local_pids.macos-arm64
   ↳ escuchando en *:3001
   ↳ escuchando en *:3082
   ↳ escuchando en *:3083
   ↳ escuchando en *:3086
```

### Binaries for every platform

**Compiling always names its target.** `-compile` on its own builds nothing: it prints the tags
available and what each one is for, so nobody has to guess or read this file to find out.

```
$ ./otsgateway.sh -compile

     TAG              GOOS/GOARCH    FOR WHOM
     ---------------- -------------  --------------------------------------------
  →  macos-arm64      darwin/arm64   Mac with Apple Silicon (M1 to M4)
                      alias: macos mac darwin-arm64
     macos-amd64      darwin/amd64   Mac with Intel
                      alias: macos-intel mac-intel darwin-amd64
     linux-amd64      linux/amd64    Linux x86_64: servers and containers
                      alias: linux ubuntu debian rhel
     linux-arm64      linux/arm64    Linux ARM64: AWS Graviton, ARM containers, 64-bit Raspberry
                      alias: linux-aarch64 graviton
     linux-arm        linux/arm      Linux ARMv6/v7: 32-bit Raspberry
                      alias: raspberry rpi
     linux-386        linux/386      Linux x86, 32-bit
                      alias: linux-x86 linux-32
     windows-amd64    windows/amd64  Windows x86_64
                      alias: windows win
     windows-arm64    windows/arm64  Windows on ARM (Surface and the like)
                      alias: win-arm
     freebsd-amd64    freebsd/amd64  FreeBSD x86_64
                      alias: freebsd

     all              all of the above, in one go: a whole release
                      alias: todas

     →  everything lands in ./dist, and -start runs the binary of whichever tag it is given
```

**One platform per invocation**, named explicitly. Any tag or any of its aliases works, so
`-compile macos`, `-compile mac` and `-compile macos-arm64` are the same thing, and `-compile ubuntu`
is `linux-amd64`. An unknown tag prints the list again instead of failing silently.

```bash
./otsgateway.sh -compile                  # the table, and nothing built
./otsgateway.sh -compile macos-arm64      # this machine
./otsgateway.sh -compile mac              # the same, by alias
./otsgateway.sh -compile linux-amd64      # a server
./otsgateway.sh -compile all              # the nine, for a release
```

**`all` is the one exception**, and it exists for the day you publish:

```
$ ./otsgateway.sh -compile all
🔍 go vet ./...
🏗️  Compilando todas las plataformas...
   macos-arm64      OK   9,9M    otsgw-1.0.0-darwin-arm64.tar.gz
      OTS Gateway 1.0.0 · darwin/arm64 · commit 3f1a9c2 · built 2026-09-10T08:14:02Z
      es la plataforma de esta máquina: ./otsgateway.sh -start macos-arm64
   macos-amd64      OK    11M    otsgw-1.0.0-darwin-amd64.tar.gz
   …
   9 de 9 plataformas compiladas
✅ Compilación correcta.
🔒 Checksums en dist/SHA256SUMS.txt
```

Three things it does on purpose: `go vet` still runs **once, before anything**, and a failure there
builds nothing; **one platform failing does not stop the rest**, because in a release what you need
is how many came out, not where it stopped — the count at the end says so, and the exit code is
non-zero if any failed; and the checksums are written at the end over everything in `dist`, so one
file covers the whole release.

| Tag | GOOS/GOARCH | Who it is for |
|---|---|---|
| `macos-arm64` · `macos` · `mac` | `darwin/arm64` | Mac with Apple Silicon, M1 to M4 |
| `macos-amd64` · `macos-intel` | `darwin/amd64` | Mac with Intel |
| `linux-amd64` · `linux` · `ubuntu` · `debian` · `rhel` | `linux/amd64` | servers and containers x86_64 — the common case |
| `linux-arm64` · `graviton` | `linux/arm64` | AWS Graviton, ARM containers, 64-bit Raspberry |
| `windows-amd64` · `windows` · `win` | `windows/amd64` | Windows x86_64 |
| `windows-arm64` · `win-arm` | `windows/arm64` | Windows on ARM, Surface and the like |
| `linux-arm` · `raspberry` · `rpi` | `linux/arm` | 32-bit Raspberry, ARMv6/v7 |
| `linux-386` · `linux-x86` | `linux/386` | 32-bit x86 |
| `freebsd-amd64` · `freebsd` | `freebsd/amd64` | FreeBSD |

Builds **accumulate** in `dist/`: compiling a second platform keeps the first, and the checksum file
is rewritten to cover everything there. To publish a release, run it once per platform — a `for` loop
in the shell if you want them all:

```bash
for p in macos-arm64 macos-amd64 linux-amd64 linux-arm64 windows-amd64 windows-arm64; do
  ./otsgateway.sh -compile $p
done
```

The dependencies are pure Go, so `CGO_ENABLED=0` produces **static** binaries that cross-compile from
any machine and depend on nothing at the destination — no libc, no runtime, no Go installed. Adding a
platform is one line in the `tag_table()` of `otsgateway.sh`, which is the single source for both the
listing and the resolution of a tag.

**Why not only x64.** Because this very Mac is `arm64`: an x86_64 binary would run under Rosetta, or
not run at all. And on servers `arm64` stopped being exotic — Graviton is cheaper per request than
the equivalent x86, and half the container images out there are multi-arch already.

Each build leaves in `dist/` one bare binary and one ready-to-run package:

```
otsgateway-linux-amd64                   the bare binary, 9.4 MB
otsgw-1.0.0-linux-amd64.tar.gz      a ready-to-run package, 3.9 MB
SHA256SUMS.txt                           checksum of everything above
```

There is no separate tag for "this machine": naming its platform is saying it. And `dist/` is the only
output — nothing is copied to the repository root — so `-start` takes the binary from there, by tag:

```bash
./otsgateway.sh -compile macos-arm64   # or its alias, macos
./otsgateway.sh -start macos-arm64     # runs dist/otsgw-darwin-arm64
./otsgateway.sh -stop macos-arm64
```

The tag is optional on `-start`, `-stop` and `-version`: left out, it is the platform of this machine,
which is the only binary the machine can execute anyway. That is also the one thing the tag buys you —
`-start linux-amd64` on a Mac is refused with the reason, instead of an exec format error:

```
❌ El binario de 'linux-amd64' es para linux/amd64 y esta máquina es darwin/arm64: aquí no se puede ejecutar.
💡 Para arrancar en esta máquina: ./otsgateway.sh -start macos-arm64
```

Each instance keeps its own PID file, `.local_pids.<tag>`, so `-stop <tag>` knows what to kill and a
bare `-stop` stops everything it finds. Both arguments of `-start` are optional and order-free: what
resolves as a tag is the tag, what exists as a file is the configuration, and anything else is an
error rather than a made-up path.

The package carries the binary named `otsgateway`, `ots.example.json`, the OTS spec, the
documentation, an empty `logs/` and — on the platforms that have bash — `otsgateway.sh`. **The real
`ots.json` never travels**: it holds credentials. `ots.example.json` starts standalone, with the
mock enabled and placeholders instead of secrets, so a fresh machine answers `tools/call` without a
backend behind it.

```bash
# on the destination
tar xzf otsgw-1.0.0-linux-amd64.tar.gz
cd otsgw-1.0.0-linux-amd64
./otsgw -version                     # which build is this
cp ots.example.json ots.json        # and change the placeholders
./otsgw -config ots.json
```

On Windows there is no `otsgateway.sh` — bash is not the point there:

```powershell
.\otsgateway.exe -version
.\otsgateway.exe -config ots.json
```

Every binary is stamped with the commit and the build date, injected at link time
(`-X main.buildCommit`, `-X main.buildDate`), which is what makes several binaries of the same version
tellable apart:

```
OTS Gateway 1.0.0 · linux/amd64 · commit 517e16b · built 2026-08-28T16:10:36Z
```

To verify what you received: `shasum -a 256 -c SHA256SUMS.txt` (or `sha256sum -c`).

Reference manual tests in [`PRUEBAS.md`](PRUEBAS.md). To diagnose the WSO2 side of the chain
(token, `tools/list`, `tools/call`, the REST API underneath and the gateway itself) run
[`diagnostico-wso2.sh`](diagnostico-wso2.sh).

## Contract governance

The `*-ots.yaml` files are the contract. They are linted with the ruleset kept in this repo:

```bash
npx @stoplight/spectral-cli lint boti-bank-ots.yaml weather-ots-yaml \
  --ruleset .claude/skills/api-expert/references/spectral-ots-ruleset.yaml \
  --fail-severity=error
```

## Documentation map

| Document | What it covers |
|---|---|
| [`CONFIGURATION.md`](CONFIGURATION.md) | Every `ots.json` option: type, default, whether it applies live or needs a restart, plus recipes — and `secrets.json`, the store the `env:` references resolve against |
| [`OTD-REFERENCE.md`](OTD-REFERENCE.md) | The `*-ots.yaml` format field by field: `backend`, schemas, masking, examples, servers, and the `resources` and `prompts` blocks |
| [`MCP-CONFORMANCE-2026-07-28.md`](MCP-CONFORMANCE-2026-07-28.md) | Conformance against the current MCP revision: what was violated, what was fixed in each phase, and what is still open |
| [`DESIGNS-PENDING.md`](DESIGNS-PENDING.md) | Eight designs with their state — all eight built; each entry records what changed between the design and what was built |
| [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md) | **The full test plan, case by case**: 185 numbered cases in eleven blocks, in the order to run them — from compiling to the orderly shutdown. Start here to prove the whole thing works |
| [`TESTING-ONE-ONE.sh`](TESTING-ONE-ONE.sh) | **That plan, executable.** Builds a disposable instance on its own ports, runs the same cases with the same ids, prints what each one proves, and stops it. `./TESTING-ONE-ONE.sh` for everything, `3 9` for two blocks, `-case 3.9` for one, `-keep` to leave it up |
| [`MANUAL-TESTS-READY.md`](MANUAL-TESTS-READY.md) | **The same cases with every address and every credential written out**, and the token asked for right above the case that needs it. Copy, paste, run. Generated from your own `ots.json` with `python3 doc/expand-manual-tests.py` — regenerate it, do not edit it |
| [`manual-env.sh`](manual-env.sh) | **`source doc/manual-env.sh`** — every variable the manual cases use, read from your own `ots.json` and asked of the running gateway: addresses, keys, payloads, cookie jars and five kinds of token. It says what it could not work out, and why |
| [`MANUAL-TESTS.md`](MANUAL-TESTS.md) | **The same 185 cases, curl by curl**, with an index, what each one proves and how to read the answer — plus 14 extra checks the ordered plan does not walk (packaging, a real provider, `client_secret_basic`, CORS on the token endpoint). Come here when one case failed |
| [`RESOURCES-AND-PROMPTS-WALKTHROUGH.md`](RESOURCES-AND-PROMPTS-WALKTHROUGH.md) | Quick walk-through of the resource and prompt endpoints, from compiling to the dashboard |
| [`designs/`](designs) | Standalone sequence diagrams, including `seq_resources_prompts_en.html`: the three primitives with and without governance |
| [`VSCODE-PLUGIN.md`](VSCODE-PLUGIN.md) | **The VS Code connector, whole**: everything it does, the gateway it carries inside, the map and what can be done on it, the breakpoint that holds a real call, one call followed end to end, the tests, and how the packages are built, shared and published. The code is in [`../vscode-extension/`](../vscode-extension) |
| [`PARKED-TOPICS.md`](PARKED-TOPICS.md) | Hardening accepted for now and parked, and what has been closed since: network exposure of the UIs, where the secrets live, plan limits |
| `ots.example.json` · `secrets.json.example` | A configuration with no credentials and the mock on, and the shape of the secret store: what the distributable packages carry |
| [`AUDIT.md`](AUDIT.md) | Code audit, its findings and the state of each correction |

## Audit

The current state of the code, the defects found and the WSO2 `900906` diagnosis are documented in
[`AUDIT.md`](AUDIT.md).
