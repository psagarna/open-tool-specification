# OpenTool Description reference

An OpenTool Description (OTD) is a `*-ots.yaml` file: the contract that says which tools exist, what
they accept, what they return, where they are served and what the mock answers. The gateway reads it
at startup and on every reload; nothing in it is optional decoration — every field below is either
enforced or served.

Lint it before trusting it:

```bash
npx @stoplight/spectral-cli lint boti-bank-ots.yaml \
  --ruleset .claude/skills/api-expert/references/spectral-ots-ruleset.yaml \
  --fail-severity=error
```

---

## Document skeleton

```yaml
ots: "1.3.0"

info:
  title: "BotiBank Core Tools (MCP Server)"
  version: "1.2.0"
  description: "…"

# Default transport and endpoint for every tool of this document
servers:
  - protocol: streamable-http
    url: "https://localhost:8243/botibankmcp/1.0/mcp"
    description: "WSO2 API Gateway"

security:
  - AgentOAuthClientCredentials: []

tools:
  listar_clientes: { … }

resources:
  politica_privacidad: { … }

prompts:
  resumen_mensual: { … }

components:
  schemas:
    Cliente: { … }
```

| Block | Read by the gateway | Purpose |
|---|---|---|
| `ots`, `info` | shown in the dashboard | Identity and version of the document |
| `servers` | **yes** | Default backend for every primitive, matched by `url` |
| `security` | no | Documentary: the security the MCP expects |
| `tools` | **yes** | The catalog the model executes |
| `resources` | **yes** | The documents and data the application attaches — see below |
| `prompts` | **yes** | The interaction templates the user picks — see below |
| `components.schemas` | **yes** | Reusable schemas; `$ref` is resolved at load time |

MCP defines three server primitives, and the three are governed the same way: declared in the
contract, authorised per subscriber, translated to the backend, mocked from their examples and
measured. A document may declare one block, two or the three — what it does not declare simply is
not announced to any agent.

---

## `servers` and `server`

The contract decides **which** backend serves a tool; `ots.json` holds the credentials for it. The
match is by `url` against the `backend_server` list of the MCP, ignoring a trailing slash.

```yaml
# document level: the default for every tool
servers:
  - protocol: streamable-http
    url: "https://localhost:8243/botibankmcp/1.0/mcp"

tools:
  listar_clientes:
    # this tool only: overrides the default
    server:
      - protocol: streamable-http
        url: "https://localhost:8243/botibankext/1.0/mcp"
```

Note the two key names: **`servers`** at document level, because it lists the defaults, and
**`server`** inside a tool, because it names the one that serves it. A tool still using the plural
key is reported at load time instead of being silently ignored.

| Field | Values | Meaning |
|---|---|---|
| `protocol` | `streamable-http` \| `sse` \| `stdio` | The transport. `sse` names the HTTP+SSE transport deprecated since 2025-03-26 and logs a warning; `stdio` is refused, the gateway only reaches HTTP backends |
| `url` | string | Must match one `backend_server.url` of that MCP, or the configuration is refused |
| `description` | string | Documentary |

Resolution order: the tool's `server` → the document `servers` → the first `backend_server`. A url
that matches nothing **refuses the configuration**, naming the tool: routing the call elsewhere in
silence would be worse than not starting.

---

## A tool, field by field

```yaml
tools:
  transferir_dinero:
    name: "transferir_dinero"
    summary: "Transferencia entre cuentas"
    description: "Realiza una transferencia de dinero entre dos cuentas bancarias."

    backend:
      tool: "post_cuentas_by_cuentaId_transferir"
      arguments:
        cuentaId: "cuenta_origen"
        "requestBody.cuentaDestino": "cuenta_destino"
        "requestBody.monto": "monto"

    cache:
      ttlMs: 300000

    inputSchema:
      type: "object"
      required: ["cuenta_origen", "cuenta_destino", "monto", "concepto"]
      additionalProperties: false
      properties:
        cuenta_origen:  { type: "string" }
        cuenta_destino: { type: "string" }
        monto:          { type: "number", minimum: 0.01 }
        concepto:       { type: "string" }
      example:
        cuenta_origen: "CTA-122"
        cuenta_destino: "CTA-999"
        monto: 500.00
        concepto: "Traspaso"

    outputSchema:
      type: "object"
      additionalProperties: false
      properties:
        mensaje:       { type: "string" }
        saldoRestante: { type: "number" }

    examples:
      default: { … }
```

| Field | Enforced? | What it does |
|---|---|---|
| `name` | yes | Must equal the key of the map, or the load fails |
| `summary` | shown | Short title, used as `title` in `tools/list` |
| `description` | shown | The prompt the model reads to decide whether to call it. Say what it does, when to use it and whether it mutates state |
| `cache.ttlMs` | yes | Freshness hint. The shortest among the visible tools becomes the `ttlMs` of `tools/list` |
| `idempotent` | **yes** | Declares that calling it twice with the same arguments has the effect of calling it once. It is what allows the gateway to retry it on a `replicas` address when the network fails. Absent means no, which is the safe reading for a contract that has not thought about it |
| `backend` | yes | Translation to the real MCP — see below |
| `inputSchema` | yes | Validated on every call |
| `outputSchema` | yes | Masks, projects and validates the response — see below |
| `example` / `examples` | yes | What the mock returns |
| `server` | yes | Which backend serves this tool |
| `security` | **yes** | The scopes this tool demands from a bearer token — see below |
| `icons` | shown | Visual identifiers, passed through to the agent in `tools/list` |
| `aiHints`, `policies`, `errors` | no | Documentary today; candidates to become enforced |

---

## `backend` — translating the contract

The agent sees your names; the backend keeps its own.

```yaml
backend:
  tool: "post_cuentas_by_cuentaId_transferir"   # real name in the target MCP
  arguments:                                   # destination: source
    cuentaId: "cuenta_origen"
    "requestBody.cuentaDestino": "cuenta_destino"
```

- `backend.tool` — omit it and the OTS name is sent as is.
- `backend.arguments` — maps *destination: source*. The key accepts dotted paths, which covers the
  `requestBody` wrapper that MCP servers generated from a REST API expect.
- With no `arguments`, the agent's arguments travel untouched. With `arguments`, **only what is
  mapped travels**: nothing the contract does not declare reaches the backend.

---

## Schemas

Both schemas follow JSON Schema 2020-12. `$ref` pointing at `#/components/schemas/…` is **resolved at
load time**, so what reaches the agent is self-contained — the `components` block never travels.
Network `$ref`s are never dereferenced.

### `inputSchema` — what the agent must send

Validated on every call, before anything is forwarded:

- `required` fields must be present;
- with `additionalProperties: false`, an undeclared argument is refused;
- primitive types are checked.

For tools with no parameters, prefer `{ "type": "object", "additionalProperties": false }`.

The request example lives **inside** the schema, exactly where OpenAPI puts it. Both spellings are
read — `example` (a single value) and `examples` (a list) — and they travel to the agent inside the
schema, so any MCP client sees them.

### `outputSchema` — what the tool returns, and what may leave

Returned in `tools/list` and applied to the response:

```yaml
outputSchema:
  type: "object"
  properties:
    cuentas:
      type: "array"
      items:
        type: "object"
        additionalProperties: false
        properties:
          cuentaId:  { type: "string", x-ots-mask: "last4" }
          clienteId: { type: "string", x-ots-mask: "hash" }
          saldo:     { type: "number" }
```

A list is always declared **wrapped** like this, never as a top-level `type: "array"`: MCP requires
a tool that declares an `outputSchema` to answer with `structuredContent`, and types
`structuredContent` as an object. A schema of type array satisfies neither rule, and the loader
refuses it. The gateway does the wrapping itself — a backend, or a query, that answers with the bare
list has it placed under the property the schema names.

`x-ots-mask` masks a field before it reaches the agent — and therefore before it reaches an LLM
context, the trace and the journal:

| Mode | Result |
|---|---|
| `full` | `•••` |
| `last4` | `•••-122` |
| `first4` | `CTA-•••` |
| `email` | `a•••@example.com` |
| `hash` | `sha256:06510c3363bd` — correlate two records without exposing the value |
| `drop` | the field disappears |

A value that is not a string is replaced whole: masking a number digit by digit would leak its
magnitude. And the text block of the result is regenerated from the masked object, because a tool
result carries the data twice — masking only `structuredContent` would leak it through
`content[0].text`, which is exactly the half the model reads.

How strict the rest is depends on `mcps[].output.enforce` in `ots.json`: `off`, `warn` (default,
validates and logs) or `reject` (also drops undeclared fields and refuses a genuine mismatch). Masks
always apply: they are an instruction of the contract, not a policy.

None of it runs on a result that comes back with `isError: true`. The schema describes the answer,
not the failure, and the failure travels whole — trimming it would leave the model an error with no
reason inside it.

---

## `security` — scopes

> Applies to the **three primitives**. A tool, a resource and a prompt each demand what their own
> `security` block says; the one that declares none inherits the document-level `security`. The
> loader names, at startup, every resource and prompt that inherits a *demanding* requirement, so
> the inheritance never surprises anybody.

Two rules that are worth stating plainly, because they are what makes the block real control:

- **Every credential goes through the gate**, an API key included. A key carries the scopes declared
  next to it in `auth_method[].scopes`; a key with none satisfies only what demands none. There is
  no credential that skips the requirement.
- **The catalogues filter by scope.** `tools/list`, `resources/list`, `resources/templates/list` and
  `prompts/list` publish only what that credential could actually use. What it cannot use, it does
  not even see.

The `security` block declares which scopes a bearer token must carry to use a tool. Shape and
semantics follow OpenAPI: a **list of alternatives**, and satisfying **any one of them** is enough.

```yaml
# document level: the default for every tool
security:
  - AgentOAuthClientCredentials: []

tools:
  transferir_dinero:
    security:
      - UserDelegationOAuth: ["bank:transfer:execute"]
```

- An alternative with an **empty** scope list is satisfied by any valid token.
- A tool without its own `security` inherits the document one.
- Scope hierarchies are honoured: a token holding `bank:transfer` satisfies a requirement of
  `bank:transfer:execute`.
- A token that falls short gets `403` with
  `WWW-Authenticate: Bearer error="insufficient_scope", scope="bank:transfer:execute"`, and the error
  `data.requiredScopes` names exactly what is missing.

This only applies to callers authenticated with a bearer token. An API key carries no scopes, so its
authorisation is the allowlist of its subscription alone. Both mechanisms can coexist, and each
consumer declares which ones it may use in its own `auth_method` — see
[`CONFIGURATION.md`](CONFIGURATION.md#auth_server--who-issues-and-who-validates-the-tokens).

When the gateway issues the tokens itself (`auth_server.internal`), these `security` blocks are also
what fills the `scope` claim: the token carries the union of what the tools of that subscription
demand, which is why a scope declared here and nowhere else still ends up enforced end to end.

**One trap worth knowing.** This combination looks strict and is not:

```yaml
security:
  - AgentOAuthClientCredentials: []                    # ← no scopes: any token passes
  - UserDelegationOAuth: ["bank:transfer:execute"]
```

Because any alternative suffices, the first one lets every valid token through and the declared scope
becomes decorative. The gateway warns about it at load time, naming the tool:

```
⚠️ tool "transferir_dinero" declares a scope requirement alongside an alternative
   with no scopes, so any valid token satisfies it
```

If the intent is to demand the scope, remove the open alternative.

## Response examples and the mock

With `mock.enabled` on the MCP, the mock server answers from these examples and the backend is never
called. One inline example:

```yaml
example:
  - id: "71992c72-…"
    nombre: "Ana"
    apellido: "García"
```

Or several named scenarios, each pairing a request with its response, failures included:

```yaml
examples:
  default:
    summary: "Transferencia aceptada"
    input:
      cuenta_origen: "CTA-122"
      cuenta_destino: "CTA-999"
      monto: 500.00
      concepto: "Traspaso"
    value:
      mensaje: "Transferencia realizada con éxito"
      saldoRestante: 1300.50

  saldo_insuficiente:
    summary: "La cuenta origen no cubre el monto"
    input:
      cuenta_origen: "CTA-123"
      monto: 5000.00
    error:
      code: -32000
      message: "Saldo insuficiente en la cuenta"
      data:
        saldo_disponible: 100.00

  tarea_larga:
    summary: "Consulta que el backend resuelve en segundo plano"
    task:
      pollsUntilDone: 2
      pollIntervalMs: 300
      statusMessage: "Recorriendo el core bancario"
    value: [ … ]
```

| Field | Meaning |
|---|---|
| `summary` | Required in a named scenario; shown in the dashboard |
| `input` | The request that produces this scenario. Validated against the `inputSchema`, and used by the mock to pick the scenario from the arguments received |
| `value` | The successful response |
| `error` | Instead of `value`: the mock returns that JSON-RPC error, to exercise the failure paths of an agent |
| `task` | Turns the scenario into a long-running one: the mock returns a durable handle and only resolves after `pollsUntilDone` polls |
| `stream` | Turns it into one that arrives in pieces: the mock answers `text/event-stream` with `events` progress notifications every `intervalMs`, each carrying `statusMessage` and the agent's own `progressToken`, then one `notifications/message` with `message` if declared, and the result as the last event. It is how the streaming path of the gateway is exercised without a backend that speaks it |

How the mock picks a scenario:

| Situation | Result |
|---|---|
| Header `X-Mock-Example: <name>` | that scenario, or an error if the spec has no such name |
| No header, the arguments match a scenario's `input` | that one — send the account with no funds, get the failure |
| No header, `examples.default` exists | `default` |
| No header, only a single `example` | that one |
| No header, several scenarios | the first alphabetically, so the answer stays deterministic |
| No example at all | HTTP 501 telling you to declare one |

A tool with no example cannot be mocked, and saying so loudly beats inventing a payload the contract
never promised.

---

## `icons`

Optional visual identifiers, passed through to the agent as the revision defines them:

```yaml
icons:
  - src: "https://cdn.example.com/icons/clients.png"
    mimeType: "image/png"
    sizes: ["48x48"]
```

## `resources` — the documents and data

A resource is what the application attaches to the model's context: a legal text, a price list, the
movements of an account. The model does not decide to read it; the host does, by `uri`.

```yaml
resources:
  politica_privacidad:
    title: "Privacy Policy"
    description: "Current legal text about data treatment, so the agent can cite it verbatim."
    uri: "ots://botibank/politica-privacidad"    # the uri the agent sees
    mimeType: "text/markdown"
    cache:
      ttlMs: 3600000
    example: |                                   # what the contract answers with
      # Privacy Policy v2.1
      …
    server:                                      # which backend serves it
      - protocol: streamable-http
        url: "https://localhost:8243/botibankext/1.0/mcp"

  movimientos_cuenta:
    title: "Account Movements"
    description: "Detailed list of the transactions of one account, newest first."
    uriTemplate: "ots://botibank/cuentas/{cuentaId}/movimientos"   # parameterised
    mimeType: "application/json"
    backend:                                     # the uri the real MCP serves
      uriTemplate: "mcp://core/accounts/{cuentaId}/tx"
```

| Field | Enforced? | What it does |
|---|---|---|
| `uri` | yes | The fixed address. A resource declares this **or** `uriTemplate`, never both |
| `uriTemplate` | yes | The parameterised address. `{placeholder}` never spans a `/`, so one uri can never match two resources |
| `title`, `description` | shown | What the catalog publishes, and what the host reads to decide whether to attach it |
| `mimeType` | shown | Published in `resources/list` and returned in the body |
| `cache.ttlMs` | yes | Freshness hint. The shortest among the visible resources becomes the `ttlMs` of `resources/list`; this one is the `ttlMs` of its own `resources/read` |
| `security` | **yes** | The scopes this resource demands, same shape and same document-level fallback as a tool — see [`security` — scopes](#security--scopes) |
| `example` | yes | The body the contract answers with, and what the mock serves |
| `backend.uri` / `backend.uriTemplate` | yes | The address of the real MCP. **Declaring it is what turns the resource into a relayed one** |
| `server` | yes | Which `backend_server` of the MCP serves it, exactly as in a tool |

A fixed uri is answered as it is; a template is answered with the uri the caller asked for, with its
placeholders bound — in the body too, so `{cuentaId}` inside an `example` is substituted.

`resources/list` publishes the fixed ones and `resources/templates/list` the parameterised ones: a
client cannot read a template, only instantiate it. For manual testing, `resources/read` also
accepts `{"name": "politica_privacidad"}` instead of the uri.

---

## `prompts` — the interaction templates

A prompt is a template the **user** picks in the client, not something the model calls on its own.

```yaml
prompts:
  resumen_mensual:
    title: "Monthly Summary"
    description: "Writes an executive summary of the monthly spending of one account."
    arguments:
      - name: "cuenta_id"
        description: "The account to summarise"
        required: true
    cache:
      ttlMs: 600000
    example:                                     # the messages the contract renders
      messages:
        - role: "user"
          content: { type: "text", text: "Analyse account {cuenta_id} and summarise it." }
    backend:                                     # or the real MCP renders them
      prompt: "summarize_account_tx"
      arguments:
        accountId: "cuenta_id"                   # destination: origin, as in a tool
```

| Field | Enforced? | What it does |
|---|---|---|
| `title`, `description` | shown | What `prompts/list` publishes; the title is what the user picks |
| `arguments[]` | **yes** | `name`, `description` and `required`. A missing required argument is `-32602` with `data.missingArguments`, never a template with a hole in it |
| `cache.ttlMs` | yes | Same criterion as a resource, over `prompts/list` and `prompts/get` |
| `security` | **yes** | The scopes this prompt demands, same shape and same fallback as a tool |
| `example.messages[]` | yes | The `{role, content}` messages, with `{placeholders}` substituted from the arguments |
| `backend.prompt` | yes | The name in the real MCP. **Declaring it is what turns the prompt into a relayed one** |
| `backend.arguments` | yes | Renames the arguments for the backend, `destination: origin`, exactly as a tool does |
| `server` | yes | Which `backend_server` serves it |

---

## Who answers a resource or a prompt

Three sources, decided in this order, and the dashboard says which one applies to each element:

| Order | Source | When |
|---|---|---|
| 1 | **mock server** | the MCP has `mock.enabled`: the mock answers from the spec examples, as it does for tools |
| 2 | **backend MCP** | the primitive declares a `backend` block: the gateway translates the address or the name and relays the call, with the OAuth2 token of its `backend_server` and one retry on a 401 |
| 3 | **the contract** | neither of the above: the `example` of the spec is the answer |

And if a primitive declares neither `example` nor `backend`, nobody can answer it: the loader warns
about it by name at startup, and a call gets an HTTP 501 saying exactly that instead of an empty
body.

The two catalogue methods per kind are free of charge; `resources/read` and `prompts/get` charge the
plan quota, because they serve content — the same criterion that makes `tools/list` free and
`tools/call` cost.

---

## What the gateway refuses to load

These abort the startup, or reject a reload and keep the previous configuration:

- a `name` that does not match the key of the tool;
- the same resource `uri` or `uriTemplate` declared in two MCPs: a name may repeat across MCPs, an
  address may not, because `resources/read` addresses a resource by uri and a uri carries no MCP;
- a resource that declares neither `uri` nor `uriTemplate`: no client could address it;
- a spec that does not parse, or declares no tools, resources or prompts;
- a `server.url` that matches no `backend_server` of its MCP;
- `protocol: stdio`, or an unknown protocol;
- the plural key `servers` inside a tool.

And these are warnings — the gateway starts and tells you:

- a request example that does not satisfy its own `inputSchema`;
- `protocol: sse`, the deprecated transport;
- a subscription allowing a tool, a resource or a prompt that no OTS spec declares;
- the same tool, resource or prompt **name** declared in two MCPs. This is allowed — you do not
  choose what a third party calls its tools — and the warning is there because it is usually not
  intended. A call naming it resolves through the endpoint of one MCP, or through the subscription
  when only one of the two is authorised; a consumer authorised on both sees the two listed as
  `mcp.name` and names the one it means;
- a resource with neither `example` nor `backend.uri`, or a prompt with neither `example.messages`
  nor `backend.prompt`: a call on it has nothing to answer with;
- a tool name outside 1–128 characters or the allowed character set;
- a scope requirement rendered moot by an alternative with no scopes;
- an MCP running in mock mode.

---

## See also

- [`CONFIGURATION.md`](CONFIGURATION.md) — every `ots.json` option
- [`README.md`](README.md) — architecture, the dashboard, the console and MCP protocol support
- [`MCP-CONFORMANCE-2026-07-28.md`](MCP-CONFORMANCE-2026-07-28.md) — conformance against the current MCP revision
