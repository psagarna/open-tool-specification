# Manual tests, case by case

Every case of the test plan with **the curl that runs it** and what proves it passed. It is the
detail behind [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md), which is the same cases as
a checklist, and behind [`TESTING-ONE-ONE.sh`](TESTING-ONE-ONE.sh), which runs them automatically
against a disposable instance in about two minutes.

**The three share one id space.** Case `6.10` is the same case in all of them, so a failure can be
reported by its id and looked up here for the command that produced it.

| Read this | When |
|---|---|
| [`TESTING-ONE-ONE.sh`](TESTING-ONE-ONE.sh) | you want to know whether anything regressed, now |
| [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md) | you are walking a release top to bottom and ticking boxes |
| this document | one case failed, or you want to run it by hand and see the whole answer |

## Before you start

> **Would you rather not export anything?** [`MANUAL-TESTS-READY.md`](MANUAL-TESTS-READY.md) is this
> same document with every address and credential spelled out and the token asked for in the case
> that needs it — copy, paste, run. It is generated from your `ots.json`:
> `python3 doc/expand-manual-tests.py`.

**One command, and every curl in this document works:**

```bash
cd /path/to/the/repository
source doc/manual-env.sh
```

> **On Windows, use a bash shell — Git Bash or WSL.** Everything here is bash, and PowerShell is not
> bash in two ways that bite immediately: `curl` there is an **alias of `Invoke-WebRequest`**, which
> does not understand `-H` or `-d` and fails with *Cannot bind parameter 'Headers'*; and `source` does
> not exist. If you have to stay in PowerShell, see
> [Running these on PowerShell](#running-these-on-powershell) at the end.

It reads the addresses and the credentials from **your `ots.json`** — the ports move, and a
document with them written in goes stale the first time somebody changes one — and it asks the
running gateway for the tokens. Then it says what it set up, and what it could not:

```
gateway    http://localhost:3002/mcp/messages
one mcp    http://localhost:3002/botibankots/mcp/messages
database   http://localhost:3002/botibankots/mcp/messages
auth       http://localhost:3003/oauth/token
mock       http://localhost:3006/botibankots
dashboard  http://localhost:3004  (key 8dadb7…)
console    http://localhost:3005  (key 26557c…)
consumers  c0
tokens     TOKEN, BROKEN, NONE, FAKE, NARROW
```

| Variable | What it is |
|---|---|
| `$GW` | the aggregate endpoint: every MCP the consumer is subscribed to |
| `$GWMCP` · `$GWDB` · `$GWWEATHER` | one MCP alone, by its `context_path`: the first, the one with a database backend, the second spec |
| `$AUTH` · `$MOCK` · `$DASH` · `$CONSOLE` | the authorization server, the mock, and the two UIs |
| `$DKEY` · `$CKEY` | their access keys |
| `$K` · `$K1` | the `X-API-Key` header of the first and second consumer |
| `$CID` · `$CSEC` | the oauth2 client of the first consumer |
| `$CALL` | a `tools/call` with no arguments, used wherever a case only needs *a* call |
| `$STREAM` | the same, asking for progress, for the streaming cases |
| `$TOKEN` | a real token from the gateway's own authorization server |
| `$BROKEN` · `$NONE` · `$FAKE` | that token with its signature flipped, with `alg=none`, and signed with another secret |
| `$NARROW` | a token narrowed to **one scope this client actually holds**. Empty when the consumer declares none, and the script says so: the internal authorization server answers `invalid_scope` to a scope the subscription never granted |
| `$SCOPES` | what that client may ask for, which is where `$NARROW` comes from |
| `$HASHED` | the hashed form of the first key, to paste into `ots.json` |
| `$D` · `$J` | cookie jars for the dashboard and the console, which hand out a session cookie |
| `$TX` | the newest transaction of the first consumer, for the cases that open a trace |
| `$WTOK` | **yours**: a token from the real IdP. It cannot be derived, so export it by hand |

Three of them need something before they can exist, and the script says which rather than leaving
you with an empty variable:

| Empty when | Fix |
|---|---|
| `$TOKEN` and everything derived from it | the gateway is down: `./otsgateway.sh -start` |
| `$TX` | no call has been made yet: make one, then source it again |
| `$NARROW` | the consumer declares no `scopes` in its `auth_method[].oauth2`. The scope cases (3.12, 3.13) need one that does — the disposable instance of `TESTING-ONE-ONE.sh` declares them, and this repository's `ots.json` does not |

Source it again after any of those, and it fills in what was missing.

`curl -si` instead of `-s` whenever the case is about a **header** — the challenges, `Retry-After`,
the CORS answer. Add `| python3 -m json.tool` (or `| jq`) to read a body comfortably.

**Two MCPs.** Several blocks need a second one. The repository ships
[`weather-ots.yaml`](weather-ots.yaml), which declares three names `boti-bank-ots.yaml` already uses
— that is deliberate, and block 9 is what it is for. Block 6 and block 7 need contract features the
production spec does not declare (a streamed scenario, a task, a masked field); the script writes a
`lab` spec for them, and each case says so.

**The ✎ mark** means the case edits `ots.json` or a spec. Back the file up first
(`cp ots.json ots.json.plan-backup`) and put it back at the end of the block; the watcher
picks the change up within `watch_interval_sec`, and a refused reload keeps the previous
configuration serving.

---

## Index

Every case has the same id here, in [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md)
and in [`TESTING-ONE-ONE.sh`](TESTING-ONE-ONE.sh). A failure reported as *6.10* means the same
thing in the three.

**[Block 0 · Preparation](#block-0--preparation)** — it compiles, it starts, and it says out loud what it loaded and where it listens

| # | What it proves |
|---|---|
| [0.1](#01--go-vet-is-clean-before-anything-is-trusted) | go vet is clean before anything is trusted |
| [0.2](#02--the-binary-reports-its-version-and-platform) | the binary reports its version and platform |
| [0.3](#03--the-secret-store-is-in-place) | the secret store is in place |
| [0.4](#04--otsjson-carries-no-literal-secret) | ots.json carries no literal secret |
| [0.5](#05--it-starts-and-answers) | it starts and answers |
| [0.6](#06--it-binds-every-port-it-announced) | it binds every port it announced |
| [0.7](#07--a-port-already-taken-is-caught-and-says-so) | a port already taken is caught, and says so |
| [0.8](#08--the-startup-log-states-the-catalogue-it-loaded) | the startup log states the catalogue it loaded |
| [0.9](#09--no--both-uis-have-their-access-key) | no 🚨: both UIs have their access key |
| [0.10](#010--an-env-reference-with-the-variable-unset-refuses-the-boot-naming-it) | an env: reference with the variable unset refuses the boot, naming it |

**[Block 1 · What the loader must refuse](#block-1--what-the-loader-must-refuse)** — a bad configuration is refused with the reason, and the previous one keeps serving

| # | What it proves |
|---|---|
| [1.1](#11--a-subscription-on-a-plan-that-does-not-exist) | a subscription on a plan that does not exist |
| [1.2](#12--the-same-api_key-on-two-consumers) | the same api_key on two consumers |
| [1.3](#13--a-security-rule-with-no-auth_method) | a security rule with no auth_method |
| [1.4](#14--a-plan-whose-rate_per_second-is-zero) | a plan whose rate_per_second is zero |
| [1.5](#15--an-hourly-quota-above-the-daily-one-can-never-bind) | an hourly quota above the daily one can never bind |
| [1.6](#16--an-hourly-token-budget-above-the-daily-one) | an hourly token budget above the daily one |
| [1.7](#17--a-per-call-cap-above-the-hourly-budget) | a per-call cap above the hourly budget |
| [1.8](#18--the-port-written-two-ways-with-two-different-values) | the port written two ways, with two different values |
| [1.9](#19--the-authorization-server-on-the-port-of-the-dashboard) | the authorization server on the port of the dashboard |
| [1.10](#110--the-token-endpoint-on-a-path-the-gateway-already-serves) | the token endpoint on a path the gateway already serves |
| [1.11](#111--a-replica-that-is-not-an-absolute-https-address) | a replica that is not an absolute http(s) address |
| [1.12](#112--a-replica-equal-to-another-backend_server-entry) | a replica equal to another backend_server entry |
| [1.13](#113--an-api_key-that-looks-hashed-but-is-malformed) | an api_key that looks hashed but is malformed |
| [1.14](#114--two-mcps-declaring-the-same-resource-uri) | two MCPs declaring the same resource uri |
| [1.15](#115--a-resource-with-neither-uri-nor-uritemplate) | a resource with neither uri nor uriTemplate |
| [1.16](#116--protocol-stdio-is-not-an-http-backend) | protocol: stdio is not an HTTP backend |
| [1.17](#117--a-resource-with-neither-example-nor-backend-warns-by-name) | a resource with neither example nor backend warns by name |
| [1.18](#118--a-document-level-security-warns-one-line-per-primitive-that-inherits-it) | a document-level security warns, one line per primitive that inherits it |
| [1.19](#119--two-mcps-declaring-the-same-tool-name-is-allowed) | two MCPs declaring the same tool NAME is allowed |
| [1.20](#120--an-outputschema-of-type-array-is-refused) | an outputSchema of type array is refused |

**[Block 2 · Credentials](#block-2--credentials)** — an api key, an oauth2 token and a stored hash all get in, and nothing else does

| # | What it proves |
|---|---|
| [2.1](#21--no-credential-401-with-both-challenges) | no credential: 401 with both challenges |
| [2.2](#22--the-api-key-of-the-subscription-gets-the-catalogue) | the api key of the subscription gets the catalogue |
| [2.3](#23--a-wrong-api-key-is-refused) | a wrong api key is refused |
| [2.4](#24--the-internal-authorization-server-issues-a-token) | the internal authorization server issues a token |
| [2.5](#25--that-token-authenticates-on-the-same-endpoint) | that token authenticates on the same endpoint |
| [2.6](#26--a-token-with-one-character-changed-does-not-verify) | a token with one character changed does not verify |
| [2.7](#27--a-token-signed-with-alg-none-is-refused) | a token signed with alg: none is refused |
| [2.8](#28--a-wrong-client_secret-is-invalid_client-and-the-retries-are-throttled) | a wrong client_secret is invalid_client, and the retries are throttled |
| [2.9](#29---hash-prints-a-different-value-each-time) | -hash prints a different value each time |
| [2.10](#210--a-hashed-api_key-authenticates-the-real-key-and-only-the-real-key) | a hashed api_key authenticates the real key, and only the real key |
| [2.11](#211--the-operator-surfaces-show-a-hash-as-a-hash) | the operator surfaces show a hash as a hash |
| [2.12](#212--a-credential-created-from-the-console-is-shown-once-and-stored-hashed) | a credential created from the console is shown once and stored hashed |
| [2.13](#213--a-credential-that-lives-in-the-store-authenticates-like-any-other) | a credential that lives in the store authenticates like any other |
| [2.14](#214--a-reference-nobody-defines-refuses-the-reload-naming-it) | a reference nobody defines refuses the reload, naming it |
| [2.15](#215--with-a-name-in-both-places-the-environment-wins) | with a name in both places the environment wins |
| [2.16](#216--a-value-that-is-itself-a-reference-is-refused) | a value that is itself a reference is refused |
| [2.17](#217--an-api-key-presented-as-a-bearer-token-is-accepted) | an api key presented as a bearer token is accepted |

**[Block 3 · Authorisation: the two gates](#block-3--authorisation-the-two-gates)** — the subscription and the contract scopes both filter, and what a credential cannot use it cannot see

| # | What it proves |
|---|---|
| [3.1](#31--toolslist-is-the-subscription-not-the-spec) | tools/list is the subscription, not the spec |
| [3.2](#32--a-tool-outside-the-allowlist-is-refused) | a tool outside the allowlist is refused |
| [3.3](#33--resourceslist-and-promptslist-follow-the-same-subscription) | resources/list and prompts/list follow the same subscription |
| [3.4](#34--the-three-lists-are-independent) | the three lists are independent |
| [3.5](#35--saving-a-subscription-that-only-touches-the-tools-keeps-the-other-two-groups) | saving a subscription that only touches the tools keeps the other two groups |
| [3.6](#36--the-wildcard-round-trips-instead-of-being-expanded) | the wildcard round-trips instead of being expanded |
| [3.7](#37--a-scope-on-a-resource-warns-at-startup-when-a-consumer-cannot-satisfy-it) | a scope on a resource warns at startup when a consumer cannot satisfy it |
| [3.8](#38--the-catalogue-filters-by-scope) | the catalogue filters by scope |
| [3.9](#39--reading-it-anyway-is-403-naming-the-scope-and-challenging-for-it) | reading it anyway is 403, naming the scope and challenging for it |
| [3.10](#310--an-api-key-does-not-skip-the-gate--it-carries-scopes) | an API key does not skip the gate — it carries scopes |
| [3.11](#311--a-broader-scope-implies-the-narrower-one) | a broader scope implies the narrower one |
| [3.12](#312--the-token-of-the-internal-server-carries-the-scope-the-resource-demands) | the token of the internal server carries the scope the resource demands |
| [3.13](#313--asking-for-less-gets-less-the-catalogue-follows-the-credential) | asking for less gets less: the catalogue follows the credential |
| [3.14](#314--a-guarded-mock-enforces-the-same-two-gates) | a guarded mock enforces the same two gates |
| [3.15](#315--a-qualified-entry-carries-the-scope-and-carries-it-nowhere-else) | a qualified entry carries the scope, and carries it nowhere else |
| [3.16](#316--a-bare-name-still-means-what-it-always-meant) | a bare name still means what it always meant |
| [3.17](#317--the-exemption-has-to-be-written--skips-the-check) | the exemption has to be written: `["*"]` skips the check |
| [3.18](#318--a-guarded-mock-applies-the-qualification-too) | a guarded mock applies the qualification too |
| [3.19](#319--the-token-of-the-internal-server-is-capped-by-the-entry) | the token of the internal server is capped by the entry |
| [3.20](#320--saving-from-the-console-does-not-unqualify-what-the-file-says) | saving from the console does not unqualify what the file says |
| [3.21](#321--the-dashboard-shows-which-entries-are-qualified) | the dashboard shows which entries are qualified |
| [3.22](#322--an-entry-that-is-neither-a-name-nor-name-scopes-is-refused) | an entry that is neither a name nor `{name: [scopes]}` is refused |

**[Block 4 · What a plan costs](#block-4--what-a-plan-costs)** — calls and context both cost, the catalogue does not, and the cost survives a restart

| # | What it proves |
|---|---|
| [4.1](#41--the-burst-binds) | the burst binds |
| [4.2](#42--a-second-later-the-bucket-has-refilled) | a second later the bucket has refilled |
| [4.3](#43--the-dashboard-shows-the-quota-and-the-token-bars) | the dashboard shows the quota and the token bars |
| [4.4](#44--the-catalogue-is-free) | the catalogue is free |
| [4.5](#45--a-call-a-read-and-a-render-each-charge-one) | a call, a read and a render each charge one |
| [4.6](#46--an-exhausted-hourly-quota-is-429-with--33004) | an exhausted hourly quota is 429 with -33004 |
| [4.7](#47--an-exhausted-token-budget-is-refused-before-the-backend-is-touched) | an exhausted token budget is refused before the backend is touched |
| [4.8](#48--the-last-answer-may-overshoot-the-budget) | the last answer may overshoot the budget |
| [4.9](#49--with-the-budget-spent-the-catalogue-still-answers) | with the budget spent the catalogue still answers |
| [4.10](#410--a-per-call-cap-refuses-an-answer-that-is-too-big) | a per-call cap refuses an answer that is too big |
| [4.11](#411--every-journal-line-carries-its-kind-and-what-it-served) | every journal line carries its kind and what it served |
| [4.12](#412--a-restart-does-not-hand-back-spent-budget) | a restart does not hand back spent budget |

**[Block 5 · The three primitives](#block-5--the-three-primitives)** — tools, resources and prompts are catalogued, addressed and answered the same way

| # | What it proves |
|---|---|
| [5.1](#51--initialize-announces-resources-and-prompts-because-the-spec-declares-them) | initialize announces resources and prompts because the spec declares them |
| [5.2](#52--a-capability-with-nothing-behind-it-is-not-announced) | a capability with nothing behind it is not announced |
| [5.3](#53--serverdiscover-carries-the-three-capabilities-and-the-cache-hints) | server/discover carries the three capabilities and the cache hints |
| [5.4](#54--resourceslist-carries-the-fixed-uris) | resources/list carries the fixed uris |
| [5.5](#55--resourcestemplateslist-carries-the-parameterised-ones) | resources/templates/list carries the parameterised ones |
| [5.6](#56--a-fixed-resource-is-answered-from-its-example) | a fixed resource is answered from its example |
| [5.7](#57--a-template-is-instantiated-and-the-variable-is-bound) | a template is instantiated and the variable is bound |
| [5.8](#58--the-ots-name-is-accepted-as-a-shortcut-for-the-uri) | the OTS name is accepted as a shortcut for the uri |
| [5.9](#59--promptslist-carries-the-declared-arguments) | prompts/list carries the declared arguments |
| [5.10](#510--promptsget-renders-the-messages-with-the-placeholder-bound) | prompts/get renders the messages with the placeholder bound |
| [5.11](#511--a-missing-required-argument-is-an-error-not-a-half-rendered-template) | a missing required argument is an error, not a half-rendered template |
| [5.12](#512--a-uri-nobody-serves-says-so) | a uri nobody serves says so |
| [5.13](#513--a-resource-with-nothing-to-answer-with-is-501) | a resource with nothing to answer with is 501 |
| [5.14](#514--the-dashboard-has-a-page-per-resource) | the dashboard has a page per resource |
| [5.15](#515--and-a-page-per-prompt) | and a page per prompt |

**[Block 6 · The backend: translation, failover and the output contract](#block-6--the-backend-translation-failover-and-the-output-contract)** — the contract translates what the agent says into what the backend expects, fails over when it may, and trims what comes back

| # | What it proves |
|---|---|
| [6.1](#61--a-call-reaches-the-backend-and-the-trace-records-the-mapping) | a call reaches the backend, and the trace records the mapping |
| [6.2](#62--a-tool-with-its-own-server-block-goes-where-the-contract-says) | a tool with its own server block goes where the contract says |
| [6.3](#63--a-relayed-resource-reaches-the-backend-under-the-translated-uri) | a relayed resource reaches the backend under the translated uri |
| [6.4](#64--a-relayed-prompt-reaches-the-backend-with-its-arguments-renamed) | a relayed prompt reaches the backend with its arguments renamed |
| [6.5](#65--everything-the-gateway-did-not-author-is-marked-untrusted) | everything the gateway did not author is marked untrusted |
| [6.6](#66--what-the-contract-itself-answers-is-not-marked) | what the contract itself answers is NOT marked |
| [6.7](#67--the-era-travels-only-when-the-backend-declares-it) | the era travels only when the backend declares it |
| [6.8](#68--an-x-mcp-header-argument-is-mirrored-whatever-era-the-backend-speaks) | an x-mcp-header argument is mirrored whatever era the backend speaks |
| [6.9](#69--a-dead-primary-with-a-live-replica-a-read-is-served-anyway) | a dead primary with a live replica: a read is served anyway |
| [6.10](#610--a-toolscall-that-does-not-declare-idempotent-is-not-retried-elsewhere) | a tools/call that does not declare idempotent is NOT retried elsewhere |
| [6.11](#611--declaring-idempotent-true-is-what-allows-the-retry) | declaring idempotent: true is what allows the retry |
| [6.12](#612--a-backend-that-answers-500-is-not-a-failover) | a backend that answers 500 is not a failover |
| [6.13](#613--the-dashboard-says-how-many-replicas-a-backend-has) | the dashboard says how many replicas a backend has |
| [6.14](#614--a-field-the-outputschema-does-not-declare-is-trimmed-off) | a field the outputSchema does not declare is trimmed off |
| [6.15](#615--a-masked-field-never-leaves-whole) | a masked field never leaves whole |
| [6.16](#616--warn-mode-relays-and-names-the-tool-in-the-log) | warn mode relays and names the tool in the log |
| [6.17](#617--a-backend-that-never-answers-is--33005-and-the-address-stays-out-of-the-answer) | a backend that never answers is -33005, and the address stays out of the answer |
| [6.18](#618--a-tool-answered-by-a-query-looks-like-any-other-tool) | a tool answered by a query looks like any other tool |
| [6.19](#619--the-outputschema-gives-the-rows-their-types) | the outputSchema gives the rows their types |
| [6.20](#620--a-column-the-contract-does-not-declare-is-trimmed) | a column the contract does not declare is trimmed |
| [6.21](#621--a-parameter-is-bound-never-interpolated) | a parameter is bound, never interpolated |
| [6.22](#622--no-row-on-a-single-object-contract-is-a-tool-error) | no row on a single-object contract is a tool error |
| [6.23](#623--the-query-file-is-watched-and-a-bad-one-is-refused) | the query file is watched, and a bad one is refused |
| [6.24](#624--a-tool-error-is-relayed-whole) | a tool error is relayed whole |

**[Block 7 · Streaming, and the notifications that travel with it](#block-7--streaming-and-the-notifications-that-travel-with-it)** — progress arrives while the work happens, and the contract still applies to every event

| # | What it proves |
|---|---|
| [7.1](#71--the-answer-is-an-event-stream-and-says-so-in-its-headers) | the answer is an event stream, and says so in its headers |
| [7.2](#72--the-events-arrive-spread-out-in-time) | the events arrive spread out in time |
| [7.3](#73--every-progress-notification-carries-the-token-the-agent-sent) | every progress notification carries the token the agent sent |
| [7.4](#74--a-log-notification-is-relayed-as-it-is) | a log notification is relayed as it is |
| [7.5](#75--the-last-event-is-the-result-stamped-and-marked) | the last event is the result, stamped and marked |
| [7.6](#76--the-trace-records-the-stream) | the trace records the stream |
| [7.7](#77--the-whole-stream-is-charged-to-the-token-budget) | the whole stream is charged to the token budget |
| [7.8](#78--the-mask-of-the-contract-applies-inside-the-stream) | the mask of the contract applies inside the stream |
| [7.9](#79--in-reject-mode-a-refused-result-travels-as-an-error-event) | in reject mode a refused result travels as an error event |
| [7.10](#710--hanging-up-cancels-the-backend) | hanging up cancels the backend |
| [7.11](#711--the-same-tool-without-a-stream-scenario-is-plain-json) | the same tool without a stream scenario is plain JSON |
| [7.12](#712--a-streamed-resource-read-relays-the-same-way) | a streamed resource read relays the same way |

**[Block 8 · The protocol, both eras](#block-8--the-protocol-both-eras)** — a legacy client and a 2026-07-28 one are both served, and a malformed request is told exactly what is wrong

| # | What it proves |
|---|---|
| [8.1](#81--a-request-that-declares-no-version-works) | a request that declares no version works |
| [8.2](#82--the-modern-era-with-the-header-and-the-client-capabilities) | the modern era, with the header and the client capabilities |
| [8.3](#83--the-modern-era-without-the-client-capabilities-is-refused) | the modern era without the client capabilities is refused |
| [8.4](#84--the-header-and-the-body-disagreeing-on-the-version-is-a-mismatch) | the header and the body disagreeing on the version is a mismatch |
| [8.5](#85--mcp-method-not-matching-the-body-is-a-mismatch-too) | Mcp-Method not matching the body is a mismatch too |
| [8.6](#86--a-version-nobody-implements-comes-back-with-the-list-of-the-ones-that-are) | a version nobody implements comes back with the list of the ones that are |
| [8.7](#87--an-unsupported-method-is-http-404) | an unsupported method is HTTP 404 |
| [8.8](#88--an-unknown-tool-is--32602-not--32601) | an unknown tool is -32602, not -32601 |
| [8.9](#89--get-and-delete-on-the-endpoint-are-405-with-allow-post) | GET and DELETE on the endpoint are 405 with Allow: POST |
| [8.10](#810--a-notification-is-202-with-no-body) | a notification is 202 with no body |
| [8.11](#811--every-result-is-stamped) | every result is stamped |
| [8.12](#812--a-catalogue-over-a-page-comes-back-with-a-cursor) | a catalogue over a page comes back with a cursor |
| [8.13](#813--subscriptionslisten-acknowledges-the-three-catalogues) | subscriptions/listen acknowledges the three catalogues |
| [8.14](#814--editing-the-resources-of-a-spec-notifies-only-that-catalogue) | editing the resources of a spec notifies only that catalogue |
| [8.15](#815--changing-a-plan-notifies-nothing) | changing a plan notifies nothing |
| [8.16](#816--a-long-operation-answers-with-a-handle) | a long operation answers with a handle |
| [8.17](#817--another-consumers-handle-answers-like-an-unknown-one) | another consumer's handle answers like an unknown one |
| [8.18](#818--revoking-the-tool-refuses-the-next-poll) | revoking the tool refuses the next poll |
| [8.19](#819--a-restart-recovers-the-tasks-in-flight) | a restart recovers the tasks in flight |
| [8.20](#820--initialize-negotiates-a-version-it-supports) | initialize negotiates a version it supports |
| [8.21](#821--a-declared-outputschema-always-comes-back-as-structuredcontent-and-it-is-an-object) | a declared outputSchema always comes back as structuredContent, and it is an object |

**[Block 9 · Endpoints, browsers, and two MCPs sharing a name](#block-9--endpoints-browsers-and-two-mcps-sharing-a-name)** — the aggregate endpoint and the per-MCP ones, discovery, CORS, and a name two MCPs both declare

| # | What it proves |
|---|---|
| [9.1](#91--the-aggregate-endpoint-serves-every-mcp-the-subscription-allows) | the aggregate endpoint serves every MCP the subscription allows |
| [9.2](#92--a-per-mcp-endpoint-serves-only-its-own) | a per-MCP endpoint serves only its own |
| [9.3](#93--a-tool-of-another-mcp-through-the-wrong-endpoint-says-where-it-lives) | a tool of another MCP through the wrong endpoint says where it lives |
| [9.4](#94--a-context-nobody-declares-is-404) | a context nobody declares is 404 |
| [9.5](#95--an-mcp-added-while-it-runs-gets-its-endpoint-on-the-next-request) | an MCP added while it runs gets its endpoint on the next request |
| [9.6](#96--the-protected-resource-metadata-is-served) | the protected resource metadata is served |
| [9.7](#97--the-authorization-server-metadata-is-served-where-the-server-listens) | the authorization server metadata is served where the server listens |
| [9.8](#98--with-cors-off-a-preflight-changes-nothing) | with CORS off, a preflight changes nothing |
| [9.9](#99--with-cors-on-an-allowed-origin-is-echoed-exactly) | with CORS on, an allowed origin is echoed exactly |
| [9.10](#910--an-origin-that-is-not-on-the-list-gets-nothing) | an origin that is not on the list gets nothing |
| [9.11](#911--a-name-two-mcps-declare-is-listed-twice-qualified) | a name two MCPs declare is listed twice, qualified |
| [9.12](#912--a-per-mcp-catalogue-has-nothing-to-qualify) | a per-MCP catalogue has nothing to qualify |
| [9.13](#913--calling-it-bare-is-409-and-the-answer-names-both-remedies) | calling it bare is 409, and the answer names both remedies |
| [9.14](#914--the-qualified-name-resolves-and-to-the-right-mcp) | the qualified name resolves, and to the right MCP |
| [9.15](#915--the-endpoint-of-that-mcp-disambiguates-just-as-well) | the endpoint of that MCP disambiguates just as well |
| [9.16](#916--a-consumer-authorised-on-one-of-the-two-never-sees-an-ambiguity) | a consumer authorised on one of the two never sees an ambiguity |
| [9.17](#917--resources-and-prompts-resolve-exactly-the-same-way) | resources and prompts resolve exactly the same way |
| [9.18](#918--by-uri-there-is-never-an-ambiguity) | by uri there is never an ambiguity |
| [9.19](#919--the-short-dashboard-url-lists-the-candidates-instead-of-a-404) | the short dashboard url lists the candidates instead of a 404 |
| [9.20](#920--the-namespaced-url-is-the-canonical-one) | the namespaced url is the canonical one |
| [9.21](#921--the-consumer-page-counts-the-two-homonyms-apart) | the consumer page counts the two homonyms apart |
| [9.22](#922--the-console-offers-the-two-as-two-checkboxes) | the console offers the two as two checkboxes |
| [9.23](#923--apart-from-the-catalogue-the-two-endpoints-are-the-same-gateway) | apart from the catalogue, the two endpoints are the same gateway |

**[Block 10 · Operating it](#block-10--operating-it)** — the console writes, the dashboard reads, both are behind their key, and a stop is orderly

| # | What it proves |
|---|---|
| [10.1](#101--the-console-shows-the-live-configuration-and-one-url-with-key-is-enough-to-navigate-it) | the console shows the live configuration |
| [10.2](#102--the-console-with-no-key-is-401) | the console with no key is 401 |
| [10.3](#103--the-writes-are-behind-the-same-gate) | the writes are behind the same gate |
| [10.4](#104--changing-the-access-key-applies-hot-and-every-cookie-dies-with-it) | changing the access key applies hot |
| [10.5](#105--a-plan-saved-from-the-console-applies-and-the-previous-file-is-kept) | a plan saved from the console applies, and the previous file is kept |
| [10.6](#106--invalid-json-in-the-raw-editor-is-refused-and-nothing-is-written) | invalid JSON in the raw editor is refused, and nothing is written |
| [10.7](#107--a-spec-edited-by-hand-is-picked-up-by-the-watcher) | a spec edited by hand is picked up by the watcher |
| [10.8](#108--the-dashboard-shows-the-tiles-and-one-table-per-primitive) | the dashboard shows the tiles and one table per primitive |
| [10.9](#109--the-transaction-list-names-the-primitive-and-its-kind) | the transaction list names the primitive and its kind |
| [10.10](#1010--a-transaction-shows-the-pipeline-and-the-payloads-masked) | a transaction shows the pipeline and the payloads, masked |
| [10.11](#1011--the-same-data-is-available-as-json) | the same data is available as JSON |
| [10.12](#1012--the-dashboard-with-no-key-is-401-too-and-hands-out-no-cookie) | the dashboard with no key is 401 too |
| [10.13](#1013--sigterm-runs-the-orderly-shutdown) | SIGTERM runs the orderly shutdown |
| [10.14](#1014--starting-again-finds-the-history-and-the-quotas-where-they-were) | starting again finds the history and the quotas where they were |
| [10.15](#1015--the-run-left-the-repository-alone) | the run left the repository alone |
| [10.16](#1016--a-secret-set-from-the-console-applies-hot-and-otsjson-is-untouched) | a secret set from the console applies hot, and ots.json is untouched |
| [10.17](#1017--a-referenced-secret-cannot-be-deleted-an-orphan-can) | a referenced secret cannot be deleted; an orphan can |

**[Block 11 · The debugger](#block-11--the-debugger)** — a breakpoint holds the call until somebody
lets it go, on every destination the gateway has.

| # | What it proves |
|---|---|
| [11.1](#111--it-is-off-unless-it-is-asked-for-and-loud-when-it-is-on) | it is off unless it is asked for, and loud when it is on |
| [11.2](#112--an-armed-box-stops-the-call-and-the-state-says-what-is-waiting) | an armed box stops the call, and the state says what is waiting |
| [11.3](#113--the-journal-measures-the-gateway-not-the-person-reading) | the journal measures the gateway, not the person reading |
| [11.4](#114--aborting-answers-the-agent-with-an-error) | aborting answers the agent with an error |
| [11.5](#115--a-caller-that-hangs-up-ends-the-pause-at-once) | a caller that hangs up ends the pause at once |
| [11.6](#116--the-timeout-releases-it-and-says-it-was-not-a-person) | the timeout releases it, and says it was not a person |
| [11.7](#117--past-the-ceiling-a-call-is-not-paused) | past the ceiling a call is not paused |
| [11.8](#118--the-mock-is-a-destination-too-and-says-so) | the mock is a destination too, and says so |
| [11.9](#119--a-resource-read-stops-as-well-on-its-own-box) | a resource read stops as well, on its own box |
| [11.10](#1110--a-query-stops-before-it-is-bound-showing-the-arguments) | a query stops before it is bound, showing the arguments |
| [11.11](#1111--a-pause-carries-what-the-agent-asked-not-only-what-is-leaving) | a pause carries what the agent asked, not only what is leaving |

**[Extra checks](#extra-checks)** — ground the ordered plan does not walk: the packaging, the
external provider, the second spelling of things.

| # | What it proves |
|---|---|
| [E1](#e1--packaging-one-binary-per-platform-with-its-checksum) | Packaging: one binary per platform, with its checksum |
| [E2](#e2--client_secret_basic-at-the-token-endpoint) | client_secret_basic at the token endpoint |
| [E3](#e3--the-other-two-refusals-of-the-token-endpoint) | The other two refusals of the token endpoint |
| [E4](#e4--the-authorization-server-on-its-own-port-and-back) | The authorization server on its own port, and back |
| [E5](#e5--cors-on-the-token-endpoint-and-the-discovery-documents) | CORS on the token endpoint and the discovery documents |
| [E6](#e6--the-plan-is-charged-to-the-rule-not-to-the-credential) | The plan is charged to the rule, not to the credential |
| [E7](#e7--how-a-call-got-in-is-in-the-trace-not-in-the-log) | How a call got in is in the trace, not in the log |
| [E8](#e8--the-external-half-against-a-real-provider) | The external half, against a real provider |
| [E9](#e9--credentials-added-and-removed-from-the-console-hot) | Credentials added and removed from the console, hot |
| [E10](#e10--the-tolerant-spellings-still-load) | The tolerant spellings still load |
| [E11](#e11--the-script-status-restart-and-a-stop-that-is-not-a-kill) | The script: status, restart and a stop that is not a kill |
| [E12](#e12--the-whole-token-validation-matrix) | The whole token-validation matrix |
| [E13](#e13--the-discovery-chain-walked-end-to-end) | The discovery chain, walked end to end |
| [E14](#e14--the-mock-inheriting-the-top-level-auth_server) | The mock inheriting the top-level auth_server |

---

## Block 0 · Preparation

> **What this block proves.** It compiles, it starts, and it says out loud what it loaded and where it listens

Nothing here needs a running gateway except from 0.5 on. Start with a clean log if you can
(`mv logs/otsgateway.log logs/otsgateway.log.old`), because three of these cases read it.

### 0.1 · go vet is clean before anything is trusted

*the compiler is happy and so is the vetter: a build that vets dirty is not a build to test*

```bash
go vet ./...
```

**Passes when** it prints nothing and exits `0`. `./otsgateway.sh -compile <tag>` runs it for you and refuses to build if it complains.

### 0.2 · the binary reports its version and platform

*the binary you are about to test is the one you just built*

```bash
./otsgateway.sh -compile macos-arm64      # or the tag of your machine
./otsgateway -version
```

**Passes when** `OTS Gateway 1.0.0 · darwin/arm64 · commit <sha> · built <date>`, and the commit matches `git rev-parse --short HEAD`.

### 0.3 · the secret store is in place

*the env: references of ots.json have somewhere to resolve from*

```bash
ls -l secrets.json || cp ejemplo/secrets.json secrets.json
python3 -c "import json;print(sorted(json.load(open('secrets.json'))['secrets']))"
```

**Passes when** the file exists with permissions `600` and carries a value for every name
`ots.json` references. The startup then says `🔐 secrets.json: N secreto(s) para M
referencia(s) de ots.json`, and a name that is missing refuses the boot — case 0.10.

### 0.4 · ots.json carries no literal secret

*every secret in the file is an env: reference, so the file can be read by anyone*

```bash
grep -n '"env:' ots.json
```

**Passes when** six lines: the two `jwt_secret` values and the WSO2 pair on each of the two backends. What matters is that no `jwt_secret`, `consumer_key` or `consumer_secret` holds a literal.

### 0.5 · it starts and answers

*the whole thing comes up and serves a catalogue*

```bash
./otsgateway.sh -start macos-arm64
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** `✅ OTS Gateway levantado con éxito (PID: N)` and the catalogue comes back with HTTP `200`.

### 0.6 · it binds every port it announced

*what the log says it is listening on is what the operating system says too*

```bash
./otsgateway.sh -status
```

**Passes when** the PID and one line per port it really holds: `*:3001` console, `*:3082` gateway, `*:3083` mock, `*:3085` dashboard, `*:3086` authorization server.

### 0.7 · a port already taken is caught, and says so

*a listener that could not bind must not be discovered by an agent instead*

```bash
grep -i 'address already in use' logs/otsgateway.log
```

**Passes when** nothing. If a line appears, something else holds that port — on this machine `llama-server` has been known to hold `3085` — and every case of that component below will fail for that reason and no other.

> `lsof -nP -iTCP -sTCP:LISTEN | grep -E '3001|3082|3083|3085|3086'` names the process holding it.

### 0.8 · the startup log states the catalogue it loaded

*the gateway tells you what it read, primitive by primitive, before anybody calls it*

```bash
grep -E 'Tool cargada|Resource cargado|Prompt cargado|📦 Catálogo' logs/otsgateway.log
```

**Passes when** one line per primitive with the MCP it belongs to and the backend name it translates to, and then `📦 Catálogo: 7 tools, 2 resources y 2 prompts desde los specs`.

### 0.9 · no 🚨: both UIs have their access key

*neither the console nor the dashboard came up open*

```bash
grep -E '⚠️|🚨' logs/otsgateway.log
```

**Passes when** no `🚨` at all. The `⚠️` lines are the expected ones: `transferir_dinero` with a scope requirement made moot by an alternative with none, and `tls_skip_verify` on the backend.

> `🚨` is reserved for the console with no `access_key`, because the console **writes** the configuration.

### 0.10 · an env: reference with the variable unset refuses the boot, naming it

*a server that cannot resolve a secret must not come up without it*

**Setup** ✎ — the name must be missing from **both** sources: not in `secrets.json` and not exported. Case 0.10 uses a name nothing defines, so neither applies.

```bash
env -u OTS_JWT_SECRET ./otsgateway -config ots.json
```

**Passes when** it exits without listening and names the variable: *environment variable OTS_JWT_SECRET is empty and ots.json requires it*.

---

## Block 1 · What the loader must refuse

> **What this block proves.** A bad configuration is refused with the reason, and the previous one keeps serving

Every case is one edit, a reload, and a look at the log. **Back the file up once before the block**
and put it back at the end:

```bash
cp ots.json ots.json.plan-backup
cp boti-bank-ots.yaml boti-bank-ots.yaml.plan-backup
tail -f logs/otsgateway.log      # in another terminal: this block is read from the log
```

A refused reload prints three things — `⛔ recarga rechazada`, one `❌` per problem, and
`⚠️ la recarga automática no se aplicó; se mantiene la configuración anterior` — and the gateway
keeps answering with what it had. That last part is the half worth checking: after each case, a
`tools/list` must still work.

### 1.1 · a subscription on a plan that does not exist

*a typo in key_plan must not silently fall back to some default*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
python3 - <<'PY'
import json,io
c=json.load(io.open("ots.json"))
c["subscriptions"][0]["security"][0]["key_plan"]="no-existe"
json.dump(c,io.open("ots.json","w"),indent=2)
PY
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … references plan "no-existe", which does not exist in "plans"`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.2 · the same api_key on two consumers

*one credential must identify one consumer, or the quota and the trace mean nothing*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# give the second consumer the api_key of the first, by hand or:
python3 - <<'PY'
import json,io
c=json.load(io.open("ots.json"))
first=c["subscriptions"][0]["security"][0]["auth_method"][0]["api_key"]
c["subscriptions"][1]["security"][0]["auth_method"][0]["api_key"]=first
json.dump(c,io.open("ots.json","w"),indent=2)
PY
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … the same api_key is assigned to … and …`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.3 · a security rule with no auth_method

*a rule nobody can authenticate against is a rule that grants nothing, silently*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json, on the rule of a subscription:
#   "auth_method": []
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … has a security rule with no auth_method`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.4 · a plan whose rate_per_second is zero

*a plan that lets nothing through is always a mistake, never an intent*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "plans": { "free": { "rate_per_second": 0, … } }
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … has rate_per_second <= 0: it would block every request`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.5 · an hourly quota above the daily one can never bind

*the hourly cap is dead code when the day runs out first: it is a configuration slip*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "free": { "quota_hourly": 900, "quota_daily": 100, … }
```

**Passes when** it **starts**, and warns: `⚠️ … the hourly cap can never bind`. This one is a slip worth telling you about, not a reason to refuse the file.

### 1.6 · an hourly token budget above the daily one

*the same slip on the context budget*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "free": { "tokens_hourly": 900, "tokens_daily": 100, … }
```

**Passes when** it **starts**, and warns: `⚠️ … the hourly budget can never bind`. This one is a slip worth telling you about, not a reason to refuse the file.

### 1.7 · a per-call cap above the hourly budget

*a per-call cap nothing can ever reach protects nothing*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "free": { "max_tokens_per_call": 5000, "tokens_hourly": 900, … }
```

**Passes when** it **starts**, and warns: `⚠️ … the per-call cap can never bind`. This one is a slip worth telling you about, not a reason to refuse the file.

### 1.8 · the port written two ways, with two different values

*port and server_port are one field with two spellings; two values is a question with no answer*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json, under otsgateway, both at once:
#   "port": "3082", "server_port": "19999"
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … they are the same field written two ways, so declare one`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.9 · the authorization server on the port of the dashboard

*two listeners on one port is one listener and one silent failure*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "auth_server": { "internal": { "port": "3085" } }   # the dashboard port
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … which is already the dashboard`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.10 · the token endpoint on a path the gateway already serves

*a token endpoint that shadows the MCP endpoint takes the whole gateway down with it*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "auth_server": { "internal": { "token_endpoint": "/mcp/messages" } }
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … cannot be … that path is already served`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.11 · a replica that is not an absolute http(s) address

*a replica is dialled directly: a relative or malformed address fails only at the worst moment*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json, on a backend_server entry:
#   "replicas": ["no-soy-una-url"]
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … which is not an absolute http(s) address`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.12 · a replica equal to another backend_server entry

*the entries of backend_server are different destinations, not copies of one*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json, pointing a replica at the url of the second entry:
#   "backend_server": [ { "url": "…/mcp", "replicas": ["…/ext"] }, { "url": "…/ext" } ]
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … the entries of that array are different destinations, not copies`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.13 · an api_key that looks hashed but is malformed

*sha256: with the wrong shape would silently never match, which reads as a wrong password forever*

**Setup** ✎ — edit `ots.json` as shown and wait for the watcher (`watch_interval_sec`, 5 s by default).

```bash
# in ots.json:
#   "api_key": "sha256:only-two-parts"
```

**Passes when** the reload is **refused**: `⛔ recarga rechazada` and `❌ … an api_key that looks hashed but is malformed`, and the previous configuration keeps serving — `call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'` still answers `200`.

### 1.14 · two MCPs declaring the same resource uri

*a name may repeat across MCPs; an address may not, because resources/read addresses by uri and a uri carries no MCP*

**Setup** ✎ — the `weather` MCP has to be configured — see block 9.

```bash
# in weather-ots.yaml, give politica_privacidad the uri of the botibank one:
sed -i.bak 's|ots://weather/politica-privacidad|ots://botibank/politica-privacidad|' weather-ots.yaml
```

**Passes when** the reload is **refused**: `❌ the uri "ots://botibank/politica-privacidad" is declared by weather.politica_privacidad and by botibank.politica_privacidad: a name may repeat across MCPs, an address may not`. Put it back with `mv weather-ots.yaml.bak weather-ots.yaml`.

### 1.15 · a resource with neither uri nor uriTemplate

*a resource no client could ever address is not a resource*

```bash
# in a spec, delete the uri: line of a resource and reload
```

**Passes when** the reload is **refused**: `❌ … declares neither uri nor uriTemplate: an MCP client could never address it`.

### 1.16 · protocol: stdio is not an HTTP backend

*the gateway speaks HTTP to its backends; stdio is a transport it cannot reach*

```bash
# in a spec, in the servers block:
#   - protocol: stdio
```

**Passes when** the reload is **refused**: `❌ … declares protocol: stdio, which is not an HTTP backend and the gateway cannot reach`.

### 1.17 · a resource with neither example nor backend warns by name

*a primitive that has nothing to answer with must be named at startup, not discovered by an agent*

```bash
grep 'nothing to answer with' logs/otsgateway.log
```

**Passes when** one `⚠️` line naming the resource. It **starts**: the rest of the catalogue is fine, and a read on that one is `501`, which is case 5.13.

### 1.18 · a document-level security warns, one line per primitive that inherits it

*a scope declared once at the top silently applies to everything: that has to be visible*

```bash
# at the top level of a spec:
#   security:
#     - UserDelegationOAuth: ["bank:docs:read"]
grep 'bank:docs:read' logs/otsgateway.log
```

**Passes when** one `⚠️` line per resource and prompt that inherits it, by name, so nothing gains a scope requirement invisibly.

### 1.19 · two MCPs declaring the same tool NAME is allowed

*you do not choose what a third party calls its tools: a shared name is a warning, not a failure*

```bash
grep 'is declared by' logs/otsgateway.log
```

**Passes when** `⚠️ the tool "consultar_cuentas" is declared by botibank and by weather: a call naming it resolves through the subscription, or through the endpoint of one of them` — and the gateway **starts**. Block 9 is how it resolves.

### 1.20 · an outputSchema of type array is refused

*no MCP client can accept one, so failing at load beats failing on the first call*

```bash
# ✎ in a spec, set a tool's outputSchema to type: "array" and wait for the watcher
grep '❌' logs/otsgateway.log | tail -2
```

**Passes when** the reload is **refused** with *declares an outputSchema of type array, which no MCP
client can accept*, and the message carries the YAML to write instead. Case 8.21 is the rule this
enforces.

---

## Block 2 · Credentials

> **What this block proves.** An api key, an oauth2 token and a stored hash all get in, and nothing else does

Two mechanisms live on the same endpoint, and a credential is only ever compared in constant time.
Get a token once, the other cases reuse it:

```bash
TOKEN=$(curl -s -X POST $AUTH -d grant_type=client_credentials \
        -d client_id=$CID -d client_secret=$CSEC | python3 -c 'import json,sys;print(json.load(sys.stdin)["access_token"])')
```

### 2.1 · no credential: 401 with both challenges

*a client that arrives with nothing is told both ways in: the bearer token and the api key*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -20
```

**Passes when** HTTP `401` with **two** `WWW-Authenticate` headers: `Bearer resource_metadata="…/.well-known/oauth-protected-resource"` and `ApiKey realm="ots-gateway"`.

### 2.2 · the api key of the subscription gets the catalogue

*the simplest credential works, and what comes back is this consumer's catalogue*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python3 -m json.tool
```

**Passes when** HTTP `200` and the three tools of `c0`: `listar_clientes`, `consultar_cuentas`, `listar_servicios`.

### 2.3 · a wrong api key is refused

*a key nobody declares gets nothing, and takes the same time as a right one*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' -H 'X-API-Key: no-vale' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -5
```

**Passes when** HTTP `401`. The comparison is constant time, so timing the two does not tell them apart — that is not assertable from a shell, only readable in the code (`secretMatches`).

### 2.4 · the internal authorization server issues a token

*the gateway can mint its own tokens for the oauth2 client of a subscription*

```bash
curl -s -X POST $AUTH -d grant_type=client_credentials \
  -d client_id=$CID -d client_secret=$CSEC | python3 -m json.tool
```

**Passes when** `access_token`, `token_type: Bearer`, `expires_in: 3600` and a `scope` built from the subscription.

### 2.5 · that token authenticates on the same endpoint

*the two mechanisms coexist: nothing has to be switched over*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python3 -m json.tool
```

**Passes when** HTTP `200` and the same catalogue as 2.2: the credential decides the consumer, not the mechanism.

### 2.6 · a token with one character changed does not verify

*the signature is checked, not merely parsed*

```bash
BROKEN=$(python3 -c '
import sys
h,_,s=sys.argv[1].rpartition(".")
i=len(s)//2
print(h+"."+s[:i]+("a" if s[i]!="a" else "b")+s[i+1:])' "$TOKEN")
curl -si -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $BROKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -5
```

**Passes when** HTTP `401` *the token signature does not verify*.

> Change a character in the **middle** of the signature. The last one carries only a couple of significant bits, so replacing it can decode to the same bytes and prove nothing.

### 2.7 · a token signed with alg: none is refused

*the oldest JWT attack there is: an unsigned token claiming to be signed*

```bash
NONE=$(python3 -c '
import base64,json
b=lambda o: base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b"=").decode()
print(b({"alg":"none","typ":"JWT"})+"."+b({"sub":"c0","exp":9999999999})+".")')
curl -si -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $NONE" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -5
```

**Passes when** HTTP `401` *unsupported signing algorithm*.

### 2.8 · a wrong client_secret is invalid_client, and the retries are throttled

*guessing a secret has to be expensive, and the answer must not say which half was wrong*

```bash
curl -s -X POST $AUTH -d grant_type=client_credentials -d client_id=$CID -d client_secret=mal
for i in $(seq 1 14); do
  curl -s -o /dev/null -w '%{http_code} ' -X POST $AUTH \
    -d grant_type=client_credentials -d client_id=$CID -d client_secret=mal
done; echo
```

**Passes when** the first is `invalid_client` — it never says whether the id or the secret was wrong — and within fourteen attempts the codes turn into `429`: `bot_detection` is `rate_per_minute: 10, burst: 5`.

### 2.9 · -hash prints a different value each time

*the salt is per credential, so two consumers with the same secret do not collide in the file*

```bash
./otsgateway -hash 'default-key-1235'
./otsgateway -hash 'default-key-1235'
```

**Passes when** two different `sha256:<salt>:<digest>` strings. Both authenticate the same secret; neither can be turned back into it.

### 2.10 · a hashed api_key authenticates the real key, and only the real key

*hashing a credential changes how it is stored, not how it is used*

**Setup** ✎ — replace the `api_key` of `c0` with the hash and wait for the watcher.

```bash
HASHED=$(./otsgateway -hash 'default-key-1235')
# put $HASHED in place of the literal api_key of c0 in ots.json, wait for the watcher, then:
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H 'X-API-Key: otra' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** `200` for the real key and `401` for any other. Put the literal back afterwards, or every other case in this document needs the new value.

### 2.11 · the operator surfaces show a hash as a hash

*a hashed credential can never be read back, and the UI must say so rather than show a mask*

**Setup** ✎ — the same as 2.10.

```bash
curl -s "$DASH/consumer/c0?key=$DKEY" | grep -o 'hashed[^<]*'
```

**Passes when** `hashed (sha256)` where a masked value would otherwise be, and the secret itself appears nowhere in the page.

### 2.12b · the old oauth.subject is migrated, and never written back

*a dead field that reappears every time you save is worse than a dead field*

```bash
# ✎ put the old shorthand into a consumer and wait for the watcher:
#   "oauth": { "subject": "agente-antiguo" }
grep 'oauth.subject' logs/otsgateway.log | tail -1
# then save anything from the console, and look for it again
python3 -c "import json;print(json.load(open('ots.json'))['subscriptions'][0]['security'][0].get('oauth','gone'))"
```

**Passes when** the reload **warns** — *still uses oauth.subject: it now belongs in auth_method as
`{"oauth2": {"client_id": …}}`* — the gateway keeps serving, and after the save the field reads
`gone`. It used to come back on every write: `omitempty` does nothing to a struct, so the field was
serialised as `"oauth": {}` into every rule of the file.

### 2.12 · a credential created from the console is shown once and stored hashed

*the console generates 32 random hex characters, shows them once, and keeps only the hash*

**Setup** ✎ — `console.hash_new_credentials` is `true` in this repository.

```bash
curl -s -X POST "$CONSOLE/method/add?key=$CKEY" -d 'consumer=0' -d 'rule=0' -d 'kind=api_key' \
  | grep -o 'only time it can be read'
grep -o '"api_key": "sha256:[^"]*' ots.json
```

**Passes when** the banner carries the new key **once** plus *It is stored hashed: this is the only time it can be read*, and `ots.json` gets a `sha256:` value. Delete the credential from the console afterwards.

### 2.13 · a credential that lives in the store authenticates like any other

*a credential field may hold the value or point at a name; nothing downstream knows the difference*

```bash
# the field says env:NAME …
python3 -c "import json;print(json.load(open('ots.json'))['subscriptions'][0]['security'][0]['auth_method'])"
# … and the value is in the store
python3 -c "import json;print(sorted(json.load(open('secrets.json'))['secrets']))"
# and the credential works
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** the call is `200` and the **value never appears in `ots.json`** — `grep` it and
find nothing. Any credential field takes the three forms: a literal, `sha256:…`, or `env:NAME`.

### 2.14 · a reference nobody defines refuses the reload, naming it

*a server that cannot resolve a credential must not come up with an empty one*

```bash
# ✎ remove a name from secrets.json that ots.json references, and wait for the watcher
grep -E 'recarga rechazada|❌' logs/otsgateway.log | tail -3
```

**Passes when** the reload is **refused**, the message names the missing secret and says where to put
it (*add it to secrets.json, or export it*), and the previous configuration keeps serving. Put the
entry back and the next reload is accepted.

### 2.15 · with a name in both places the environment wins

*the environment is the deliberate override; the file is the default store — and finding that out by debugging costs an afternoon*

```bash
OTS_JWT_SECRET=desde-el-entorno ./otsgateway -config ots.json 2>&1 | grep -i 'also in the environment'
```

**Passes when** the startup warns *the secret "OTS_JWT_SECRET" is defined in secrets.json and also in
the environment: the environment wins*. That is why `otsgateway.sh` no longer sources anything: with
the store in place, an environment variable means somebody put it there on purpose.

### 2.16 · a value that is itself a reference is refused

*a name pointing at another name is either a cycle or a secret that silently resolves to nothing*

```bash
# ✎ in secrets.json, set a value to "env:SOMETHING_ELSE" and wait for the watcher
grep '❌' logs/otsgateway.log | tail -1
```

**Passes when** the reload is refused: *the secret "…" in secrets.json is itself an env: reference: a
value cannot point at another name*.

### 2.17 · an api key presented as a bearer token is accepted

*most MCP clients have a single "API key" field and send whatever goes in it as `Authorization: Bearer …`*

```bash
curl -s -o /dev/null -w 'key as bearer: %{http_code}\n' -X POST $GW \
  -H 'Content-Type: application/json' -H "Authorization: Bearer default-key-1235" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
curl -s -o /dev/null -w 'garbage:       %{http_code}\n' -X POST $GW \
  -H 'Content-Type: application/json' -H 'Authorization: Bearer no-vale' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** the key works as a bearer (`200`) and anything that is neither a token nor a key is
still `401`. A JWT is three dot-separated parts; a bearer that is not one is tried as an API key, in
constant time like every other credential. `X-API-Key` keeps working exactly as before.

> This is what a client hitting *the access token is not valid: the token is not a JWT* in the log
> was running into: it was sending the key, correctly, in the header its UI offers.

---

## Block 3 · Authorisation: the two gates

> **What this block proves.** The subscription and the contract scopes both filter, and what a credential cannot use it cannot see

There are two independent gates on every call, and **both also filter the catalogue** — a primitive
this credential could not use is not advertised to it. The subscription is the first
(`mcps[].{tools,resources,prompts}`), the `security` block of the contract is the second.

Cases 3.7 to 3.14 need a scope on a resource. Add it once, at the top of the block:

```bash
cp boti-bank-ots.yaml boti-bank-ots.yaml.plan-backup
```
```yaml
# ✎ boti-bank-ots.yaml, inside resources:
  politica_privacidad:
    security:
      - UserDelegationOAuth: ["bank:docs:read"]
    title: "Privacy Policy"
    …
```

### 3.1 · tools/list is the subscription, not the spec

*the catalogue an agent sees is what its own subscription allows, never the whole contract*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
```

**Passes when** three tools — `listar_clientes`, `consultar_cuentas`, `listar_servicios` — and not the seven the spec declares. `transferir_dinero` and `pagar_hipoteca` are absent.

### 3.2 · a tool outside the allowlist is refused

*not being listed is not the protection; the call is refused too*

```bash
curl -si -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}' | head -3
```

**Passes when** HTTP `403` and `-33002` *your subscription does not authorise this tool*.

### 3.3 · resources/list and prompts/list follow the same subscription

*the three catalogues are filtered by the same rule, each by its own list*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep '"name"'
call '{"jsonrpc":"2.0","id":1,"method":"prompts/list"}' | grep '"name"'
```

**Passes when** only what `c0` declares in its `resources` and `prompts` lists: `politica_privacidad`, `movimientos_cuenta`, `resumen_mensual`, `guia_creditos`.

### 3.4 · the three lists are independent

*authorising a tool grants neither the documents nor the templates of the same MCP*

**Setup** ✎ — `"resources": []` on the botibank block of `c0`.

```bash
# ✎ empty the resources list of c0, keep its tools, wait for the watcher
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'     | grep -c '"name"'
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep -c '"name"'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
```

**Passes when** the tools still list and still work, `resources/list` comes back **empty**, and the read is `403`.

### 3.5 · saving a subscription that only touches the tools keeps the other two groups

*the console form posts the three groups together, which is exactly how it once erased two of them*

```bash
curl -s -X POST "$CONSOLE/subscription?key=$CKEY" \
  -d 'consumer=0' -d 'rule=0' -d 'key_plan=free' \
  -d 'tools=botibank.listar_clientes' -d 'tools=botibank.consultar_cuentas' \
  -d 'tools=botibank.listar_servicios' \
  -d 'resources=botibank.politica_privacidad' -d 'resources=botibank.movimientos_cuenta' \
  -d 'prompts=botibank.resumen_mensual' -d 'prompts=botibank.guia_creditos' > /dev/null
python3 -c "import json;print(json.load(open('ots.json'))['subscriptions'][0]['security'][0]['mcps'])"
```

**Passes when** the `resources` and `prompts` lists are still there after the save. The checkbox names are `tools`, `resources` and `prompts`, and the rule is addressed by `consumer` + `rule`.

### 3.6 · the wildcard round-trips instead of being expanded

*`*` has to survive a save, or the subscription silently stops authorising whatever the spec gains tomorrow*

```bash
# ✎ tick botibank.* under resources in the console and save, then:
python3 -c "import json;print(json.load(open('ots.json'))['subscriptions'][0]['security'][0]['mcps'])"
```

**Passes when** the file reads `"resources": ["*"]`, not the expanded list of names.

### 3.7 · a scope on a resource warns at startup when a consumer cannot satisfy it

*a call that will always be refused is a configuration problem, and it is visible before anybody makes it*

**Setup** ✎ — the `security` block on `politica_privacidad` shown at the top of this block, and no `scopes` on the api_key of `c0`.

```bash
grep 'bank:docs:read' logs/otsgateway.log
```

**Passes when** `⚠️ consumer "c0" is allowed on the resource "politica_privacidad", whose contract demands bank:docs:read, but its api_key declares no scopes: that call will be refused with 403`.

### 3.8 · the catalogue filters by scope

*what a credential cannot read, it is not told about*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep -c politica_privacidad
```

**Passes when** `0`: the resource is not listed to this key. The other resource still is.

### 3.9 · reading it anyway is 403, naming the scope and challenging for it

*the answer has to tell an agent what to go and get, not merely say no*

```bash
curl -si -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}' | head -12
```

**Passes when** HTTP `403`, `-33002`, `data.requiredScopes: ["bank:docs:read"]`, and the header `WWW-Authenticate: Bearer error="insufficient_scope", scope="bank:docs:read"`.

### 3.10 · an API key does not skip the gate — it carries scopes

*the api key is a credential like any other: it holds scopes, it does not bypass them*

**Setup** ✎ — add `"scopes": ["bank:docs:read"]` to the `api_key` entry of `c0`.

```bash
# ✎ on the api_key entry of c0:
#   { "api_key": "default-key-1235", "scopes": ["bank:docs:read"] }
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep -c politica_privacidad
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
```

**Passes when** it is listed again and the read is `200`. Nothing else changed: the key did not gain a bypass, it gained a scope.

### 3.11 · a broader scope implies the narrower one

*bank covers bank:docs:read, so an operator does not have to enumerate every leaf*

```bash
# ✎ the same entry, with the broader scope:
#   { "api_key": "default-key-1235", "scopes": ["bank"] }
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
```

**Passes when** `200`. The prefix rule is `bank` → `bank:docs` → `bank:docs:read`.

### 3.12 · the token of the internal server carries the scope the resource demands

*a scope no tool demands is still issuable: the resources and prompts are part of the surface*

```bash
curl -s -X POST $AUTH -d grant_type=client_credentials \
  -d client_id=$CID -d client_secret=$CSEC | python3 -m json.tool | grep scope
```

**Passes when** the `scope` string includes `bank:docs:read`, which only the **resource** demands.

### 3.13 · asking for less gets less: the catalogue follows the credential

*a token narrowed at the token endpoint narrows the catalogue too, with no configuration change*

```bash
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "Authorization: Bearer $NARROW" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep '"name"'
```

**Passes when** the resource is listed, and a tool demanding a scope this token does not hold has disappeared from `tools/list` with the same credential.

### 3.14 · a guarded mock enforces the same two gates

*mock mode must not be a way around the governance it exists to demonstrate*

**Setup** ✎ — take the `scopes` back off the api_key of `c0` before the last call, or it legitimately passes.

```bash
# with both halves of mock_server.auth_server off — the default — the mock is OPEN:
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}'
# ✎ mock_server.auth_server.internal.enabled = true, then the same three calls:
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
```

**Passes when** open: `200` for anything, which is what `🔓 Mock abierto` warns about at startup. Guarded: `401` with no credential, `403` on the allowlist, and `403` on the scope — the same pipeline as the gateway.

### 3.15 · a qualified entry carries the scope, and carries it nowhere else

*an allowlist entry can say which scopes the credential shows for that one primitive*

**Setup** ✎ — put `security: [{ UserDelegationOAuth: ["bank:docs:read"] }]` on the resource `politica_privacidad` **and** on the tool `listar_clientes` of `boti-bank-ots.yaml`, leave the api_key of `c0` with no `scopes`, and qualify only the resource:

```json
"resources": [ { "politica_privacidad": ["bank:docs:read"] }, "movimientos_cuenta" ]
```

```bash
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' | jq .error.data
```

**Passes when** the resource answers `200` and the tool is `403` with `requiredScopes: ["bank:docs:read"]`. The same scope and the same credential: granted where the entry says it, refused where it does not.

---

### 3.16 · a bare name still means what it always meant

*the regression this design exists to prevent*

```json
"resources": [ "politica_privacidad", "movimientos_cuenta" ]
```

**Passes when** reading it is `403` again and `resources/list` does not show it. If an unqualified entry meant "no scope check", every allowlist ever written would have become an exemption the day this shipped.

---

### 3.17 · the exemption has to be written: `["*"]` skips the check

```json
"resources": [ { "politica_privacidad": ["*"] }, "movimientos_cuenta" ]
```

**Passes when** the read is `200` and the resource is listed again, with no `scopes` anywhere on the credential. It is the only way past the contract, and it is one `grep` away in `config.json`.

---

### 3.18 · a guarded mock applies the qualification too

**Setup** ✎ — `mock_server.auth_server.internal.enabled = true`, the resource qualified with `["bank:docs:read"]` and the tool left bare.

```bash
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $MOCK -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
```

**Passes when** `200` and `403`: mock mode is not a way around the scopes, qualified or not.

---

### 3.19 · the token of the internal server is capped by the entry

*the issuer may not mint what the subscription says the consumer cannot present*

**Setup** ✎ — qualify both with an empty list: `{ "politica_privacidad": [] }` and `{ "listar_clientes": [] }`.

```bash
curl -s -X POST $AUTH -d grant_type=client_credentials -d "client_id=$CID" -d "client_secret=$CSEC" | jq .scope
```

**Passes when** the token carries no `bank:docs:read`. Qualify them back with `["bank:docs:read"]` and it comes back.

---

### 3.20 · saving from the console does not unqualify what the file says

*the form has no field for scopes and it is the only writer of that block*

```bash
curl -s -o /dev/null -X POST "$CONSOLE/subscription?key=$CKEY" \
  -d 'consumer=0' -d 'rule=0' -d 'key_plan=free' \
  -d 'tools=botibank.listar_clientes' -d 'resources=botibank.politica_privacidad'
jq '.subscriptions[0].security[0].mcps[0].botibank.resources' ots.json
```

**Passes when** the qualified entry comes back qualified and a bare name comes back bare. Without carrying them over, one save would quietly turn every qualified entry into a bare name.

---

### 3.21 · the dashboard shows which entries are qualified

```bash
curl -s "$DASH/consumer/c0?key=$DKEY" | grep -o 'scopes bank:docs:read'
```

**Passes when** the tag reads `botibank.politica_privacidad · scopes bank:docs:read`. A permission that narrows or skips the contract has to be legible where permissions are read, not only in the file.

---

### 3.22 · an entry that is neither a name nor `{name: [scopes]}` is refused

```json
"resources": [ { "politica_privacidad": ["x"], "movimientos_cuenta": ["y"] } ]
```

**Passes when** the reload is refused with *an allowlist entry is a name or {"name": ["scope"]}* and the previous configuration keeps serving. Two keys in one entry is a file that means two things at once.

> **Put the block back**: restore `boti-bank-ots.yaml`, remove the `scopes` from the credential, restore the three lists of `c0`, and turn the mock guard off again.

---

## Block 4 · What a plan costs

> **What this block proves.** Calls and context both cost, the catalogue does not, and the cost survives a restart

The `free` plan of this repository is 2 req/s, burst 5, 60 an hour, 500 a day, 50 000 tokens an
hour, 400 000 a day and 12 000 per call. Four of these cases lower a number to make it bind in
seconds instead of hours — put the plan back at the end.

The token figures are an **estimate**, four bytes to a token: the gateway does not know which model
is on the other side. They measure what it served.

```bash
CALL='{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
quota(){ curl -s "$DASH/api/state?key=$DKEY" \
  | python3 -c 'import json,sys;c=[x for x in json.load(sys.stdin)["consumers"] if x["Name"]=="c0"][0];print(c["Quota"])'; }
```

### 4.1 · the burst binds

*a plan is a limit that actually stops traffic, not a number on a dashboard*

```bash
for i in $(seq 1 8); do
  curl -s -o /dev/null -w '%{http_code} ' -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL"
done; echo
```

**Passes when** the first five pass and the rest are `429`. The refusal carries `Retry-After: 1` and `-33003` — check with `curl -si` on the sixth.

### 4.2 · a second later the bucket has refilled

*the limit is a token bucket, not a lockout*

```bash
sleep 1.5
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL"
```

**Passes when** `200`: it refills at `rate_per_second`.

### 4.3 · the dashboard shows the quota and the token bars

*an operator can see how close a consumer is without reading a log*

```bash
open "$DASH/consumer/c0?key=$DKEY"   # or curl it
```

**Passes when** four bars: calls this hour, calls today, tokens this hour, tokens today, each with its limit and a percentage.

### 4.4 · the catalogue is free

*listing what you may call must not cost what calling it costs, or an agent cannot afford to look*

```bash
quota
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'     > /dev/null
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' > /dev/null
call '{"jsonrpc":"2.0","id":1,"method":"prompts/list"}'   > /dev/null
quota
```

**Passes when** `HourUsed` is the same before and after the three list methods.

### 4.5 · a call, a read and a render each charge one

*the three methods that hand over content are the three that cost*

```bash
quota
call "$CALL" > /dev/null ; sleep 1
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/politica-privacidad"}}' > /dev/null ; sleep 1
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"resumen_mensual","arguments":{"cuenta_id":"CU-001"}}}' > /dev/null
quota
```

**Passes when** `HourUsed` went up by exactly three, and each trace has a `plan quota` step.

### 4.6 · an exhausted hourly quota is 429 with -33004

*the hourly window binds on its own, separately from the rate*

**Setup** ✎ — `plans.free.quota_hourly: 1`.

```bash
# ✎ plans.free.quota_hourly = 1, wait for the watcher
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL"
sleep 1
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL" | python3 -m json.tool
```

**Passes when** the second is `429` with `-33004` *the hourly quota of the plan is exhausted*.

### 4.7 · an exhausted token budget is refused before the backend is touched

*the context budget is a limit on what the agent receives, and it is checked before the work*

**Setup** ✎ — `plans.free.tokens_hourly: 200`.

```bash
# ✎ plans.free.tokens_hourly = 200, wait for the watcher
for i in $(seq 1 8); do
  sleep 1
  curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL" \
    | python3 -c 'import json,sys;d=json.load(sys.stdin);print(d.get("error",{}).get("message","ok"))'
done
```

**Passes when** at some point *the hourly token budget of the plan is exhausted*, and the gateway log shows **no** backend call for that request.

### 4.8 · the last answer may overshoot the budget

*the budget is charged with what was served, so the answer that crosses the line is served whole*

```bash
curl -s "$DASH/consumer/c0?key=$DKEY" | grep -o 'Tokens this hour[^<]*<b[^>]*>[^<]*'
```

**Passes when** a figure over the limit, for example `288 / 200`. That is documented behaviour, not a bug: `max_tokens_per_call` is the knob that refuses **before** serving, and that is case 4.10.

### 4.9 · with the budget spent the catalogue still answers

*an agent that ran out of budget must still be able to see what exists*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -5
```

**Passes when** `200`. The catalogue does not pay, so it never runs out.

### 4.10 · a per-call cap refuses an answer that is too big

*one call must not be able to eat a whole context window*

**Setup** ✎ — `plans.free.max_tokens_per_call: 50`.

```bash
# ✎ plans.free.max_tokens_per_call = 50, wait for the watcher
curl -si -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL" | head -3
curl -s  -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL" | python3 -m json.tool
```

**Passes when** HTTP `413` with `-33004` *the answer of this call is about N tokens, over the 50 the plan allows for a single call*.

> If you ran 4.7 first, raise `tokens_hourly` in the same edit: an hourly budget you already spent answers `429` before the per-call cap gets its turn, and the two limits are different cases.

### 4.11 · every journal line carries its kind and what it served

*the journal is what rebuilds the windows, so it has to hold the numbers*

```bash
tail -1 logs/transactions.jsonl | python3 -m json.tool | grep -E 'kind|TokensServed|QuotaCharged'
```

**Passes when** `kind` is `tool`, `resource` or `prompt`, and `TokensServed` is a number. `QuotaCharged` says whether that line moved the quota.

### 4.12 · a restart does not hand back spent budget

*the windows are rebuilt from the journal, so restarting is not a way to reset a plan*

**Setup** ✎ — `plans.free.quota_hourly: 1` and the quota already spent.

```bash
# ✎ quota_hourly = 1, spend it, then:
./otsgateway.sh -restart macos-arm64
grep 'Diario restaurado' logs/otsgateway.log
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL"
```

**Passes when** `📚 Diario restaurado …` at startup, and the call is still `429`.

> **Put the block back**: `free` is 2 req/s, burst 5, 60/hour, 500/day, 50 000 tokens/hour, 400 000/day, 12 000 per call.

---

## Block 5 · The three primitives

> **What this block proves.** Tools, resources and prompts are catalogued, addressed and answered the same way

MCP has three server primitives and the OTS contract declares all three. What this block proves is
that they are not three code paths: one resolution, one authorisation, one accounting, one trace.

### 5.1 · initialize announces resources and prompts because the spec declares them

*a capability is announced only when there is something behind it, or a client asks and finds nothing*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18"}}'
```

**Passes when** `capabilities` carries `tools`, `resources` and `prompts`, and `serverInfo` names the gateway.

### 5.2 · a capability with nothing behind it is not announced

*the announcement follows the live spec, not the code*

**Setup** ✎ — every `resources:` block emptied at once — which is why the script skips this one.

```bash
# ✎ empty the resources: block of every spec, wait for the watcher, then:
call '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18"}}' | grep -c resources
```

**Passes when** `0`: the capability disappears. Put the block back.

### 5.3 · server/discover carries the three capabilities and the cache hints

*the modern discovery method answers in one round trip what initialize needed a handshake for*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"server/discover"}'
```

**Passes when** the three capabilities with `listChanged: true`, an `authentication` block naming the token endpoint, `resultType: complete`, `ttlMs` and `cacheScope: private`.

### 5.4 · resources/list carries the fixed uris

*a resource with a fixed address is listed; a template is not, because it cannot be read as it stands*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}'
```

**Passes when** `politica_privacidad` with `ots://botibank/politica-privacidad`, plus `ttlMs` and `cacheScope: private`. `movimientos_cuenta` is **not** here.

### 5.5 · resources/templates/list carries the parameterised ones

*a template is instantiated, not read, so it lives in its own catalogue*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/templates/list"}'
```

**Passes when** `movimientos_cuenta` as a `uriTemplate`: `ots://botibank/cuentas/{cuentaId}/movimientos`.

### 5.6 · a fixed resource is answered from its example

*with no backend block declared, the contract itself is the answer*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/politica-privacidad"}}'
```

**Passes when** the body of the `example`, its `mimeType: text/markdown`, and the `ttlMs` + `cacheScope` of a `CacheableResult`.

### 5.7 · a template is instantiated and the variable is bound

*the answer has to carry the uri that was asked for, and the placeholders inside the body too*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/cuentas/CU-001/movimientos"}}'
```

**Passes when** `contents[0].uri` is `ots://botibank/cuentas/CU-001/movimientos` — the one asked for, not the template — and `{cuentaId}` inside the example has become `CU-001`.

### 5.8 · the OTS name is accepted as a shortcut for the uri

*MCP addresses a resource by uri; the name is an OTS courtesy that makes a curl readable*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
```

**Passes when** the same answer as 5.6.

### 5.9 · prompts/list carries the declared arguments

*a template is useless without knowing what it needs*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"prompts/list"}'
```

**Passes when** both prompts, ordered by name, each with its `arguments` and which of them are `required`.

### 5.10 · prompts/get renders the messages with the placeholder bound

*the gateway does the substitution, so the agent gets a finished prompt*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"resumen_mensual","arguments":{"cuenta_id":"CU-001"}}}'
```

**Passes when** `messages` with `{cuenta_id}` replaced by `CU-001`, plus the `title` and `description` of the contract.

### 5.11 · a missing required argument is an error, not a half-rendered template

*a hole left in a prompt reaches the model as an instruction: it has to be refused instead*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"resumen_mensual","arguments":{}}}'
```

**Passes when** `-32602` with `data.missingArguments: ["cuenta_id"]`.

### 5.12 · a uri nobody serves says so

*an unknown address is an invalid parameter, and the message names it*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/no-existe"}}'
```

**Passes when** `-32602` *no resource of this gateway serves "ots://botibank/no-existe"*.

### 5.13 · a resource with nothing to answer with is 501

*an empty body would look like a document that says nothing; 501 says the contract is incomplete*

```bash
# a resource with neither example nor backend, authorised to this consumer:
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/sin-respuesta"}}'
```

**Passes when** HTTP `501` *declares no example and no backend uri: this gateway has nothing to answer with*, and the same resource was named at startup by case 1.17.

> With the **mock on**, the mock is the backend and it is the one that refuses, so the same condition arrives as `502 · -33005` instead. Which of the two you see tells you who answered.

### 5.14 · the dashboard has a page per resource

*an operator can see a document's contract without opening the spec*

```bash
open "$DASH/mcp/botibank/resource/movimientos_cuenta?key=$DKEY"
```

**Passes when** the template with its variables, the mime type, the cache ttl, **who answers it** (mock, backend or contract) and who has read it.

### 5.15 · and a page per prompt

*the same for a template: its arguments, and what it maps to on the backend*

```bash
open "$DASH/mcp/botibank/prompt/guia_creditos?key=$DKEY"
```

**Passes when** the arguments and which are required, the mapping to `loan_guide` and the renamed `riskProfile`, and the messages of the spec.

---

## Block 6 · The backend: translation, failover and the output contract

> **What this block proves.** The contract translates what the agent says into what the backend expects, fails over when it may, and trims what comes back

This block needs calls that really leave the gateway, so **mock off** on the MCP under test and a
backend that answers. If you have no real backend at hand, the script writes a small stand-in that
echoes what it received; `./TESTING-ONE-ONE.sh 6 -keep` leaves it running on `:5205` with a `lab`
MCP wired to it, and these cases then run against `http://127.0.0.1:5200/labots/mcp/messages`.

Failover is per `backend_server` **entry**: `replicas` are copies of one destination, and the other
entries of the array are different destinations, never fallbacks.

### 6.1 · a call reaches the backend, and the trace records the mapping

*the agent says the OTS name and the backend receives its own*

**Setup** ✎ — mock off on that MCP.

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}'
# then open the transaction the dashboard lists last:
open "$DASH/transactions?key=$DKEY"
```

**Passes when** the trace has a step `backend mapping consultar_cuentas → get_cuentas, 1 arguments translated`, and the outbound payload carries `get_cuentas` with `clienteId`.

### 6.2 · a tool with its own server block goes where the contract says

*the destination is a decision of the contract, not of the MCP entry*

```bash
# listar_clientes declares its own server: block; consultar_cuentas does not
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' > /dev/null
open "$DASH/transactions?key=$DKEY"
```

**Passes when** the trace of `listar_clientes` says `target …/botibankext/1.0/mcp · chosen by the tool server block`, and `consultar_cuentas` goes to the document-level server instead.

### 6.3 · a relayed resource reaches the backend under the translated uri

*declaring a backend block is what turns a resource into a relayed one*

**Setup** ✎ — a `backend.uriTemplate` on that resource, and mock off.

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/cuentas/CU-001/movimientos"}}' > /dev/null
open "$DASH/transactions?key=$DKEY"
```

**Passes when** `backend mapping ots://botibank/cuentas/CU-001/movimientos → mcp://core/accounts/CU-001/tx`, with the variable carried across. A resource with **no** backend block still answers from its example — the change was additive.

### 6.4 · a relayed prompt reaches the backend with its arguments renamed

*the same translation applies to the third primitive*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"guia_creditos","arguments":{"perfil_riesgo":"bajo"}}}' > /dev/null
open "$DASH/transactions?key=$DKEY"
```

**Passes when** the backend received `loan_guide` and `riskProfile`, which is what `backend.prompt` and `backend.arguments` declare.

### 6.5 · everything the gateway did not author is marked untrusted

*the host has to be able to tell a document from an instruction, and the gateway is the only one who knows*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}' | grep -A3 _meta
```

**Passes when** `_meta` carries `ots/untrusted: true` and `ots/source` naming who produced it.

### 6.6 · what the contract itself answers is NOT marked

*the example in the spec is written by whoever configures the gateway: it is not third-party content*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://botibank/politica-privacidad"}}' | grep -c untrusted
```

**Passes when** `0`, with the mock off and no backend block on that resource. Under the mock the source is the mock server, which **is** marked.

### 6.7 · the era travels only when the backend declares it

*a backend that never asked for the 2026 headers must not receive them*

```bash
# ✎ backend_server[0].protocol_version = "2026-07-28", then call and read the trace
# ✎ then set it back to "" and call again
```

**Passes when** with the version declared, the outbound payload carries `MCP-Protocol-Version`, `Mcp-Method`, `Mcp-Name` and the `_meta` of that era. With it empty, none of them travel.

### 6.8 · an x-mcp-header argument is mirrored whatever era the backend speaks

*the mirroring is the contract of that tool, not a feature of a protocol version*

**Setup** ✎ — `x-mcp-header: "Cliente"` on the `cliente` property of that tool's `inputSchema`.

```bash
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -H 'Mcp-Param-Cliente: CL-001' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente":"CL-001"}}}'
```

**Passes when** the backend receives `Mcp-Param-Cliente: CL-001`. Note that `x-mcp-header` in the spec holds only the `{name}` half — `"Cliente"` — and the gateway builds `Mcp-Param-Cliente`.

### 6.9 · a dead primary with a live replica: a read is served anyway

*a read cannot have changed anything, so it may always be retried elsewhere*

```bash
# ✎ backend_server[0].url pointed at a port where nothing listens,
# ✎ backend_server[0].replicas = ["<the address that works>"]
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"movimientos_cuenta"}}'
grep failover logs/otsgateway.log
```

**Passes when** the read is `200`, and the log has `⚠️ failover: …, probando la siguiente dirección` followed by a step saying which replica answered.

### 6.10 · a tools/call that does not declare idempotent is NOT retried elsewhere

*a transport error never says whether the request arrived: retrying a payment is worse than failing it*

**Setup** ✎ — the same dead primary as 6.9, and a tool with no `idempotent: true`.

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}'
```

**Passes when** `502` with `-33005`, and **no** failover step: the replica was never tried.

### 6.11 · declaring idempotent: true is what allows the retry

*the contract is what says a call is safe to repeat, and nothing else*

```bash
# ✎ idempotent: true on that tool, then the same call
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
```

**Passes when** `200`, served by the replica, with the failover steps in the trace.

### 6.12 · a backend that answers 500 is not a failover

*a backend that answered is not a backend that is down, even when the answer is bad*

```bash
# a backend that returns HTTP 500, with a replica configured and idempotent: true
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
grep -c failover logs/otsgateway.log
```

**Passes when** the error reaches the agent and the failover count does **not** grow. Only a transport failure or a 502/503/504 tries the next address.

### 6.13 · the dashboard says how many replicas a backend has

*an operator should not have to read the config to know whether a backend has a spare*

```bash
curl -s "$DASH/?key=$DKEY" | grep -o '+[0-9]* replica[^<]*'
```

**Passes when** `+1 replica(s) for failover` next to the backend address of that MCP.

### 6.14 · a field the outputSchema does not declare is trimmed off

*the contract is what the agent was promised; anything else is the backend leaking*

**Setup** ✎ — `output.enforce: "reject"` on that MCP.

```bash
# ✎ mcps[].output.enforce = "reject", and an outputSchema with additionalProperties: false
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}'
```

**Passes when** the undeclared field is gone and the call goes through. **The schema has to be closed**: trimming only happens with `additionalProperties: false`.

### 6.15 · a masked field never leaves whole

*a mask is an explicit instruction of the contract, so it applies in every mode and in both representations*

**Setup** ✎ — `x-ots-mask: "last4"` on that property of the `outputSchema`.

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}' | grep -o 'CTA[^"]*'
```

**Passes when** the value arrives as `•••-122`, in `structuredContent` **and** in the `text` block. The whole value appears nowhere.

### 6.16 · warn mode relays and names the tool in the log

*turning it on audits the contracts without breaking anything, which is how you find out how wrong they are*

```bash
# ✎ output.enforce = "warn"
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}' > /dev/null
grep -i 'outputSchema' logs/otsgateway.log | tail -3
```

**Passes when** the answer goes through untouched except for the masks, and the log names the tool and the field that did not match.

### 6.17 · a backend that never answers is -33005, and the address stays out of the answer

*the agent gets a correlation id; the topology stays inside*

```bash
# ✎ the backend url pointed at a port where nothing listens, no replicas
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
grep "$(…the requestId from the answer…)" logs/otsgateway.log
```

**Passes when** the agent gets `-33005` with a `requestId` and no address, host or port anywhere in the body. The log, under that same `requestId`, has the address and the real error.

> **Put the block back**: the backend urls, `idempotent`, the `enforce` mode and the mock flag.

### A backend that is a query · the whole thing, step by step

Six cases below need a database behind a tool. This is every step from an empty machine to a `curl`
that answers, in the order to do them. It is written against the `consultar_cuentas` of
`boti-bank-ots.yaml`, because that is a tool that already exists and already has both schemas — the
point of the exercise is that **nothing about it changes** when a query starts answering it.

#### 1 · A database

```bash
docker run -d --name mariadb_db \
  -e MARIADB_ROOT_PASSWORD=root -e MARIADB_DATABASE=botibank \
  -e MARIADB_USER=pablo -e MARIADB_PASSWORD=patata \
  -p 3306:3306 mariadb:lts
```

> **Those variables only apply the first time**, when the data directory is empty. Pointing a new
> container at a volume that already exists keeps the **old** credentials and the old database, and
> the symptom is `Access denied` with the password you just set. `docker compose down -v` (the `-v`
> deletes the volume) is what starts clean. To find out what a running container actually has:
> `docker inspect <name> --format '{{range .Config.Env}}{{println .}}{{end}}' | grep -i maria`.

#### 2 · The table

```sql
create table cuentas (
  cuentaId  varchar(20)    not null,
  clienteId char(36)       not null,
  saldo     decimal(12,2)  not null default 0.00,
  tipo      enum('Corriente','Ahorro','Inversión','Sueldo') not null default 'Corriente',
  primary key (cuentaId),
  key idx_cuentas_cliente (clienteId)
) engine=InnoDB default charset=utf8mb4 collate=utf8mb4_unicode_ci;

insert into cuentas (cuentaId, clienteId, saldo, tipo) values
  ('CTA-122', '71992c72-cc1c-4c5a-8b50-9ee4fb6c214d', 1800.50, 'Corriente'),
  ('CTA-123', '71992c72-cc1c-4c5a-8b50-9ee4fb6c214d',  100.00, 'Ahorro'),
  ('CTA-999', '71992c72-cc1c-4c5a-8b50-9ee4fb6c214d',    0.00, 'Inversión');
```

The types come from `components.schemas.Cuenta` of the spec: `cuentaId` and `clienteId` are strings,
`saldo` is a number — `decimal(12,2)`, which the gateway hands over as `1800.5`. The index is on the
column the `where` filters by.

And the user the gateway should connect as, which is **not** the owner of the database:

```sql
create user 'ots_ro'@'%' identified by '…';
grant select on botibank.cuentas to 'ots_ro'@'%';
flush privileges;
```

#### 3 · The query file

`sql/getConsultarCuentasByClienteId.sql`, relative to `ots.json`:

```sql
select cuentaId, clienteId, saldo from cuentas where clienteId = $cliente_id;
```

`$cliente_id` is the name of an argument the tool declares. It is **bound**, never pasted into the
text of the statement.

#### 4 · The secret

```bash
# from the console, or by hand in secrets.json
{ "secrets": { "DB_PASSWORD": "…" } }
```

#### 5 · The backend entry

In `ots.json`, inside the `backend_server` list of that MCP:

```json
{
  "url": "mariadb://127.0.0.1:3306/botibank?getConsultarCuentasByClienteId",
  "type": "database",
  "query_file": "sql/getConsultarCuentasByClienteId.sql",
  "description": "Cuentas de un cliente, desde MariaDB",
  "cache": { "enabled": false },
  "security": { "type": "password", "username": "ots_ro", "password": "env:DB_PASSWORD" }
}
```

Three things in that url, and each one has cost somebody an afternoon:

| Part | What it is |
|---|---|
| `127.0.0.1`, not `localhost` | `localhost` resolves to `::1` first and a container published on `0.0.0.0` is IPv4 only, so the connection is refused before it starts |
| `/botibank` | the **schema**, the database name — not a path, and not the name of anything in the spec |
| `?getConsultarCuentasByClienteId` | a **label** for this entry. It is what makes two queries against the same database two distinct urls, so a `server:` block can point at one of them. It is not the name of the tool |

#### 6 · Point the tool at it

In the spec, on `consultar_cuentas`, the same url the entry declares:

```yaml
    server:
      - protocol: database
        url: "mariadb://127.0.0.1:3306/botibank?getConsultarCuentasByClienteId"
        description: "Cuentas desde la base de datos"
```

**The two urls have to match character for character**, because that is the binding. Everything else
about the tool — its `inputSchema` with `cliente_id`, its `outputSchema` of `Cuenta`, its
`backend.tool` for the day it points at an MCP again — stays exactly as it was.

#### 7 · Start, and read the startup

```bash
./otsgateway.sh -start macos-arm64
grep -E '🔐|❌|📦' logs/otsgateway.log | tail -3
```

**Passes when** the catalogue loads and `🔐 secrets.json: N secreto(s) para M referencia(s)` appears
with no `❌`. If the gateway refuses to start, section *When one fails* at the end of this document
and the table below cover what it says.

#### 8 · The curl

```bash
curl -s -X POST $GW \
  -H 'Content-Type: application/json' \
  -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call",
       "params":{"name":"consultar_cuentas",
                 "arguments":{"cliente_id":"71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"}}}' \
  | python3 -m json.tool
```

**Passes when** the three accounts come back, `saldo` is a **number** (`1800.5`, not `"1800.50"`),
and `_meta` carries `ots/source: "database query"` with `ots/untrusted: true`.

Then, one at a time, the interesting ones:

```bash
# the catalogue says nothing about a database
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep -c mariadb        # → 0

# a client with no accounts: an empty list, because the outputSchema is an array
… "arguments":{"cliente_id":"00000000-0000-0000-0000-000000000000"}            # → []

# an injection: the value is bound, so it matches nothing
… "arguments":{"cliente_id":"'"'"' or '"'"'1'"'"'='"'"'1"}                     # → []

# editing the .sql applies within the watch interval, with no restart
sed -i.bak 's/where clienteId/where 1=1 and clienteId/' sql/getConsultarCuentasByClienteId.sql
```

#### When it does not work

Every one of these was hit while building it, and each says exactly what is wrong:

| The message | What it means |
|---|---|
| `primitive "X" points at the server "…", which is not in the backend_server list` | the url in the `server:` block and the url of the entry differ, or the entry was removed while the spec still names it |
| `dial tcp [::1]:3306: connect: connection refused` (in the log; the agent gets `-33005`) | `localhost` in the url · use `127.0.0.1` |
| `Access denied for user …` | the container's credentials are not the ones in the compose file: it was initialised with a volume that already existed |
| `is a database entry with no query_file` | the entry has `type: database` and no `.sql` |
| `the query of "X" uses $y and the inputSchema does not declare it` | the parameter has to be a declared argument, by name |
| `starts with "delete": only SELECT (or WITH … SELECT) is allowed` | a query file is one `SELECT`, and nothing else |
| `is a database entry no primitive points at` (a warning) | the entry loaded but no `server:` block names it, so nothing will ever run it |

### 6.18 · a tool answered by a query looks like any other tool

*the contract is the contract: a consumer must not be able to tell a query from an MCP server, or swapping one for the other tomorrow breaks it*

```bash
curl -s -X POST $GWDB -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep -ci mariadb
curl -s -X POST $GWDB -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"db_listar","arguments":{}}}' | python3 -m json.tool
```

**Passes when** the catalogue mentions no database at all (`0`), and the result is an ordinary tool
result: `structuredContent`, the same JSON in a `text` block, `resultType: complete`, and
`_meta` carrying `ots/untrusted: true` with `ots/source: "database query"`.

### 6.19 · the outputSchema gives the rows their types

*a MySQL driver hands back "49.90" for a DECIMAL and bytes for text; without the schema every consumer parses strings*

```bash
… tools/call db_listar … | python3 -c 'import json,sys;print(json.load(sys.stdin)["result"]["structuredContent"]["productos"][0])'
```

**Passes when** `precio` is `49.9` (a number), `stock` is `12` (an integer) and `nombre` is a string.

### 6.20 · a column the contract does not declare is trimmed

*the failure a `select *` produces six months later, stopped at the border*

```bash
… tools/call db_listar … | grep -c coste_interno
```

**Passes when** `0`: the query selects it, the contract never promised it, and it does not reach the
model. Needs `output.enforce: "reject"` on that MCP.

### 6.21 · a parameter is bound, never interpolated

*this is the case that decides whether the feature is safe*

```bash
… '{"name":"db_por_id","arguments":{"id":"1 or 1=1"}}'
… '{"name":"db_por_nombre","arguments":{"nombre":"'"'"' or '"'"'1'"'"'='"'"'1"}}'
… '{"name":"db_por_nombre","arguments":{"nombre":"Teclado"}}'
```

**Passes when** the first is `-32602` — an `id` declared `integer` cannot be a string, so the type
check stops it before SQL — the second returns **0 rows**, and the third returns 1. Zero rows on the
injection is the proof: the value reached the database as a string, not as SQL.

### 6.22 · no row on a single-object contract is a tool error

*a product that does not exist is a fact about the data, not a fault of the gateway, and a model has to tell them apart*

```bash
… '{"name":"db_por_id","arguments":{"id":999}}'
```

**Passes when** HTTP `200` with `isError: true` and *the query of this tool matched no row* — not a
`-33005`. More than one row on the same contract **is** an error: that means the query is wrong.

### 6.25 · one backend can be mocked while the rest of its MCP goes out for real

*faking one integration is the normal case; "mock" as an all-or-nothing flag on the MCP could not say it*

```bash
# ✎ in ots.json, give one backend_server entry its own block and wait for the watcher:
#   "mock": { "enabled": true, "delay_ms": 0 }
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' \
  | grep -o '"ots/source":"[^"]*"'
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"}}}' \
  | grep -o '"ots/source":"[^"]*"'
```

**Passes when** the tool served by that backend answers `"ots/source":"mock server"` and the one
served by another answers from its real destination — a database query here. The startup **names
the backend**, not the MCP: *the backend "…" of mcp "…" is mocked … and the other backends of this
mcp still go out*. Removing the block puts that destination back under the flag of its MCP:
`mock` absent and `mock: {enabled: false}` are different answers, which is why it is a pointer.

### 6.23 · the query file is watched, and a bad one is refused

*editing a query is editing how a contract is answered, and it should apply like editing a spec*

```bash
# ✎ change the ORDER BY of the .sql and wait for the watcher
grep 'cambio detectado' logs/otsgateway.log | tail -1
# ✎ then put a DELETE in it
grep '❌' logs/otsgateway.log | tail -1
```

**Passes when** the edit applies within the watch interval and the new order shows in the answer,
and the `DELETE` is **refused** — *only SELECT (or WITH … SELECT) is allowed* — with the previous
query still serving.

### 6.24 · a tool error is relayed whole

*the contract describes the answer, not the failure — and the failure is the only thing that says what broke*

```bash
# with the backend unreachable, or any tool whose backend answers isError
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' | jq '.result'
grep 'contrato de salida' logs/otsgateway.log | tail -1
```

**Passes when** the result comes back with `isError: true` and the backend's own body **complete** —
for an API Manager that cannot reach the core, its four fields:

```json
{"code":"101503","description":"Error connecting to the back end",
 "message":"Runtime Error","type":"Status report"}
```

— and **no** `contrato de salida` line names that call. A failure has the shape the backend chose,
which matches no `outputSchema`: validating it logged *is not declared in the outputSchema* once per
field, and in `reject` mode it would have trimmed the failure down to nothing, leaving the model an
error with no reason in it. Works the same in the three modes, because it is not a policy: the
contract simply does not govern a failure.

---

## Block 7 · Streaming, and the notifications that travel with it

> **What this block proves.** Progress arrives while the work happens, and the contract still applies to every event

**Read it with a client that does not buffer.** `curl -N`, or a raw socket. A library that reads to
the end shows every event arriving at once and you will think it is broken.

The mock is what exercises this without a backend that streams. Declare a scenario on a tool:

```yaml
# ✎ in the spec, inside a tool
    examples:
      consulta_larga:
        summary: "A query the backend resolves little by little"
        stream:
          events: 3
          intervalMs: 400
          statusMessage: "Walking the banking core"
          message: "the backend wants this logged"
        value:
          - { id: "CLI-1", nombre: "Ana" }
```

and ask for it by name. This is the call the whole block reads:

```bash
STREAM='{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{},"_meta":{"progressToken":"tok-42"}}}'

curl -N -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: consulta_larga' -H 'Accept: text/event-stream' -d "$STREAM"
```

### 7.1 · the answer is an event stream, and says so in its headers

*the headers have to arrive before the work, or nothing downstream will stream either*

```bash
curl -N -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: consulta_larga' -H 'Accept: text/event-stream' -d "$STREAM" | head -8
```

**Passes when** `Content-Type: text/event-stream`, `Cache-Control: no-cache` and `X-Accel-Buffering: no`, and they arrive in **milliseconds**, not when the work ends.

### 7.2 · the events arrive spread out in time

*this is the whole point: all at once means it was buffered somewhere*

```bash
curl -N -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: consulta_larga' -H 'Accept: text/event-stream' -d "$STREAM" \
  | while IFS= read -r l; do printf '%s %s\n' "$(python3 -c 'import time;print(int(time.time()*1000))')" "$l"; done
```

**Passes when** one event roughly every `intervalMs`. Reference measurement: headers at 9 ms, events at 411, 811 and 1212 ms.

### 7.3 · every progress notification carries the token the agent sent

*a progress notification with the wrong token is a notification the agent cannot attribute*

```bash
… | grep notifications/progress
```

**Passes when** each one has `progress`, `total`, the `statusMessage` of the scenario, and **`progressToken: "tok-42"`** — the one the agent sent, not one the gateway invented.

### 7.4 · a log notification is relayed as it is

*the other half of what a backend has to say while it works*

```bash
… | grep notifications/message
```

**Passes when** relayed untouched: its `level`, its `logger` and its `data`.

### 7.5 · the last event is the result, stamped and marked

*a stream ends with the same result a whole-body call would have returned*

```bash
… | tail -3
```

**Passes when** the result with `resultType: "complete"`, `ots/untrusted: true` and `ots/source`.

### 7.6 · the trace records the stream

*a streamed call has two numbers a normal one does not: how many events, and how long to the first*

```bash
tail -1 logs/transactions.jsonl | python3 -m json.tool | grep -E 'StreamEvents|TTFB|TokensServed'
open "$DASH/transactions?key=$DKEY"
```

**Passes when** a `stream` step reading *N event(s) relayed · first one in Xms · Y bytes*, and `StreamEvents`, `TTFB` and `TokensServed` in the journal line.

### 7.7 · the whole stream is charged to the token budget

*every event went into the agent's context, so every event is paid for*

```bash
tail -1 logs/transactions.jsonl | python3 -c 'import json,sys;print(json.load(sys.stdin)["TokensServed"])'
```

**Passes when** a number covering the whole stream, not just the last event.

### 7.8 · the mask of the contract applies inside the stream

*streaming must not be a way around the output contract*

```bash
# with an x-ots-mask on a field of that tool's outputSchema:
curl -N -s … | grep -c '<the full value>'
```

**Passes when** `0`: the value is masked in the result event too. Whether an **undeclared** field is trimmed follows the `enforce` mode exactly as it does off the stream — `warn` reports it, `reject` drops it.

### 7.9 · in reject mode a refused result travels as an error event

*the refusal has to reach the agent as an event, because the headers went out long ago*

```bash
# ✎ output.enforce = "reject", and a streamed scenario whose value breaks its own outputSchema
curl -N -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: rota' -H 'Accept: text/event-stream' -d "$STREAM"
```

**Passes when** the progress events travel first, and then a JSON-RPC **error** event instead of the result, with the same code the whole-body path returns.

### 7.10 · hanging up cancels the backend

*an agent that walked away must not leave work running downstream*

```bash
curl -N -s --max-time 0.5 -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: consulta_larga' -H 'Accept: text/event-stream' -d "$STREAM" > /dev/null
grep 'cerró el stream' logs/otsgateway.log logs/mock_server.log
```

**Passes when** the gateway logs *el agente cerró el stream tras 1 evento(s)* **and** the mock logs *el cliente cerró el stream … en el evento 2*: the cancellation reached the backend.

### 7.11 · the same tool without a stream scenario is plain JSON

*the JSON path is untouched: streaming is opt-in per scenario*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'X-Mock-Example: rapida' -d "$STREAM" | head -5
```

**Passes when** `Content-Type: application/json` and the whole answer at once.

### 7.12 · a streamed resource read relays the same way

*the relay is one code path for the three primitives*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"…"}}'
```

**Passes when** the same event-by-event relay, with the cache hints stamped on the result. Needs a backend that streams a `resources/read`, which the mock does not do from a resource example.

> **Keep the stream scenario** if you can: it is the only thing that exercises this path, and it costs nothing when nobody asks for it by name.

---

## Block 8 · The protocol, both eras

> **What this block proves.** A legacy client and a 2026-07-28 one are both served, and a malformed request is told exactly what is wrong

Two eras coexist on one endpoint. The legacy one is what every deployed SDK speaks today; the
2026-07-28 one adds mirrored headers that must agree with the body, and requires the client to
declare its capabilities.

### 8.1 · a request that declares no version works

*the era is optional: not declaring one is the legacy contract, and it must keep working*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** `200` and the catalogue.

### 8.2 · the modern era, with the header and the client capabilities

*declaring 2026-07-28 opts into the stricter contract, and the gateway honours it*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 2026-07-28' -H 'Mcp-Method: tools/list' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/clientCapabilities":{"roots":{}}}}}'
```

**Passes when** `200`.

### 8.3 · the modern era without the client capabilities is refused

*the revision requires them: accepting the request anyway would be pretending to implement it*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 2026-07-28' -H 'Mcp-Method: tools/list' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -3
```

**Passes when** HTTP `400` with `-32602`.

### 8.4 · the header and the body disagreeing on the version is a mismatch

*a mirrored header exists to be checked; two values means one of them is a lie*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 2026-07-28' -H 'Mcp-Method: tools/list' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/clientCapabilities":{},"io.modelcontextprotocol/protocolVersion":"2025-06-18"}}}'
```

**Passes when** HTTP `400` with `-32020` `HeaderMismatch`.

### 8.5 · Mcp-Method not matching the body is a mismatch too

*the same rule for every mirrored header, not just the version*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 2026-07-28' -H 'Mcp-Method: tools/call' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/clientCapabilities":{}}}}'
```

**Passes when** HTTP `400` with `-32020`.

### 8.6 · a version nobody implements comes back with the list of the ones that are

*a client that guessed wrong should be able to fix itself from the answer*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 1999-01-01' -H 'Mcp-Method: tools/list' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/clientCapabilities":{}}}}'
```

**Passes when** `400` with `-32022` and `data.supported: ["2026-07-28", "2025-06-18"]`.

### 8.7 · an unsupported method is HTTP 404

*404 is how a client tells this server from a legacy one that does not host the MCP endpoint at all*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"no/existe"}' | head -3
```

**Passes when** HTTP **404** with `-32601` in the body. Not 200, not 400.

### 8.8 · an unknown tool is -32602, not -32601

*the method exists; the name inside it does not — those are different failures*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"no_existe","arguments":{}}}'
```

**Passes when** `-32602` *unknown tool: no_existe*.

### 8.9 · GET and DELETE on the endpoint are 405 with Allow: POST

*the transport is POST; anything else has to say what is allowed*

```bash
curl -si $GW | head -5
curl -si -X DELETE $GW | head -3
```

**Passes when** HTTP `405` with `Allow: POST` on both.

### 8.10 · a notification is 202 with no body

*a JSON-RPC notification has no id, so there is nothing to answer with*

```bash
curl -si -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","method":"notifications/initialized"}' | head -5
```

**Passes when** HTTP `202` and an empty body.

### 8.11 · every result is stamped

*the revision requires the type and the server identity on every result*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' | grep -E 'resultType|serverInfo'
```

**Passes when** `resultType: "complete"` and `_meta.io.modelcontextprotocol/serverInfo`.

### 8.12 · a catalogue over a page comes back with a cursor

*pagination is honoured instead of silently returning everything*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"cursor":"no-es-un-cursor"}}'
```

**Passes when** an invalid cursor is `-32602` *the cursor is not valid*. The paging half needs more than 100 tools allowed to one subscription: then `tools/list` carries `nextCursor` and passing it back returns the next page.

### 8.13 · subscriptions/listen acknowledges the three catalogues

*the acknowledgement comes first, and only names what the gateway can actually honour*

```bash
curl -N -s --max-time 2 -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'Accept: text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"subscriptions/listen","params":{"notifications":{"toolsListChanged":true,"resourcesListChanged":true,"promptsListChanged":true}}}'
```

**Passes when** the first event names the three. Note the parameter is `notifications`, an object, not a list.

### 8.14 · editing the resources of a spec notifies only that catalogue

*one notification per catalogue that actually changed, or a client rebuilds everything on every edit*

```bash
# terminal 1:
curl -N -s --max-time 20 -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'Accept: text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"subscriptions/listen","params":{"notifications":{"toolsListChanged":true,"resourcesListChanged":true,"promptsListChanged":true}}}'
# terminal 2: ✎ edit a description inside the resources: block of a spec
```

**Passes when** **only** `notifications/resources/list_changed` arrives. No tools notification, no prompts notification.

### 8.15 · changing a plan notifies nothing

*a plan is not a catalogue: waking every connected agent for it would be noise*

```bash
# with the same listener open, ✎ change a plan in the console
```

**Passes when** nothing arrives on the stream, and the plan change applies on the next request all the same.

### 8.16 · a long operation answers with a handle

*a task outlives the request, and the quota is charged once, on the call*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"<a tool with a task: scenario>","arguments":{}}}'
call '{"jsonrpc":"2.0","id":2,"method":"tasks/get","params":{"taskId":"<the handle>"}}'
```

**Passes when** `resultType: "task"` with a durable handle, and `tasks/get` polls it to completion. The quota moved by **one**, on the call, not on each poll.

### 8.17 · another consumer's handle answers like an unknown one

*the existence of a foreign task must not be probeable*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H 'X-API-Key: <another consumer>' \
  -d '{"jsonrpc":"2.0","id":2,"method":"tasks/get","params":{"taskId":"<c0 handle>"}}'
```

**Passes when** the same answer an invented handle gets. Nothing in it says the task exists and belongs to someone else.

### 8.18 · revoking the tool refuses the next poll

*authorisation is re-checked on every poll, not captured when the task was created*

```bash
# ✎ remove that tool from the subscription, then poll again
call '{"jsonrpc":"2.0","id":2,"method":"tasks/get","params":{"taskId":"<the handle>"}}'
```

**Passes when** HTTP `403`.

### 8.19 · a restart recovers the tasks in flight

*a task that survives a disconnection has to survive a restart, which is the point of tasks*

```bash
./otsgateway.sh -restart macos-arm64
grep 'tareas en curso recuperadas' logs/otsgateway.log
call '{"jsonrpc":"2.0","id":2,"method":"tasks/get","params":{"taskId":"<the handle>"}}'
```

**Passes when** `N tareas en curso recuperadas` at startup, and the poll is still routed and authorised.

> Under the **mock**, the poll then comes back as a backend `404`: the mock keeps its tasks in memory and lost its half. That is the mock's amnesia, not the gateway forgetting — with a real backend that persists tasks, the poll continues.

### 8.20 · initialize negotiates a version it supports

*echoing the requested version back told a client it was fine and then refused every request that carried it*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{}}}'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" \
  -H 'MCP-Protocol-Version: 2025-11-25' -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
call '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"1999-01-01","capabilities":{}}}'
```

**Passes when** `2025-11-25` comes back as itself and a request carrying it is `200`; and
`1999-01-01` is answered with `2025-06-18` — a version the gateway supports — with the negotiation
noted in the log. Three revisions are served: `2026-07-28`, `2025-11-25` and `2025-06-18`. An
unsupported version on a **request** is still `-32022`, which is case 8.6.

### 8.21 · a declared outputSchema always comes back as structuredContent, and it is an object

*two halves of one rule: a tool that declares an outputSchema **must** return `structuredContent`, and `structuredContent` **is** an object*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"}}}'
grep 'outputSchema of type array' logs/otsgateway.log | head -2
```

**Passes when** every tool that declares an `outputSchema` answers with `structuredContent`, and it
is always an object — a list arrives **wrapped** under the property the contract names:
`{"cuentas": [ … ]}`.

An `outputSchema` of `type: array` satisfies neither half, so the loader refuses it (case 1.20).
Both symptoms come from that same mistake:

```
ValidationError: … structuredContent  Input should be a valid dictionary [input_type=list]
RuntimeError: Tool consultar_cuentas has an output schema but did not return structured content
```

The fix is in the contract, and the loader prints the YAML to write:

```yaml
outputSchema:
  type: "object"
  properties:
    cuentas:
      type: "array"
      items: { $ref: "#/components/schemas/Cuenta" }
```

A database-backed tool needs nothing else: the gateway puts the rows under that property, and the
query stays a plain `SELECT`.

---

## Block 9 · Endpoints, browsers, and two MCPs sharing a name

> **What this block proves.** The aggregate endpoint and the per-MCP ones, discovery, CORS, and a name two MCPs both declare

Both endpoints are the whole gateway — same credential, same allowlist, same scopes, same plan,
same trace — and what changes is how much of the catalogue the agent sees: `/mcp/messages` every
MCP its subscription allows, `/{context_path}/mcp/messages` one of them. With a single MCP
configured the two answer identically. *Which endpoint an agent calls* in
[`README.md`](README.md) is when to pick each.

Cases 9.11 to 9.22 need the second MCP. The repository ships it:
[`weather-ots.yaml`](weather-ots.yaml) declares `consultar_cuentas`, `politica_privacidad` and
`resumen_mensual` — three names `boti-bank-ots.yaml` already uses — plus `consultar_tiempo`, which is
unique, so one catalogue shows both cases at once.

```json
// ✎ ots.json, in "mcps"
{
  "name": "weather",
  "description": "A second MCP that shares three names with botibank",
  "context_path": "/weatherots",
  "ots_file": "weather-ots.yaml",
  "mock": { "enabled": true, "delay_ms": 0 },
  "backend_server": [{ "url": "http://127.0.0.1:<mock_server.port>/weatherots", "security": { "type": "" } }]
}
```
```json
// ✎ ots.json, in "subscriptions": authorise the homonyms on BOTH for c0,
//    and add a second consumer authorised on only one of them
{ "consumer_name": "c1", "description": "botibank only", "security": [{
    "mcps": [{ "botibank": { "tools": ["consultar_cuentas"],
                             "resources": ["politica_privacidad"],
                             "prompts": ["resumen_mensual"] } }],
    "auth_method": [{ "api_key": "solo-botibank-9999" }],
    "oauth": {}, "key_plan": "free" }] }
```
```bash
GWWEATHER=${GW%/mcp/messages}/weatherots/mcp/messages
K1="X-API-Key: solo-botibank-9999"
```

### 9.1 · the aggregate endpoint serves every MCP the subscription allows

*one address for everything is the default an agent is configured with*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
```

**Passes when** tools from **both** MCPs in one list.

### 9.2 · a per-MCP endpoint serves only its own

*context_path is not decorative: it narrows every catalogue and every call*

```bash
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
```

**Passes when** only botibank's, and the same for `resources/list` and `prompts/list`.

### 9.3 · a tool of another MCP through the wrong endpoint says where it lives

*an empty answer would look like the tool does not exist; naming the MCP is actionable*

```bash
curl -s -X POST $GWWEATHER -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}'
```

**Passes when** `-32602` *this endpoint serves the mcp "weather"; the tool "listar_clientes" belongs to "botibank" — use its own endpoint or the aggregate one*.

### 9.4 · a context nobody declares is 404

*the address is wrong, and saying so beats an empty catalogue*

```bash
curl -s -o /dev/null -w '%{http_code}\n' -X POST "${GW%/mcp/messages}/noexiste/mcp/messages" \
  -H 'Content-Type: application/json' -H "$K" -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** `404`.

### 9.5 · an MCP added while it runs gets its endpoint on the next request

*the routing is resolved per request, so onboarding an MCP does not need a restart*

```bash
# ✎ add an MCP with a context_path from the console, then:
curl -s -X POST "${GW%/mcp/messages}/<the new context>/mcp/messages" \
  -H 'Content-Type: application/json' -H "$K" -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** `200` with that MCP's catalogue, with **no restart**.

### 9.6 · the protected resource metadata is served

*RFC 9728 is how a client discovers which authorization server protects this resource*

```bash
curl -s "${GW%/mcp/messages}/.well-known/oauth-protected-resource" | python3 -m json.tool
```

**Passes when** `resource`, `authorization_servers`, `scopes_supported` and `bearer_methods_supported`.

### 9.7 · the authorization server metadata is served where the server listens

*RFC 8414, on the gateway port or on its own, wherever auth_server.internal.port put it*

```bash
curl -s "${AUTH%/oauth/token}/.well-known/oauth-authorization-server" | python3 -m json.tool
```

**Passes when** `issuer`, `token_endpoint`, `grant_types_supported: ["client_credentials"]` and the scopes.

### 9.8 · with CORS off, a preflight changes nothing

*off means off: no headers, no special case*

```bash
curl -si -X OPTIONS $GW -H 'Origin: https://agente.example' \
  -H 'Access-Control-Request-Method: POST' | head -5
```

**Passes when** HTTP `405`, and no `Access-Control-*` header at all.

### 9.9 · with CORS on, an allowed origin is echoed exactly

*a credentialed endpoint may never answer with a wildcard origin*

```bash
# ✎ otsgateway.cors.enabled = true
#    otsgateway.allowed_origins = ["https://agente.example"]
curl -si -X OPTIONS $GW -H 'Origin: https://agente.example' \
  -H 'Access-Control-Request-Method: POST' | head -10
```

**Passes when** HTTP `204` with `Access-Control-Allow-Origin: https://agente.example` — the exact origin, **never** `*` — and `Vary: Origin`.

> `allowed_origins` is a **sibling** of `cors`, under `otsgateway`, not a field inside it: who may call is one decision, telling the browser about it is another.

### 9.10 · an origin that is not on the list gets nothing

*the list is the authority, and the answer does not leak what is on it*

```bash
curl -si -X OPTIONS $GW -H 'Origin: https://otro.example' \
  -H 'Access-Control-Request-Method: POST' | head -5
```

**Passes when** HTTP `403` and no CORS headers.

### 9.11 · a name two MCPs declare is listed twice, qualified

*two entries with the same name would leave a client unable to address either*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
```

**Passes when** `botibank.consultar_cuentas` and `weather.consultar_cuentas`, both qualified — and `consultar_tiempo` and the rest still **bare**, because they are unique in this listing.

### 9.12 · a per-MCP catalogue has nothing to qualify

*one MCP by construction, so no name in it can be ambiguous*

```bash
curl -s -X POST $GWWEATHER -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
```

**Passes when** `consultar_cuentas` bare, not `weather.consultar_cuentas`.

### 9.13 · calling it bare is 409, and the answer names both remedies

*an ambiguity the agent has to resolve must come with the two ways to resolve it*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{}}}'
```

**Passes when** HTTP `409` with `-32602`: *… name it "botibank.consultar_cuentas" or "weather.consultar_cuentas", as the catalogue lists it, or call the endpoint of the one you mean, /{context_path}/mcp/messages*.

### 9.14 · the qualified name resolves, and to the right MCP

*the form the catalogue advertised has to be the form the call accepts*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"weather.consultar_cuentas","arguments":{"estacion":"EM-01"}}}'
```

**Passes when** `200`, and the answer is the **weather** one — `cuentas_de_lluvia`, a field only that spec declares.

### 9.15 · the endpoint of that MCP disambiguates just as well

*two ways out of one ambiguity, and the agent picks whichever it can*

```bash
curl -s -X POST $GWWEATHER -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"estacion":"EM-01"}}}'
```

**Passes when** `200` with the same answer, using the **bare** name.

### 9.16 · a consumer authorised on one of the two never sees an ambiguity

*the subscription resolves it: most collisions never reach the agent at all*

```bash
curl -s -X POST $GW -H 'Content-Type: application/json' -H "$K1" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep '"name"'
curl -s -o /dev/null -w '%{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K1" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"CL-001"}}}'
```

**Passes when** the catalogue lists it **bare** and the bare call is `200`: this consumer's world has no collision in it.

### 9.17 · resources and prompts resolve exactly the same way

*one resolution, three registries*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}'
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"weather.politica_privacidad"}}'
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"resumen_mensual","arguments":{"ciudad":"Madrid"}}}'
call '{"jsonrpc":"2.0","id":1,"method":"prompts/get","params":{"name":"weather.resumen_mensual","arguments":{"ciudad":"Madrid"}}}'
```

**Passes when** `409` for each bare name, `200` for each qualified one.

### 9.18 · by uri there is never an ambiguity

*a uri identifies a resource on its own, which is why the loader refuses a duplicate one*

```bash
call '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"uri":"ots://weather/politica-privacidad"}}'
```

**Passes when** `200`, from any endpoint, with `contents[0].uri` echoing what was asked for. Case 1.14 is the loader rule that makes this safe.

### 9.19 · the short dashboard url lists the candidates instead of a 404

*the name is right; it is the url that is missing the MCP*

```bash
curl -si "$DASH/tool/consultar_cuentas?key=$DKEY" | head -12
```

**Passes when** HTTP `300 Multiple Choices` with both MCPs as links.

### 9.20 · the namespaced url is the canonical one

*every table in the dashboard links to this form*

```bash
curl -s -o /dev/null -w '%{http_code}\n' "$DASH/mcp/weather/tool/consultar_cuentas?key=$DKEY"
curl -s -o /dev/null -w '%{http_code}\n' "$DASH/tool/consultar_tiempo?key=$DKEY"
```

**Passes when** `200` for the namespaced url, and `200` for the short one of a **unique** name: no old link or bookmark breaks.

### 9.21 · the consumer page counts the two homonyms apart

*the counters are per (mcp, name), so two tools with one name are two rows*

```bash
curl -s "$DASH/consumer/c0?key=$DKEY" | grep -o '/mcp/[a-z]*/tool/consultar_cuentas'
```

**Passes when** two different links, one per MCP, each row with its own calls, errors and latency.

### 9.22 · the console offers the two as two checkboxes

*the console always spoke mcp.name, so it needed no change at all*

```bash
curl -s "$CONSOLE/?key=$CKEY" | grep -o 'value="[a-z]*\.consultar_cuentas"'
```

**Passes when** `value="botibank.consultar_cuentas"` and `value="weather.consultar_cuentas"`.

### 9.23 · apart from the catalogue, the two endpoints are the same gateway

*9.1 to 9.4 prove each endpoint narrows what it should; this is the half an operator actually asks about — whether choosing one changes anything else*

```bash
# Pick a tool whose answer is deterministic — one the mock or a query serves. A
# tool pointing at a real backend having a bad day answers differently on two
# consecutive calls, and that difference has nothing to do with endpoints.
CALL='{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"71992c72-cc1c-4c5a-8b50-9ee4fb6c214d"}}}'

# the same call, both ways
curl -s -X POST $GW    -H 'Content-Type: application/json' -H "$K" -d "$CALL" | python3 -m json.tool > /tmp/a.json
curl -s -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" -d "$CALL" | python3 -m json.tool > /tmp/b.json
diff /tmp/a.json /tmp/b.json && echo 'identical'

# the credential is checked the same way on both
curl -s -o /dev/null -w 'aggregate: %{http_code}\n' -X POST $GW    -H 'Content-Type: application/json' -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
curl -s -o /dev/null -w 'per-MCP:   %{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'

# and so is the allowlist
curl -s -o /dev/null -w 'aggregate: %{http_code}\n' -X POST $GW    -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}'
curl -s -o /dev/null -w 'per-MCP:   %{http_code}\n' -X POST $GWMCP -H 'Content-Type: application/json' -H "$K" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"transferir_dinero","arguments":{}}}'
```

**Passes when** the two answers are byte for byte the same (`requestId` aside, which is per
request), both are `401` with no credential, and both are `403` on a tool the subscription omits.

> If they differ, look at **what** differs before blaming the endpoint. A backend that is down
> answers differently each time: a WSO2 whose circuit breaker trips between the two calls returns
> `101503 Error connecting to the back end` and then `303001 … endpoint SUSPENDED`. That is the
> backend talking, not the gateway.
What the context path narrows is the catalogue; the credential, the allowlist, the scopes, the plan
and the trace are the same pipeline either way.

> With a single MCP configured, `tools/list` also answers identically on both — the distinction only
> shows up once there is a second one, which is what 9.1 and 9.2 cover.

---

## Block 10 · Operating it

> **What this block proves.** The console writes, the dashboard reads, both are behind their key, and a stop is orderly

The two UIs listen on **every interface**. The `access_key` is the only barrier, it is read live on
every request, and it is compared in constant time — see point 1 of
[`PARKED-TOPICS.md`](PARKED-TOPICS.md) for what that does and does not protect.

### 10.1 · the console shows the live configuration, and one url with ?key= is enough to navigate it

*what the console renders is the configuration in memory; and a credential that only rode on the url would authenticate the page you typed and nothing you click*

```bash
curl -s "$CONSOLE/?key=$CKEY" | grep -o 'name="\(tools\|resources\|prompts\)"' | sort -u

# now as a browser does it: one url with the key, then clicks — keep the cookies
J=$(mktemp)
curl -si -c $J "$CONSOLE/?key=$CKEY" | grep -i set-cookie
curl -s -o /dev/null -w 'a save:      %{http_code}\n' -b $J -c $J -X POST "$CONSOLE/plan" \
  -d 'name=premium' -d 'rate_per_second=20' -d 'burst=40' -d 'quota_hourly=5000' \
  -d 'quota_daily=50000' -d 'tokens_hourly=1000000' -d 'tokens_daily=10000000' -d 'max_tokens_per_call=60000'
curl -s -o /dev/null -w 'no cookie:   %{http_code}\n' -X POST "$CONSOLE/plan" -d 'name=premium'

# and the dashboard: a click and a deep link, both plain paths
D=$(mktemp)
curl -s -o /dev/null -w 'entry:       %{http_code}\n' -c $D "$DASH/?key=$DKEY"
curl -s -o /dev/null -w 'a click:     %{http_code}\n' -b $D "$DASH/mcp/botibank"
curl -s -o /dev/null -w 'a deep link: %{http_code}\n' -b $D "$DASH/mcp/botibank/tool/consultar_cuentas"
curl -s -o /dev/null -w 'api/state:   %{http_code}\n' -b $D "$DASH/api/state"
curl -s -o /dev/null -w 'no cookie:   %{http_code}\n'      "$DASH/mcp/botibank"
```

**Passes when** the three checkbox groups are there, the entry page answers
`Set-Cookie: ots_console_key=…; Path=/; HttpOnly; SameSite=Strict`, and from then on every click,
every deep link and **every form post** is `200` while the same request without the cookie is `401`.
Put the plan back afterwards.

> Without the cookie the pages would be unusable in a browser: every link and every form action is a
> plain path, so `?key=` would authenticate the entry page and nothing else. See *Reaching the
> dashboard and the console* in [`README.md`](README.md).

### 10.2 · the console with no key is 401

*the console writes ots.json: it is the one that must never answer without its key*

```bash
curl -si "$CONSOLE/" | head -5
```

**Passes when** HTTP `401` with `WWW-Authenticate: ApiKey realm="ots-console"`.

### 10.3 · the writes are behind the same gate

*guarding the page and leaving the POST open would guard nothing*

```bash
curl -s -o /dev/null -w '%{http_code}\n' -X POST "$CONSOLE/subscription" -d 'consumer=0'
```

**Passes when** `401`.

### 10.4 · changing the access key applies hot, and every cookie dies with it

*turning a key on or rotating it must not need a restart — that is exactly when you cannot afford one — and a session that was already open must not survive the rotation*

```bash
J=$(mktemp); curl -s -o /dev/null -c $J "$CONSOLE/?key=$CKEY"     # a session, open

# ✎ console.access_key = "rotada-en-caliente", wait for the watcher
curl -s -o /dev/null -w 'old key:      %{http_code}\n' "$CONSOLE/?key=$CKEY"
curl -s -o /dev/null -w 'new key:      %{http_code}\n' "$CONSOLE/?key=rotada-en-caliente"
curl -si -b $J "$CONSOLE/" | grep -iE '^HTTP|set-cookie'          # the open session
curl -s -o /dev/null -w 'sign in again: %{http_code}\n' -c $J "$CONSOLE/?key=rotada-en-caliente"
curl -s -o /dev/null -w 'and navigate:  %{http_code}\n' -b $J "$CONSOLE/"
```

**Passes when** `401` for the old key and `200` for the new one with no restart; the already-open
session is `401` too — the rotation invalidates it by itself, because the comparison then fails —
and that same response **clears** the stale cookie (`ots_console_key=; Max-Age=0`), so the operator
is asked once instead of being refused forever by a cookie they cannot see.

### 10.5 · a plan saved from the console applies, and the previous file is kept

*every write keeps one step of undo next to it*

```bash
curl -s -X POST "$CONSOLE/plan?key=$CKEY" -d 'name=premium' -d 'rate_per_second=20' \
  -d 'burst=44' -d 'quota_hourly=5000' -d 'quota_daily=50000' \
  -d 'tokens_hourly=1000000' -d 'tokens_daily=10000000' -d 'max_tokens_per_call=60000' > /dev/null
python3 -c "import json;print(json.load(open('ots.json'))['plans']['premium']['burst'])"
ls -l ots.json.bak
```

**Passes when** `44` in the file, applied on the next request, and `ots.json.bak` holds the previous version.

### 10.6 · invalid JSON in the raw editor is refused, and nothing is written

*a half-written config file is worse than a rejected edit*

```bash
md5 -q ots.json
curl -s -X POST "$CONSOLE/apply?key=$CKEY" -d 'raw={ esto no es json' > /dev/null
md5 -q ots.json
call '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | head -3
```

**Passes when** the checksum is unchanged, and the gateway keeps answering with the previous configuration.

### 10.7 · a spec edited by hand is picked up by the watcher

*the specs are watched too, not just ots.json*

```bash
# ✎ change a description inside a spec
grep 'cambio detectado' logs/otsgateway.log | tail -1
call '{"jsonrpc":"2.0","id":1,"method":"resources/list"}' | grep '<the new text>'
```

**Passes when** `👁️ cambio detectado en …, recargando` within `watch_interval_sec`, and the new text in the catalogue.

### 10.8 · the dashboard shows the tiles and one table per primitive

*the three primitives are first-class in the operator view, not just in the protocol*

```bash
open "$DASH/?key=$DKEY"
```

**Passes when** the count tiles, and inside each MCP a table for tools, one for resources and one for prompts, each with calls, failures, latency and last use.

### 10.9 · the transaction list names the primitive and its kind

*one history for the three, with a column that tells them apart*

```bash
curl -s "$DASH/transactions?key=$DKEY" | grep -o '<td>[^<]*</td>' | head
```

**Passes when** an `Element` column with the name and a `tool` / `resource` / `prompt` tag, each linking to `/mcp/{mcp}/…`.

### 10.10 · a transaction shows the pipeline and the payloads, masked

*the trace is the thing you actually debug with, and it must not become a place secrets leak*

```bash
open "$DASH/transaction/<id>?key=$DKEY"
```

**Passes when** the pipeline step by step with timings, and the four payloads — agent request, gateway→MCP, MCP response, gateway→agent — with the credentials masked (`def•••35`, `Bearer eyJ•••Lw`).

### 10.11 · the same data is available as JSON

*an operator surface that cannot be scripted is half a surface*

```bash
curl -s "$DASH/api/state?key=$DKEY" | python3 -m json.tool | head -30
```

**Passes when** `consumers`, `mcps` and the counters, the same numbers the pages render.

### 10.12 · the dashboard with no key is 401 too, and hands out no cookie

*it reads every trace and every masked credential: it is not a public page — and a refused request must not leave a usable session behind*

```bash
curl -si "$DASH/" | grep -iE '^HTTP|www-authenticate|set-cookie'
```

**Passes when** HTTP `401` with `WWW-Authenticate: ApiKey realm="ots-dashboard"`, and **no**
`Set-Cookie` carrying a key. A `Set-Cookie` that only *clears* a stale cookie is fine and expected
when the request presented one.

### 10.13 · SIGTERM runs the orderly shutdown

*a stop that drops in-flight requests loses the journal lines that rebuild the quotas*

```bash
./otsgateway.sh -stop macos-arm64
tail -3 logs/otsgateway.log
```

**Passes when** *señal de apagado recibida, cerrando ordenadamente…* and then *OTS Gateway detenido*.

### 10.14 · starting again finds the history and the quotas where they were

*the journal is replayed at startup, so a restart is not a reset*

```bash
./otsgateway.sh -start macos-arm64
grep 'Diario restaurado' logs/otsgateway.log
curl -s "$DASH/transactions?key=$DKEY" | grep -c '/transaction/'
```

**Passes when** `📚 Diario restaurado` at startup and the transaction list is not empty.

### 10.15 · the run left the repository alone

*a test pass that leaves the working tree dirty cannot be run twice*

```bash
git status --short
```

**Passes when** `ots.json` may be modified if you edited it and did not put it back, and `secrets.env` **must not** appear as staged. Nothing else from the run.

> `./TESTING-ONE-ONE.sh` never has this problem: it works on copies inside `.testing-one-one/`, which is gitignored. Its version of this case compares the working tree against **how it found it**, so running the suite over work in progress does not report your own edits as its own.

### 10.16 · a secret set from the console applies hot, and ots.json is untouched

*this is the reason the store is a separate file: rotating a secret must not rewrite the configuration, and must not need a restart*

```bash
md5 -q ots.json                      # before
curl -s "$CONSOLE/?key=$CKEY" | grep -o 'OTS_JWT_SECRET</code>'
curl -s "$CONSOLE/?key=$CKEY" | grep -c '<the actual secret value>'   # must be 0

curl -s -o /dev/null -X POST "$CONSOLE/secret?key=$CKEY" \
  -d 'name=OTS_JWT_SECRET' -d 'value=una-clave-nueva-de-al-menos-32-caracteres'
sleep 1
md5 -q ots.json                      # after: the same
curl -s -o /dev/null -w 'an old token now: %{http_code}\n' -X POST $GW \
  -H 'Content-Type: application/json' -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** the console page **names** the secret and shows how long it is but never the value;
the checksum of `ots.json` is unchanged; a token minted before the rotation is now `401`; and a
token minted after it is `200` — all with no restart.

### 10.17 · a referenced secret cannot be deleted; an orphan can

*deleting a referenced name would refuse the next reload, and you could not fix it from the console*

```bash
curl -s -X POST "$CONSOLE/secret/delete?key=$CKEY" -d 'name=OTS_JWT_SECRET' | grep -o 'still referenced by[^<]*'
curl -s -o /dev/null -X POST "$CONSOLE/secret?key=$CKEY" -d 'name=HUERFANO' -d 'value=nada-lo-usa'
curl -s -o /dev/null -X POST "$CONSOLE/secret/delete?key=$CKEY" -d 'name=HUERFANO'
python3 -c "import json;print('HUERFANO' in json.load(open('secrets.json'))['secrets'])"
```

**Passes when** the referenced one is refused, naming the field that points at it
(`auth_server.internal.jwt_secret`), and the orphan is deleted — the console marks it *nobody — safe
to delete* precisely because nothing references it.

---

## Block 11 · The debugger

> **What this block proves.** A breakpoint holds a real call until somebody lets it go — on every
> destination the gateway has — and every way a pause can end without a person works

Off unless you ask for it: `debug.enabled` is false by default, and the gateway refuses to turn it on
when the console is disabled or has no `access_key`, because the console is the only way to release
anything. Arming, releasing and reading what is held all live behind that key.

Everything in this block needs it on:

```bash
python3 - <<'PY'
import json
c = json.load(open('ots.json'))
c['debug'] = {"enabled": True, "timeout_sec": 30, "on_timeout": "continue",
              "max_paused": 3, "allow_abort": True}
json.dump(c, open('ots.json', 'w'), indent=2, ensure_ascii=False)
PY
# the gateway watches the file: no restart
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY"
```

Turn it back off when you are done. A gateway anyone can pause is not a debugger.

### 11.1 · it is off unless it is asked for, and loud when it is on

*a feature that can hold somebody else's call must be impossible to leave on by accident*

```bash
grep 'debug.enabled is ON' logs/otsgateway.log
curl -s "$CONSOLE/debug/state?key=$CKEY"
curl -s -o /dev/null -w '%{http_code}\n' "$CONSOLE/debug/state"
```

**Passes when** the startup line warns that the debugger is on, the state says `"enabled":true`, and
the same request with no key is `401`.

### 11.2 · an armed box stops the call, and the state says what is waiting

*this is the whole feature: the call is not answered until a person says so*

```bash
# arm the tool's box — the same id the map uses
curl -s -X POST "$CONSOLE/debug/breakpoints?key=$CKEY" -d 'node=tool:botibank:listar_clientes' -d 'on=true'

# a real call, in the background, so you can look at it while it waits
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" > /tmp/held.json &
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -m json.tool

# and let it go
ID=$(curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -c 'import json,sys;w=json.load(sys.stdin)["waiting"];print(w[0]["id"] if w else "")')
curl -s -X POST "$CONSOLE/debug/continue/$ID?key=$CKEY"
sleep 1; head -c 120 /tmp/held.json
```

**Passes when** `waiting` holds one call with the box it stopped at, where it stopped
(`"at":"before the backend"`), who is calling, how long they have been waiting (`waitingMs`) and both
payloads — and then **stops again** on the way back, at `"after the backend"`, because one box
watches both directions: what leaves it and what comes back. Release both and the call answers
normally.

### 11.3 · the journal measures the gateway, not the person reading

*a held call would otherwise put your coffee break into the latency of the tool*

```bash
tail -1 logs/transactions.jsonl | python3 -c '
import json,sys
d = json.load(sys.stdin)
print("Duration", d["Duration"]/1e6, "ms · PausedMs", d.get("PausedMs"), "· Debugged", d.get("Debugged"))
print("work", d["Duration"]/1e6 - d.get("PausedMs", 0), "ms")'
```

**Passes when** `Duration` is what the caller actually waited, `PausedMs` is the pause, `Debugged` is
true — and every average the dashboard shows subtracts the pause, so one debugged call does not move
the numbers.

### 11.4 · aborting answers the agent with an error

*a breakpoint you can only continue is a breakpoint you cannot use to test a failure*

```bash
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" > /tmp/aborted.json &
sleep 2
ID=$(curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -c 'import json,sys;w=json.load(sys.stdin)["waiting"];print(w[0]["id"] if w else "")')
curl -s -X POST "$CONSOLE/debug/abort/$ID?key=$CKEY"
sleep 1; cat /tmp/aborted.json
```

**Passes when** the agent gets an error saying the call was aborted from the debugger, and the
backend was never called. `allow_abort: false` takes this away and leaves only *continue*.

### 11.5 · a caller that hangs up ends the pause at once

*holding a corpse costs a slot of the ceiling and helps nobody*

```bash
curl -s -m 2 -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" >/dev/null &
sleep 5
curl -s "$CONSOLE/debug/state?key=$CKEY"
grep -c 'the caller hung up while the call was paused' logs/transactions.jsonl
```

**Passes when** nothing is being held any more and the trace says the caller left: the pause watches
the request context, not only its own clock.

### 11.6 · the timeout releases it, and says it was not a person

*your distraction must not become the agent's failed call*

```bash
# with timeout_sec at 3, and on_timeout "continue"
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" > /tmp/timeout.json &
sleep 7
grep -c 'released by the timeout' logs/transactions.jsonl
head -c 80 /tmp/timeout.json
```

**Passes when** the call went through on its own and the trace says it was the timeout that released
it, not a person. `on_timeout: "abort"` makes the same moment an error instead.

### 11.7 · past the ceiling a call is not paused

*the debugger may never be the reason a gateway stops answering*

```bash
for i in 1 2 3 4; do
  curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" >/dev/null &
  sleep 1
done
curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -c 'import json,sys;print(len(json.load(sys.stdin)["waiting"]), "held")'
grep -c 'too many calls are already waiting' logs/transactions.jsonl
```

**Passes when** no more than `max_paused` calls are held and the ones over the ceiling went straight
through, each marked in its trace as not paused because too many were already waiting.

### 11.8 · the mock is a destination too, and says so

*a call answered from an example is the one you most want to stop: it is the one you are about to change*

```bash
# put the backend that serves this tool in mock mode, then call it
curl -s -X POST "$CONSOLE/debug/breakpoints?key=$CKEY" -d 'node=tool:botibank:listar_clientes' -d 'on=true'
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" >/dev/null &
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY" | grep -o '"at":"[^"]*"'
```

**Passes when** it holds the call and says `"at":"before the mock"` — and the box after it
(`backend:<mcp>:<index>`) holds the answer the mock gave, at `"after the mock"`.

### 11.9 · a resource read stops as well, on its own box

*resources and prompts are primitives like tools, and a debugger that only knew about tools was a debugger that lied on two thirds of the map*

```bash
curl -s -X POST "$CONSOLE/debug/breakpoints?key=$CKEY" -d 'node=resource:botibank:politica_privacidad' -d 'on=true'
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"resources/read","params":{"name":"politica_privacidad"}}' >/dev/null &
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY" | grep -o '"node":"[^"]*"'
```

**Passes when** the pause names the resource's own box, not the tool's: the node id carries the kind.

### 11.10 · a query stops before it is bound, showing the arguments

*there is no request on a wire here, so what the pause shows is what is about to be bound*

```bash
curl -s -X POST "$CONSOLE/debug/breakpoints?key=$CKEY" -d 'node=tool:botibank:consultar_cuentas' -d 'on=true'
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"1"}}}' >/dev/null &
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -m json.tool | grep -E '"at"|"payload"'
```

**Passes when** it says `"at":"before the query"` and the payload is the arguments that are about to
be bound — and the box of the database backend holds the rows at `"after the query"`.

### 11.11 · a pause carries what the agent asked, not only what is leaving

*one is unreadable without the other, and the journal has neither while the call is still in flight*

```bash
curl -s -X POST "$CONSOLE/debug/breakpoints?key=$CKEY" -d 'node=tool:botibank:listar_clientes' -d 'on=true'
curl -s -X POST "$GWMCP" -H "$K" -H 'Content-Type: application/json' -d "$CALL" >/dev/null &
sleep 2
curl -s "$CONSOLE/debug/state?key=$CKEY" | python3 -c '
import json,sys
call = json.load(sys.stdin)["waiting"][0]
print("asked:   ", call["request"][:90])
print("leaving: ", call["payload"][:90])'
```

**Passes when** `request` is the JSON-RPC the agent sent and `payload` is what is about to happen at
that point — the request on the way out, the answer on the way back. The dashboard has both once the
call is over; a breakpoint is for while it is not.


---

## Extra checks

These are not in the ordered plan and the script does not run them: they need a real
provider, a second machine, or a packaging step. They are here because they still have to be
checked before a release.

### E1 · Packaging: one binary per platform, with its checksum

*what you ship is what you built, and it runs where you say it runs*

```bash
./otsgateway.sh -compile                    # lists the tags, builds nothing
./otsgateway.sh -compile linux-amd64
file dist/otsgateway-linux-amd64
tar tzf dist/*-linux-amd64.tar.gz
cd dist && shasum -a 256 -c SHA256SUMS.txt

# and the whole release in one command
rm -rf dist && ./otsgateway.sh -compile all
ls dist | wc -l                             # 9 binaries + 9 archives + SHA256SUMS.txt
cd dist && shasum -a 256 -c SHA256SUMS.txt | grep -c OK    # 18
```

**Passes when** `-compile` with no tag prints the table and creates nothing — compiling always names
its target; `file` says *ELF 64-bit … x86-64, statically linked*; the tarball carries `otsgateway`,
`ejemplo/` with a working deployment in it, the spec, the docs and `logs/`, and **not** `ots.json`; and every checksum
line is `OK`.

`-compile all` prints `N de 9 plataformas compiladas` and exits non-zero if any failed — one that
fails does not stop the rest, because in a release the useful thing is how many came out. `go vet`
runs once before any of them, and a failure there builds nothing.

Two refusals worth having: `./otsgateway.sh -start linux-amd64` on a Mac says *el binario de
'linux-amd64' es para linux/amd64 y esta máquina es …*, and `-start pepito` says it is neither a tag
nor a file. Nothing is ever copied to the repository root: `dist` is the only output, and `-start`
runs the binary of the tag it is given.

### E2 · client_secret_basic at the token endpoint

*OAuth 2.1 prefers the credentials in the Authorization header, and the gateway accepts both*

```bash
curl -s -u "$CID:$CSEC" -X POST $AUTH -d 'grant_type=client_credentials'
```

**Passes when** the answer is the same token as `client_secret_post` (case 2.4). Both forms are
supported on purpose; the header form is the one a browser needs, which is why `Authorization` is in
the CORS `Allow-Headers` — see E5.

### E3 · The other two refusals of the token endpoint

*a bad request at the token endpoint has to name which part was bad, in OAuth's own vocabulary*

```bash
curl -s -X POST $AUTH -d "grant_type=password&client_id=$CID&client_secret=$CSEC"
curl -s -X POST $AUTH -d "grant_type=client_credentials&client_id=$CID&client_secret=$CSEC&scope=bank:admin"
```

**Passes when** the first is `unsupported_grant_type` and the second is
`{"error":"invalid_scope","error_description":"scope \"bank:admin\" is not available to this client"}`.
A wrong secret is `invalid_client` (case 2.8) and says nothing about **which** half was wrong.

### E4 · The authorization server on its own port, and back

*moving the token endpoint moves its metadata with it, and nothing else*

With `auth_server.internal.port` set to something other than the gateway port:

```bash
# on the gateway port: the endpoint is not there any more
curl -s -o /dev/null -w 'gateway   /oauth/token   %{http_code}\n' -X POST ${GW%/mcp/messages}/oauth/token
# on its own port: it is
curl -s -o /dev/null -w 'auth      /oauth/token   %{http_code}\n' -X POST $AUTH \
  -d grant_type=client_credentials -d client_id=$CID -d client_secret=$CSEC
# and its metadata moved with it
curl -s -o /dev/null -w 'gateway   metadata       %{http_code}\n' "${GW%/mcp/messages}/.well-known/oauth-authorization-server"
curl -s -o /dev/null -w 'auth      metadata       %{http_code}\n' "${AUTH%/oauth/token}/.well-known/oauth-authorization-server"
```

| Request | Expected |
|---|---|
| `POST <gateway>/oauth/token` | `404` — it moved |
| `GET <gateway>/.well-known/oauth-authorization-server` | `404` — it moved |
| `POST <auth port>/oauth/token` | the token |
| `GET <auth port>/.well-known/oauth-authorization-server` | `token_endpoint` on that port |
| `GET <gateway>/.well-known/oauth-protected-resource` | `resource` on the gateway, `authorization_servers` naming the auth port |

**Passes when** each of those five answers as the table says. **Emptying the field** puts everything
back on the gateway port — this one needs `-stop`/`-start`, because a listener is bound once.
Setting it to the gateway's own port starts **with a warning**, as the shared setup; setting it to
the dashboard's is refused at load, which is case 1.9.

### E5 · CORS on the token endpoint and the discovery documents

*the browser handshake has to work on the three endpoints a browser agent actually touches, not just the MCP one*

```bash
# ✎ cors.enabled = true and allowed_origins = ["https://app.example.com"]

# preflight of the TOKEN endpoint
curl -si -X OPTIONS $AUTH -H "Origin: https://app.example.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: authorization" | grep -iE "^HTTP|access-control|vary"

# the 401 challenge has to be readable from the page
curl -si -X POST $GW -H "Origin: https://app.example.com" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep -i expose-headers

# a foreign origin, with CORS on
curl -s -o /dev/null -w '%{http_code}\n' -X POST $AUTH \
  -H "Origin: https://evil.example.com" -d 'grant_type=client_credentials'
```

**Passes when** the preflight is `204` with `Access-Control-Allow-Methods: POST, OPTIONS` and
`Authorization` inside `Allow-Headers` — that is what `client_secret_basic` needs from a browser;
the exact origin in `Allow-Origin`, never `*`, and `Vary: Origin`; the challenge carries
`Access-Control-Expose-Headers: Retry-After, X-Mock-Example, WWW-Authenticate` — **without
`WWW-Authenticate` on that list the browser hides it and the discovery chain breaks silently**; and
the foreign origin is `403`.

> `allowed_origins` is the defence and applies whether or not CORS is on. `cors.enabled` only
> decides whether the gateway tells the browser about it.

### E6 · The plan is charged to the rule, not to the credential

*one consumer with two credentials has one bucket, or a plan means nothing*

```bash
curl -s "$DASH/api/state?key=$DKEY" | python3 -c 'import json,sys;print([c["Quota"] for c in json.load(sys.stdin)["consumers"] if c["Name"]=="c0"])'
call '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' > /dev/null
curl -s -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"listar_clientes","arguments":{}}}' > /dev/null
curl -s "$DASH/api/state?key=$DKEY" | python3 -c 'import json,sys;print([c["Quota"] for c in json.load(sys.stdin)["consumers"] if c["Name"]=="c0"])'
```

**Passes when** the counter went up by **two**: two credentials, one bucket. The transactions show
`via api_key` and `via oauth2`, and the consumer page shows a single quota.

### E7 · How a call got in is in the trace, not in the log

*the same consumer can arrive three ways, and an auditor has to be able to tell which*

```bash
# $TX is already set by doc/manual-env.sh; this is how it is found
TX=$(curl -s "$DASH/consumer/$C0?key=$DKEY" | grep -oE '/transaction/[a-f0-9-]+' | head -1)
curl -s "$DASH$TX?key=$DKEY" | grep -oE "consumer c0[^<]*"
```

**Passes when** the **authentication** step reads `consumer c0 · plan free · via api_key`, and
`via oauth2` or `via oauth2-external` on the calls that arrived with a token. Same consumer, same
plan, and the trace says which credential each call carried.

### E8 · The external half, against a real provider

*a token minted by somebody else's IDP is accepted, and both halves can run at once*

```json
"auth_server": {
  "internal": { "enabled": true, "jwt_secret": "env:OTS_JWT_SECRET" },
  "external": { "enabled": true,
                "jwks_url": "https://localhost:9443/oauth2/jwks",
                "issuer": "https://localhost:9443/oauth2/token",
                "tls_skip_verify": true }
}
```

with the `client_id` of that provider declared **with no secret** — a resource server never sees one:

```json
{ "oauth2": { "client_id": "wpd8x7vCxP6XbdgI0ZP86ggOGyoa" } }
```

```bash
WTOK=$(curl -sk -X POST https://localhost:9443/oauth2/token -d 'grant_type=client_credentials' \
  -u 'wpd8x7vCxP6XbdgI0ZP86ggOGyoa:<secret>' \
  | python3 -c 'import json,sys;print(json.load(sys.stdin)["access_token"])')

curl -s -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $WTOK" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
curl -s "${GW%/mcp/messages}/.well-known/oauth-protected-resource"
```

**Passes when** the call is `200` and the trace says `via oauth2-external`; a token of ours **also**
works on the same gateway, each validated by the half its algorithm belongs to; and the metadata
advertises **two** authorization servers. Also worth checking: `audiences` left empty warns at
startup, and a token whose `aud` is not ours is refused with *the token audience … is not this
server*.

### E9 · Credentials added and removed from the console, hot

*onboarding and offboarding an agent must not need a restart, and must not be able to lock a rule out*

```bash
curl -s -X POST "$CONSOLE/method/add?key=$CKEY" -d 'consumer=0&rule=0&kind=oauth2' | grep -o 'client_id: [^<]*'
curl -s -X POST $AUTH -d "grant_type=client_credentials&client_id=<the new one>&client_secret=<the new one>"
curl -s -X POST "$CONSOLE/method/delete?key=$CKEY" -d 'consumer=0&rule=0&method=2'
```

**Passes when** the new client gets a token with no restart, stops getting one after the delete, and
the **last** credential of a rule cannot be deleted (*use "Revoke this rule" instead*) — a rule with
no credential is a rule nobody can use and nobody can fix from the UI.

Also worth checking in `ots.json` afterwards: `auth_server` stays at the top level and none
appears inside `otsgateway`, and the credentials are written as `auth_method`.

### E10 · The tolerant spellings still load

*a configuration written the old way, or with a typo the loader can survive, must not take the server down*

```bash
# each spelling, written and then put back. The gateway keeps serving throughout.
cp ots.json /tmp/config.backup.json
python3 - <<'PY'
import json,io
c=json.load(io.open("ots.json"))
rule=c["subscriptions"][0]["security"][0]
rule["aut_method"]=rule.pop("auth_method")          # the typo the loader survives
json.dump(c,io.open("ots.json","w"),indent=2,ensure_ascii=False)
PY
sleep 7 ; grep -E '⚠️|❌' logs/otsgateway.log | tail -3
curl -s -o /dev/null -w 'still serving: %{http_code}\n' -X POST $GW -H 'Content-Type: application/json' -H "$K" -d "$CALL"
cp /tmp/config.backup.json ots.json ; sleep 7
```

- `aut_method` instead of `auth_method`: accepted, everything keeps working.
- The old `"api_key": "…"` shorthand instead of the list: accepted, and the log **warns**.
- `auth_server` nested inside `mcps[]`: promoted to the top level at load time and removed from the
  file the console writes — a server believed to be protected must never come up open.
- `port` and `server_port`: either spelling, one of them; both with the same value is fine, both with
  different values is refused (case 1.8).

**Passes when** every one of those loads and the server keeps serving, with the warning where the
list says there is one. A tolerated spelling that silently dropped what it carried would be worse
than a refusal — which is why the `scopes` of an `api_key` are part of case 3.10.

### E11 · The script: status, restart and a stop that is not a kill

*the operational commands do what they say, and say what they did*

```bash
./otsgateway.sh -status
./otsgateway.sh -restart macos-arm64
./otsgateway.sh -stop macos-arm64
```

**Passes when** `-status` prints the PID and **the ports it really binds** (it asks the operating
system, it does not read the config); `-restart` stops, re-sources `secrets.env` and comes back with
a new PID; and `-stop` produces the orderly shutdown of case 10.13 rather than a `kill -9`. With
nothing running, `-status` says `🔴 No hay ninguna instancia en marcha` and, if a stale pid file is
left over, names the pid that no longer exists.

### E12 · The whole token-validation matrix

*the classic attacks on a resource server, each with the message that names what was wrong*

Cases 2.6 and 2.7 cover two of these. The six together are the matrix worth walking after
any change to the authentication path.

| Token | Refused with |
|---|---|
| `alg: none` | *unsupported signing algorithm "none": only HS256 (internal) and RS256 (external)* |
| signature tampered with | *the token signature does not verify* |
| HS256 signed with another secret | *the token signature does not verify* |
| valid but expired | *the token expired at …* |
| valid, `client_id` of nobody | `403` · *the token subject … is not declared in any subscription* |
| RS256 while `external` is disabled | *this server accepts no external tokens: RS256 is not accepted* |

```bash
# HS256 signed with a secret that is not ours
FAKE=$(python3 -c "
import base64,json,hmac,hashlib
h=base64.urlsafe_b64encode(json.dumps({'alg':'HS256','typ':'JWT'}).encode()).rstrip(b'=').decode()
p=base64.urlsafe_b64encode(json.dumps({'iss':'ots-gateway','aud':'ots-gateway',
  'client_id':'agente-ventas','exp':9999999999}).encode()).rstrip(b'=').decode()
s=base64.urlsafe_b64encode(hmac.new(b'otro-secreto',(h+'.'+p).encode(),
  hashlib.sha256).digest()).rstrip(b'=').decode()
print(h+'.'+p+'.'+s)")
curl -s -X POST $GW -H 'Content-Type: application/json' -H "Authorization: Bearer $FAKE" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
```

**Passes when** every one of the six is refused, and the message names which check failed — a single
generic *unauthorized* would make the authentication path undebuggable.

### E13 · The discovery chain, walked end to end

*an agent configured with nothing but the gateway address can find its way to a token*

```bash
# 1 · a bare call, to be told where to authenticate
curl -si -X POST $GW -H 'Content-Type: application/json' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | grep -i www-authenticate

# 2 · the resource metadata that header points at
curl -s "${GW%/mcp/messages}/.well-known/oauth-protected-resource"

# 3 · the metadata of the authorization server that document names
curl -s "${AUTH%/oauth/token}/.well-known/oauth-authorization-server"

# 4 · and the token, at the endpoint that document declares
curl -s -X POST $AUTH -d "grant_type=client_credentials&client_id=$CID&client_secret=$CSEC"
```

**Passes when** each step is read from the previous one and **nothing in the chain was configured by
hand**. `server/discover` publishes the same thing in one round trip for an agent that speaks the
2026-07-28 revision, and its `authentication.tokenEndpoint` is the **whole address** while the
server is on its own port, and just the path when it shares.

### E14 · The mock inheriting the top-level auth_server

*deleting the mock's own block must protect it with the gateway's rules, not leave it open*

```bash
cp ots.json /tmp/config.backup.json
python3 - <<'PY'
import json,io
c=json.load(io.open("ots.json"))
c.get("mock_server",{}).pop("auth_server",None)
json.dump(c,io.open("ots.json","w"),indent=2,ensure_ascii=False)
PY
sleep 7 ; grep -E 'Mock abierto|mock' logs/otsgateway.log | tail -3
curl -s -o /dev/null -w 'mock with a gateway token: %{http_code}\n' -X POST $MOCK/mcp/messages \
  -H 'Content-Type: application/json' -H "Authorization: Bearer $TOKEN" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}'
cp /tmp/config.backup.json ots.json ; sleep 7
```

Delete `mock_server.auth_server` entirely and reload.

**Passes when** the mock is protected with the **same** rules and the same secret as the gateway, so
a gateway token opens it — and the startup no longer says `🔓 Mock abierto`. If that block has its
own `port`, the single listener already serves the mock: check with
`lsof -nP -iTCP -sTCP:LISTEN | grep otsgateway` that there is no second one.


---

## Running these on PowerShell

The cases are bash, and the shortest answer is **Git Bash or WSL**, where they run unchanged. If you
have to stay in PowerShell, two things have to be worked around.

**`curl` is not curl.** In PowerShell it is an alias of `Invoke-WebRequest`, which takes a dictionary
for `-Headers` and knows nothing about `-H` or `-d`:

```
Invoke-WebRequest : Cannot bind parameter 'Headers'. Cannot convert the
"Content-Type: application/json" value of type "System.String" to type
"System.Collections.IDictionary".
```

Call the real one, which Windows 10 and 11 ship, by its full name — **`curl.exe`**:

```powershell
curl.exe -s -X POST http://localhost:3002/botibankots/mcp/messages `
  -H "Content-Type: application/json" `
  -H "X-API-Key: default-key-1235" `
  --data-raw '{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"1"}}}'
```

**The quotes are the other half.** PowerShell rewrites quoting on its way to a native program, so a
JSON body written inline is the thing most likely to arrive mangled. Put it in a file and stop
thinking about it:

```powershell
'{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"consultar_cuentas","arguments":{"cliente_id":"1"}}}' |
  Set-Content -Encoding utf8 body.json
curl.exe -s -X POST http://localhost:3002/botibankots/mcp/messages `
  -H "Content-Type: application/json" -H "X-API-Key: default-key-1235" `
  --data-binary "@body.json"
```

**Or do it the PowerShell way**, which has no quoting problem at all because nothing is a string:

```powershell
$body = @{
  jsonrpc = "2.0"; id = 1; method = "tools/call"
  params = @{ name = "consultar_cuentas"; arguments = @{ cliente_id = "1" } }
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Method Post -Uri http://localhost:3002/botibankots/mcp/messages `
  -ContentType "application/json" `
  -Headers @{ "X-API-Key" = "default-key-1235" } `
  -Body $body | ConvertTo-Json -Depth 10
```

`Invoke-RestMethod` parses the answer for you, so there is no `| python3 -m json.tool` either — and
`python3` is usually `python` on Windows anyway.

**What does not change**: the gateway, the ports and the credentials are the same. `doc/manual-env.sh`
is bash, so on PowerShell read the values out of `ots.json` yourself, or run that one command in Git
Bash and copy what it prints.

---

## When one fails

1. **The id is the same everywhere.** Look it up in
   [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md) for where it sits in the ordered walk, and
   run `./TESTING-ONE-ONE.sh -case <id>` to see whether it fails on a clean disposable instance too.
   If it passes there and fails here, the difference is your configuration, not the code.
2. **Read the trace before the log.** `$DASH/transaction/<id>?key=$DKEY` has the pipeline step by
   step and the four payloads, with the secrets masked. It usually names the problem outright.
3. **The log has the half the agent never sees.** A backend error reaches the agent as `-33005` with
   a `requestId`; the address, the status and the body stay in `logs/otsgateway.log` under that same
   `requestId`.

## See also

- [`PRUEBAS-CASOS-UNO-UNO.md`](PRUEBAS-CASOS-UNO-UNO.md) — the same cases as an ordered checklist
- [`TESTING-ONE-ONE.sh`](TESTING-ONE-ONE.sh) — the same cases, executed
- [`CONFIGURATION.md`](CONFIGURATION.md) — every `ots.json` field, and what applies live
- [`OTD-REFERENCE.md`](OTD-REFERENCE.md) — the spec format, and what the loader refuses or warns about
- [`README.md`](README.md) — what each feature is and why it works the way it does
