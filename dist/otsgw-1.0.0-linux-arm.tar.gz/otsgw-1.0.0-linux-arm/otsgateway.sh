#!/bin/bash

# ==========================================
# VARIABLES GLOBALES
# ==========================================
# The binary is otsgw. It was otsgateway until 1.0.0, and the name of a script
# is not the name of a program: this file keeps its own name so that anybody who
# has ./otsgateway.sh in a runbook still has it.
APP_NAME="otsgw"
PID_FILE=".local_pids"
LOG_DIR="logs"
LOG_FILE="$LOG_DIR/otsgateway.log"
# Secretos fuera de config.json. Fichero local, en .gitignore; la plantilla
# secrets.json.example sí se versiona.
SECRETS_JSON="secrets.json"       # el que lee el gateway

# ==========================================
# 🏗️ COMPILACIÓN
# ==========================================
# Tabla única de plataformas. Formato:
#   tag|GOOS|GOARCH|alias,separados,por,comas|descripción
# Se usa tanto para listar como para resolver lo que se pide, así que añadir una
# plataforma es añadir una línea aquí y nada más.
#
# Bash 3.2 (el que trae macOS) no tiene arrays asociativos: de ahí la tabla en
# texto en vez de un declare -A.
tag_table() {
    cat <<'TABLA'
macos-arm64|darwin|arm64|macos,mac,darwin-arm64|Mac con Apple Silicon (M1 a M4)
macos-amd64|darwin|amd64|macos-intel,mac-intel,darwin-amd64|Mac con Intel
linux-amd64|linux|amd64|linux,ubuntu,debian,rhel|Linux x86_64: servidores y contenedores
linux-arm64|linux|arm64|linux-aarch64,graviton|Linux ARM64: AWS Graviton, contenedores ARM, Raspberry 64
linux-arm|linux|arm|raspberry,rpi|Linux ARMv6/v7: Raspberry de 32 bits
linux-386|linux|386|linux-x86,linux-32|Linux x86 de 32 bits
windows-amd64|windows|amd64|windows,win|Windows x86_64
windows-arm64|windows|arm64|win-arm|Windows on ARM (Surface y similares)
freebsd-amd64|freebsd|amd64|freebsd|FreeBSD x86_64
TABLA
}

DIST_DIR="dist"

# Ficheros que acompañan al binario en cada paquete. config.json NO viaja: lleva
# credenciales reales. Se distribuye config.example.json, que arranca en modo
# mock sin backend y con marcadores en lugar de secretos.
# Lo que no está se avisa al final, una vez, en vez de faltar en los nueve
# paquetes sin que nadie lo note.
MISSING_FILES=""

PACKAGE_FILES=(
    "boti-bank-ots.yaml"
)

# El despliegue de ejemplo viaja como carpeta, no suelto en la raíz: un
# ots.json en la raíz del paquete es un ots.json que alguien arranca sin leer,
# con las credenciales vacías y sin saber por qué se niega. En ejemplo/ hay que
# copiarlo a mano, y al lado está el LEEME que dice qué rellenar.
PACKAGE_DIRS=(
    "ejemplo"
)

# La documentación vive en doc/ y viaja con esa misma ruta dentro del paquete,
# para que los enlaces entre documentos sigan resolviendo.
PACKAGE_DOCS=(
    "doc/README.md"
    "doc/CONFIGURATION.md"
    "doc/OTD-REFERENCE.md"
    "doc/PARKED-TOPICS.md"
    "doc/MANUAL-TESTS.md"
)

# ---------- listado: lo que responde -compile sin argumento ----------
list_targets() {
    local host_tag="$(go env GOOS)/$(go env GOARCH)"
    echo "🏗️  Compilación de OTS Gateway. Hay que decir para qué plataforma:"
    echo ""
    printf "     %-16s %-14s %s\n" "TAG" "GOOS/GOARCH" "PARA QUIÉN"
    printf "     %-16s %-14s %s\n" "----------------" "-------------" "----------------------------------------"
    tag_table | while IFS='|' read -r tag os arch aliases desc; do
        [ -z "$tag" ] && continue
        local platform="$os/$arch" mark="   "
        # La plataforma de esta máquina se señala: compilarla deja además el
        # binario en la raíz, listo para -start.
        [ "$platform" = "$host_tag" ] && mark="→  "
        printf "  %s%-16s %-14s %s\n" "$mark" "$tag" "$platform" "$desc"
        [ -n "$aliases" ] && printf "     %-16s %s\n" "" "alias: $(echo $aliases | tr ',' ' ')"
        true
    done
    echo ""
    echo "     all              todas las de arriba, de una vez: una release entera"
    echo "                      alias: todas"
    echo ""
    echo "     →  todo sale a ./$DIST_DIR, y -start arranca el binario del tag que se le diga"
    echo ""
    echo "  Ejemplos:"
    echo "     ./otsgateway.sh -compile macos-arm64   # esta máquina"
    echo "     ./otsgateway.sh -compile macos         # el mismo, por su alias"
    echo "     ./otsgateway.sh -compile linux-amd64"
    echo "     ./otsgateway.sh -compile windows
     ./otsgateway.sh -compile all           # las nueve, para publicar"
    echo ""
    echo "  Cada compilación se acumula en ./$DIST_DIR con su paquete y su checksum."
    echo ""
}

# ---------- resolución de un tag o alias a "tag os arch" ----------
resolve_tag() {
    local wanted="$1" found=""
    found=$(tag_table | awk -F'|' -v w="$wanted" '
        $1 == "" { next }
        {
            if ($1 == w) { print $1, $2, $3; exit }
            n = split($4, a, ",")
            for (i = 1; i <= n; i++) if (a[i] == w) { print $1, $2, $3; exit }
        }')
    [ -z "$found" ] && return 1
    echo "$found"
}

# ldflags: -s -w quita la tabla de símbolos y el DWARF (unos 3 MB menos), y las
# dos -X sellan el binario para poder responder "¿qué build es este?".
build_ldflags() {
    local commit date
    commit=$(git rev-parse --short HEAD 2>/dev/null || echo "sin-git")
    date=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    echo "-s -w -X main.buildCommit=$commit -X main.buildDate=$date"
}

prepare_module() {
    # El script viaja dentro de los paquetes distribuibles, donde no hay fuentes:
    # sin este aviso, "go mod init" crearía basura y el error sería incomprensible.
    if [ ! -f main.go ]; then
        echo "❌ No hay fuentes aquí: este directorio es un paquete con el binario ya compilado."
        echo "💡 Usa './$APP_NAME -config config.json' directamente, o clona el repositorio para compilar."
        exit 1
    fi
    if [ ! -f go.mod ]; then
        go mod init otsgateway
    fi
    go mod tidy
}

app_version() {
    grep -m1 'serverVersion  *= *"' main.go | sed 's/.*"\(.*\)".*/\1/'
}

# ---------- una plataforma ----------
# $1 tag ya resuelto, $2 GOOS, $3 GOARCH, $4 ldflags, $5 "quiet" para no repetir cabecera
compile_target() {
    local tag="$1" os="$2" arch="$3" ldflags="$4"
    local ext="" name version stage archive

    [ "$os" = "windows" ] && ext=".exe"
    name="$APP_NAME-$os-$arch$ext"
    version=$(app_version)

    printf "   %-16s " "$tag"
    if ! CGO_ENABLED=0 GOOS=$os GOARCH=$arch go build -trimpath -ldflags "$ldflags" -o "$DIST_DIR/$name" . 2>$DIST_DIR/.err; then
        printf "FALLO\n"; sed 's/^/      /' $DIST_DIR/.err | head -3; return 1
    fi

    # Un paquete por plataforma: el binario con su nombre de siempre, la
    # configuración de ejemplo, el spec y la documentación.
    stage="$DIST_DIR/.stage/$APP_NAME-$version-$os-$arch"
    mkdir -p "$stage/logs"
    cp "$DIST_DIR/$name" "$stage/$APP_NAME$ext"
    # Un fichero listado que no está se copiaba en silencio: los paquetes
    # salieron sin ninguna configuración de ejemplo durante un día entero, y
    # nada lo dijo. Se avisa, y el paquete sigue haciéndose.
    for f in "${PACKAGE_FILES[@]}"; do
        if [ -f "$f" ]; then
            cp "$f" "$stage/"
        else
            MISSING_FILES="$MISSING_FILES $f"
        fi
    done
    for d in "${PACKAGE_DIRS[@]}"; do
        if [ -d "$d" ]; then
            cp -R "$d" "$stage/"
        else
            MISSING_FILES="$MISSING_FILES $d/"
        fi
    done
    mkdir -p "$stage/doc"
    for f in "${PACKAGE_DOCS[@]}"; do
        [ -f "$f" ] && cp "$f" "$stage/doc/"
    done
    # El lanzador en shell solo sirve donde hay bash.
    [ "$os" != "windows" ] && cp otsgateway.sh "$stage/" 2>/dev/null

    if [ "$os" = "windows" ]; then
        archive="$APP_NAME-$version-$os-$arch.zip"
        (cd "$DIST_DIR/.stage" && zip -qr "../$archive" "$APP_NAME-$version-$os-$arch")
    else
        archive="$APP_NAME-$version-$os-$arch.tar.gz"
        (cd "$DIST_DIR/.stage" && tar czf "../$archive" "$APP_NAME-$version-$os-$arch")
    fi
    rm -rf "$DIST_DIR/.stage"
    printf "OK   %-6s  %s\n" "$(du -h "$DIST_DIR/$name" | cut -f1)" "$archive"

    # Nada se copia a la raíz: dist es la única salida, y -start saca de ahí el
    # binario del tag que se le diga.
    if [ "$os" = "$(go env GOOS)" ] && [ "$arch" = "$(go env GOARCH)" ]; then
        echo "      $("$DIST_DIR/$name" -version)"
        echo "      es la plataforma de esta máquina: ./otsgateway.sh -start $tag"
    fi
    return 0
}

write_checksums() {
    if command -v shasum >/dev/null 2>&1; then
        (cd $DIST_DIR && shasum -a 256 $(ls | grep -v SHA256SUMS) > SHA256SUMS.txt 2>/dev/null)
    elif command -v sha256sum >/dev/null 2>&1; then
        (cd $DIST_DIR && sha256sum $(ls | grep -v SHA256SUMS) > SHA256SUMS.txt 2>/dev/null)
    fi
}

# ---------- punto de entrada de -compile ----------
compile() {
    local wanted="$1"

    # Sin argumento no se compila nada: se dice qué hay.
    if [ -z "$wanted" ]; then
        list_targets
        exit 0
    fi

    local resolved ldflags ok=0 fail=0

    # "all" compila todas las plataformas de la tabla. Es una release entera en
    # un comando; para el día a día sigue siendo una por invocación, que es
    # mucho más rápido.
    if [ "$wanted" = "all" ] || [ "$wanted" = "todas" ]; then
        resolved=""
    else
        resolved=$(resolve_tag "$wanted")
        if [ -z "$resolved" ]; then
            echo "❌ Plataforma desconocida: '$wanted'"
            echo ""
            list_targets
            exit 1
        fi
    fi

    prepare_module

    # go vet antes de compilar: cuesta un segundo y caza lo que el compilador
    # deja pasar. Un fallo aquí para la compilación, porque publicar un binario
    # que vet rechaza es publicar un problema conocido.
    echo "🔍 go vet ./..."
    if ! go vet ./... ; then
        echo "❌ go vet ha encontrado problemas: no se compila."
        exit 1
    fi

    mkdir -p $DIST_DIR
    ldflags=$(build_ldflags)

    if [ -z "$resolved" ]; then
        # Todas. Una que falle no detiene a las demás: al final se dice cuántas
        # salieron y cuántas no, que es lo que hace falta saber en una release.
        local total=0
        echo "🏗️  Compilando todas las plataformas..."
        while IFS='|' read -r tag os arch _alias _desc; do
            [ -z "$tag" ] && continue
            total=$((total + 1))
            if compile_target "$tag" "$os" "$arch" "$ldflags"; then
                ok=$((ok + 1))
            else
                fail=$((fail + 1))
            fi
        done <<EOF
$(tag_table)
EOF
        echo ""
        echo "   $ok de $total plataformas compiladas$([ $fail -gt 0 ] && echo ", $fail con errores")"
    else
        # Una plataforma por invocación: hay que decir cuál, y lo que ya estaba
        # en dist se conserva, así que publicar varias es repetir el comando.
        set -- $resolved
        echo "🏗️  Compilando para $1..."
        if compile_target "$1" "$2" "$3" "$ldflags"; then ok=1; else fail=1; fi
    fi

    rm -f $DIST_DIR/.err
    # Si no quedó ningún artefacto no se inventa un directorio ni un fichero de
    # checksums vacío.
    if [ -n "$(ls -A $DIST_DIR 2>/dev/null | grep -v SHA256SUMS)" ]; then
        write_checksums
    else
        rm -f $DIST_DIR/SHA256SUMS.txt
        rmdir $DIST_DIR 2>/dev/null
    fi

    echo ""
    if [ $fail -gt 0 ]; then
        echo "❌ La compilación falló."
        exit 1
    fi
    echo "✅ Compilación correcta."
    if [ -n "$MISSING_FILES" ]; then
        echo "⚠️  No están, así que los paquetes salen sin ellos:$(echo "$MISSING_FILES" | tr ' ' '\n' | sort -u | tr '\n' ' ')"
        echo "    Quien reciba un paquete no tendrá de qué partir: el gateway busca ots.json y no lo encuentra."
    fi
    if [ -d $DIST_DIR ]; then
        [ -f "$DIST_DIR/SHA256SUMS.txt" ] && echo "🔒 Checksums en $DIST_DIR/SHA256SUMS.txt"
        echo "🔎 Comprobar que nada se ha tocado: (cd $DIST_DIR && shasum -a 256 -c SHA256SUMS.txt)"
        echo "💡 Comprobar en el destino: ./$APP_NAME -version"
        echo ""
        ls -lh $DIST_DIR | tail -n +2 | awk '{printf "   %-52s %s\n", $9, $5}'
    fi
    echo ""
}

# ==========================================
# 🎯 RESOLUCIÓN DEL BINARIO DE UN TAG
# ==========================================
# host_tag es el tag de esta máquina: el que -start y -stop usan por defecto,
# porque es el único binario que este equipo puede ejecutar.
host_tag() {
    tag_table | awk -F'|' -v os="$(go env GOOS)" -v arch="$(go env GOARCH)" '
        $2 == os && $3 == arch { print $1; exit }'
}

# binary_for <tag resuelto> <GOOS> <GOARCH> -> ruta en dist
binary_for() {
    local os="$2" arch="$3" ext=""
    [ "$os" = "windows" ] && ext=".exe"
    echo "$DIST_DIR/$APP_NAME-$os-$arch$ext"
}

# pid_file_for <tag> -> un fichero de PIDs por tag, para que -stop <tag> sepa
# a quién apagar.
pid_file_for() { echo "$PID_FILE.$1"; }

# resolve_runnable <tag o vacío> -> imprime "tag os arch binario", o falla con el
# motivo. Aquí es donde se atrapa el error de intentar arrancar un binario de
# otra arquitectura: compilarlo se puede, ejecutarlo no.
resolve_runnable() {
    local wanted="$1" resolved tag os arch bin
    if [ -z "$wanted" ]; then
        wanted=$(host_tag)
        if [ -z "$wanted" ]; then
            echo "❌ Esta plataforma ($(go env GOOS)/$(go env GOARCH)) no está en la tabla de tags." >&2
            return 1
        fi
    fi
    resolved=$(resolve_tag "$wanted")
    if [ -z "$resolved" ]; then
        echo "❌ Plataforma desconocida: '$wanted'." >&2
        echo "💡 Ejecuta './otsgateway.sh -compile' para ver los tags." >&2
        return 1
    fi
    set -- $resolved
    tag="$1"; os="$2"; arch="$3"
    # Compilar para otra arquitectura se puede; ejecutarla aquí, no.
    if [ "$os" != "$(go env GOOS)" ] || [ "$arch" != "$(go env GOARCH)" ]; then
        echo "❌ El binario de '$tag' es para $os/$arch y esta máquina es $(go env GOOS)/$(go env GOARCH): aquí no se puede ejecutar." >&2
        echo "💡 Para arrancar en esta máquina: ./otsgateway.sh -start $(host_tag)" >&2
        return 1
    fi
    bin=$(binary_for "$tag" "$os" "$arch")
    echo "$tag $os $arch $bin"
}

# ==========================================
# 🛑 FUNCIÓN: DETENER SERVICIOS
# ==========================================
# stop [tag]: con tag apaga esa instancia; sin tag, todas las que haya.
stop() {
    local wanted="$1" files="" f killed=0

    if [ -n "$wanted" ]; then
        local resolved
        resolved=$(resolve_tag "$wanted")
        if [ -z "$resolved" ]; then
            echo "❌ Plataforma desconocida: '$wanted'. Ejecuta -compile para ver los tags."
            exit 1
        fi
        set -- $resolved
        files=$(pid_file_for "$1")
        echo "🛑 Apagando OTS Gateway ($1)..."
    else
        # Los .local_pids.<tag> de cualquier tag, y el .local_pids suelto que
        # dejaban las versiones anteriores del script.
        files=$(ls $PID_FILE.* 2>/dev/null)
        [ -f "$PID_FILE" ] && files="$files $PID_FILE"
        echo "🛑 Apagando OTS Gateway..."
    fi

    # SIGTERM primero: el gateway tiene apagado ordenado (cierra el diario, drena
    # las peticiones en vuelo). El -9 queda como último recurso, no como norma.
    for f in $files; do
        [ -f "$f" ] || continue
        while read pid; do
            kill -0 $pid 2>/dev/null || continue
            kill -TERM $pid 2>/dev/null
            for _ in 1 2 3 4 5 6 7 8 9 10; do
                kill -0 $pid 2>/dev/null || break
                sleep 0.3
            done
            if kill -0 $pid 2>/dev/null; then
                echo "⚠️  El PID $pid no se apagó con SIGTERM: forzando."
                kill -9 $pid 2>/dev/null
            fi
            killed=$((killed+1))
        done < "$f"
        rm -f "$f"
    done

    if [ $killed -gt 0 ]; then
        echo "✅ Servicio detenido correctamente ($killed proceso(s))."
    else
        echo "⚠️ No había nada en marcha (ningún fichero de PIDs). Probablemente ya esté apagado."
    fi
    echo ""
}

# ==========================================
# 📊 FUNCIÓN: ESTADO
# ==========================================
# status [tag]: qué hay en marcha, con su PID y sus puertos escuchando. Sin tag,
# todas las instancias que tengan fichero de PIDs.
status() {
    local wanted="$1" files="" f any=0

    if [ -n "$wanted" ]; then
        local resolved
        resolved=$(resolve_tag "$wanted")
        if [ -z "$resolved" ]; then
            echo "❌ Plataforma desconocida: '$wanted'. Ejecuta -compile para ver los tags."
            exit 1
        fi
        set -- $resolved
        files=$(pid_file_for "$1")
    else
        files=$(ls $PID_FILE.* 2>/dev/null)
        [ -f "$PID_FILE" ] && files="$files $PID_FILE"
    fi

    for f in $files; do
        [ -f "$f" ] || continue
        while read pid; do
            if kill -0 $pid 2>/dev/null; then
                any=1
                echo "✅ En marcha · PID $pid · $(basename "$f")"
                # Los puertos que ese proceso tiene abiertos: es la forma honesta
                # de responder "¿está escuchando donde yo creo?".
                # El -a es imprescindible: sin él lsof une los filtros en vez de
                # cruzarlos, y lista los sockets de toda la máquina.
                if command -v lsof > /dev/null 2>&1; then
                    lsof -a -nP -p $pid -iTCP -sTCP:LISTEN 2>/dev/null \
                        | awk 'NR>1 && $9 ~ /:/ {print "   ↳ escuchando en " $9}' | sort -u
                fi
            else
                echo "⚠️  Fichero de PIDs $(basename "$f") con el PID $pid, que ya no existe (arranque fallido o apagado a mano)."
            fi
        done < "$f"
    done

    [ $any -eq 0 ] && echo "🔴 No hay ninguna instancia en marcha."
    echo ""
}

# ==========================================
# 🚀 FUNCIÓN: INICIAR SERVICIOS
# ==========================================
# start [tag] [config]: arranca el binario de ese tag desde dist. Los dos
# argumentos son opcionales y se distinguen solos, así que "-start config.json"
# sigue funcionando igual que antes.
start() {
    local tag="" config="" resolved bin pid_file

    # Los dos argumentos son opcionales y en cualquier orden: lo que resuelve
    # como tag es el tag, lo que existe como fichero es la configuración. Lo que
    # no es ni una cosa ni la otra es un error, no una ruta inventada.
    for arg in "$1" "$2"; do
        [ -z "$arg" ] && continue
        if [ -z "$tag" ] && [ -n "$(resolve_tag "$arg")" ]; then
            tag="$arg"
        elif [ -f "$arg" ]; then
            config="$arg"
        else
            echo "❌ '$arg' no es un tag de plataforma ni un fichero de configuración existente."
            echo "💡 Tags: ./otsgateway.sh -compile   ·   uso: -start [tag] [ots.json]"
            exit 1
        fi
    done
    # El fichero se llama ots.json. config.json se sigue aceptando: todos los
    # despliegues que existen se crearon con ese nombre, y renombrarlos a la
    # fuerza no gana nada.
    if [ -z "$config" ]; then
        for candidate in ots.json config.json; do
            [ -f "$candidate" ] && config="$candidate" && break
        done
        [ -z "$config" ] && config="ots.json"
    fi

    if ! resolved=$(resolve_runnable "$tag"); then
        # resolve_runnable ya explicó el motivo por stderr.
        exit 1
    fi
    set -- $resolved
    tag="$1"; bin="$4"
    pid_file=$(pid_file_for "$tag")

    echo "🚀 Iniciando OTS Gateway ($tag) en segundo plano..."
    echo "📁 Usando configuración: $config"

    if [ ! -x "$bin" ]; then
        echo "❌ ERROR: no existe el binario '$bin'."
        echo "💡 Solución: ./otsgateway.sh -compile $tag"
        exit 1
    fi
    if [ ! -f "$config" ]; then
        echo "❌ ERROR: no existe el fichero de configuración '$config'."
        exit 1
    fi

    # Los secretos no están en config.json, que se versiona: viven en
    # secrets.json, que lee el propio gateway y que la consola puede escribir.
    # Este script ya no tiene que cargar nada.
    if [ -f "$SECRETS_JSON" ]; then
        echo "🔐 Secretos en $SECRETS_JSON (los lee el gateway)"
    elif grep -q '"env:' "$config" 2>/dev/null; then
        echo "⚠️  $config referencia secretos por nombre (env:) y no hay $SECRETS_JSON."
        echo "💡 Crea $SECRETS_JSON con esos nombres, o exporta las variables a mano."
    fi

    [ -f "$pid_file" ] && stop "$tag" > /dev/null

    mkdir -p $LOG_DIR
    "$bin" -config "$config" > $LOG_FILE 2>&1 &
    echo $! > "$pid_file"

    echo "🏷️  $("$bin" -version)"
    echo "✅ OTS Gateway levantado con éxito (PID: $(cat "$pid_file"))."
    echo "📄 Puedes ver los logs en tiempo real con: tail -f $LOG_FILE"
    echo ""
}

# ==========================================
# 🎛️ CONTROLADOR PRINCIPAL (CLI)
# ==========================================
case "$1" in
    -compile)
        compile "$2"
        ;;
    -version)
        if resolved=$(resolve_runnable "$2"); then
            set -- $resolved
            if [ -x "$4" ]; then "$4" -version; else echo "❌ No hay binario '$4': ejecuta -compile $1"; fi
        fi
        ;;
    -start)
        start "$2" "$3"
        ;;
    -stop)
        stop "$2"
        ;;
    -restart)
        stop "$2" 
        start "$2" "$3"
        ;;
    -status)
        status "$2"
        ;;
    *)
        echo "❌ Comando no reconocido."
        echo "Opciones disponibles:"
        echo "  ./otsgateway.sh -compile                  (Lista las plataformas que se pueden compilar)"
        echo "  ./otsgateway.sh -compile <tag>            (Compila esa plataforma: macos-arm64, linux-amd64, windows...)"
        echo "  ./otsgateway.sh -start [tag] [config]     (Lanza el binario de dist. Por defecto, el de esta máquina y ots.json, o config.json)"
        echo "  ./otsgateway.sh -stop [tag]               (Apaga esa instancia, o todas si no se dice el tag)"
        echo "  ./otsgateway.sh -restart [tag] [config]   (Apaga y vuelve a arrancar)"
        echo "  ./otsgateway.sh -status [tag]             (Qué hay en marcha, con su PID y sus puertos)"
        echo "  ./otsgateway.sh -version [tag]            (Versión, plataforma y commit del binario compilado)"
        exit 1
        ;;
esac